import type { NextConfig } from 'next';
const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  async headers() {
    const securityHeaders = [
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
      { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
      { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
      ...(process.env.NODE_ENV === 'production'
        ? [{ key: 'Strict-Transport-Security', value: 'max-age=31536000' }]
        : []),
    ];
    return [{ source: '/:path*', headers: securityHeaders }];
  },
  async rewrites() {
    const base=(process.env.API_INTERNAL_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');
    return [{source:'/uploads/:path*',destination:`${base}/public-media/:path*`}];
  },
};
export default nextConfig;
