import type {MetadataRoute} from 'next';
export default function robots():MetadataRoute.Robots {
  return {rules:{userAgent:'*',allow:'/',disallow:['/representative$','/representative/','/panel','/api']}, sitemap:(process.env.NEXT_PUBLIC_SITE_URL||'https://faromid.com')+'/sitemap.xml'};
}
