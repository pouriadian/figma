# Faromid — native Next.js + React + Tailwind CSS

نسخه‌ی مستقل سایت فرامید، بدون نیاز به Figma، خروجی API آن یا فایل‌های JSON طراحی.

## اجرا

```bash
npm install
npm run dev
```

سپس `http://localhost:3000` را باز کنید.

برای Production:

```bash
npm run lint
npm run build
npm start
```

## ساختار

- `src/app/`: صفحات و مسیرهای App Router و متادیتای SEO.
- `src/components/desktop/`: کامپوننت‌های واقعی JSX برای هر یک از هشت صفحه دسکتاپ.
- `src/components/site-layout.tsx`: پوسته Responsive مشترک و لایت‌باکس.
- `src/components/pages/`: View مستقل هر Route؛ فقط همان Desktop Component وارد Bundle هر مسیر می‌شود.
- `src/components/mobile-page.tsx`: صفحات مستقل موبایل و تبلت با Tailwind CSS.
- `src/components/`: هدر، فوتر، فرم، نقشه و اجزای مشترک.
- `src/app/globals.css`: فقط Tailwind و Reset پایه.
- `public/assets/`: تصاویر و SVGهای محلی پروژه.

هیچ فایلی در `src/design` یا import از داده‌های طرح وجود ندارد. هیچ سرویس خارجی طراحی در Runtime یا Build موردنیاز نیست.

## Fidelity و Responsive

دسکتاپ: لایه‌های گرافیکی موجود به صورت JSX ثابت و کلاس‌های Tailwind با همان مختصات، ابعاد، رنگ‌ها، فونت‌ها، ترتیب رسم، مسیردهی و SVGهای قبلی تبدیل شده‌اند. جهت حفظ مطابقت پیکسلی، در دسکتاپ یک Artboard قابل مقیاس‌گذاری با عرض مرجع 1727–1729px استفاده می‌شود. این انتخاب آگاهانه جایگزین یک بازطراحی Flex/Grid متفاوت است.

موبایل و تبلت (عرض حداکثر 900px): همان نسخه‌ی Responsive قبلی با Tailwind و کامپوننت‌های native React.

در موارد خاص مثل image backgrounds، matrix transforms و shadows، propertyهای inline استاندارد React باقی مانده‌اند؛ اطلاعات آنها در کد TSX ثبت شده، نه JSON.

## نکات عملیاتی

- فرم‌ها همچنان با `mailto:` اجرا می‌شوند و Backend دریافت پیام ندارند.
- جزئیات بعضی محصولات از داده‌های نمایشی استفاده می‌کند؛ قبل از Production به ERP / API واقعی وصل کنید.
- فایل‌ها و تصاویر روی پروژه local هستند و برای نمایش از Figma استفاده نمی‌شود.
- `npm install` روی محیطی که دسترسی به npm دارد باید اجرا و lockfile تولید شود.

## صفحات

`/`, `/products`, `/about`, `/careers`, `/gallery`, `/dealership`, `/contact`, `/exhibitions`, `/textures`, `/products/product-1` ... `/products/product-12`.
