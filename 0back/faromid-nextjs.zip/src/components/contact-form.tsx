'use client';

import {useState, type FormEvent} from 'react';
import {ArrowUpLeft} from 'lucide-react';
import {buttonStyles, formFieldStyles} from '@/lib/tailwind-styles';

export function ContactForm({type = 'contact'}: {type?: 'contact' | 'careers' | 'dealership'}) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [notice, setNotice] = useState(false);
  const subject = type === 'careers' ? 'درخواست همکاری' : type === 'dealership' ? 'درخواست نمایندگی' : 'پیام از وبسایت فرامید';

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const body = `نام: ${name}\nایمیل: ${email}\n\n${message}`;
    window.location.href = `mailto:info@faromid.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setNotice(true);
  };

  return (
    <form className="mx-auto mt-[20px] flex max-w-[650px] flex-col gap-[8px]" onSubmit={submit}>
      <label className="text-[13px] font-bold" htmlFor={`${type}-name`}>نام و نام خانوادگی</label>
      <input className={formFieldStyles} required id={`${type}-name`} value={name} onChange={e => setName(e.target.value)} placeholder="نام شما" autoComplete="name" />
      <label className="text-[13px] font-bold" htmlFor={`${type}-email`}>ایمیل</label>
      <input className={formFieldStyles} required id={`${type}-email`} type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="name@example.com" dir="ltr" autoComplete="email" />
      <label className="text-[13px] font-bold" htmlFor={`${type}-message`}>پیام شما</label>
      <textarea className={formFieldStyles} required id={`${type}-message`} rows={4} value={message} onChange={e => setMessage(e.target.value)} placeholder={type === 'careers' ? 'زمینه تخصصی و راه ارتباطی خود را بنویسید...' : type === 'dealership' ? 'شهر و اطلاعات کسب‌وکار را شرح دهید...' : 'متن پیام...'} />
      <button className={buttonStyles} type="submit">ارسال از طریق ایمیل <ArrowUpLeft size={17} /></button>
      <p className="text-[11px] leading-[1.8] text-[#777]">
        {notice ? 'برنامه ایمیل دستگاه برای ارسال پیام باز شد؛ ارسال نهایی باید در همان برنامه تأیید شود.' : 'با انتخاب ارسال، برنامه ایمیل دستگاه باز می‌شود. ارسال مستقیم از سرور نیازمند اتصال API است.'}
      </p>
    </form>
  );
}
