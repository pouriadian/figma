"use client";
/* Pure JSX component. Desktop geometry and media are authored at build time,
 * so no design JSON, layout interpreter or external design service is used.
 * The absolute utility classes intentionally preserve the legacy pixel-perfect artwork. */
import Image from 'next/image';
import Link from 'next/link';

export function GalleryDesktop({onOpenImage}:{onOpenImage:(src:string)=>void}) {
  return (
    <>
      {/* Static Tailwind-rendered desktop artwork */}
      <div className={"absolute left-[384px] top-[73px] w-[1288px] h-[75px] box-border origin-top-left opacity-[0.8] rounded-[5px] bg-[#ffffff]"} />
      <div className={"absolute left-[1509px] top-[99px] w-[100px] h-[22px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"صفحه اصلی"}
      </div>
      <div className={"absolute left-[1376px] top-[101px] w-[87px] h-[19px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"محصولات"}
      </div>
      <div className={"absolute left-[866px] top-[100px] w-[66px] h-[20px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"درباره ما"}
      </div>
      <div className={"absolute left-[583px] top-[104px] w-[89px] h-[13px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"تماس با ما"}
      </div>
      <div className={"absolute left-[718px] top-[101px] w-[102px] h-[18px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"همکاری با ما"}
      </div>
      <div className={"absolute left-[978px] top-[103px] w-[95px] h-[15px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"نمایشگاه ها"}
      </div>
      <div className={"absolute left-[1280px] top-[93px] w-[54px] h-[36px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"تکسچر"}
      </div>
      <div className={"absolute left-[1118px] top-[101px] w-[102px] h-[24px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"گالری تصاویر"}
      </div>
      <div className={"absolute left-[741px] top-[2408px] w-[245px] h-[44px] box-border origin-top-left text-[#000000] text-[36px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"محصولات جدید"}
      </div>
      <div className={"absolute left-[720px] top-[2780px] w-[289px] h-[73px] box-border origin-top-left"}>
        <div className={"absolute left-[105px] top-[0px] w-[73px] h-[73px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left rounded-[4px] bg-[#f1f1f1]"} />
        </div>
        <div className={"absolute left-[134px] top-[13px] w-[18px] h-[44px] box-border origin-top-left text-[#ff0000] text-[36px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"1"}
        </div>
        <div className={"absolute left-[216px] top-[0px] w-[73px] h-[73px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left rounded-[4px] bg-[#f1f1f1]"} />
          <div className={"absolute left-[23px] top-[37px] w-[26px] h-[0px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26 1" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 0 -1.5 C -0.828 -1.5 -1.5 -0.828 -1.5 0 C -1.5 0.828 -0.828 1.5 0 1.5 L 0 -1.5 Z M 27.061 1.061 C 27.646 0.475 27.646 -0.475 27.061 -1.061 L 17.515 -10.607 C 16.929 -11.192 15.979 -11.192 15.393 -10.607 C 14.808 -10.021 14.808 -9.071 15.393 -8.485 L 23.879 0 L 15.393 8.485 C 14.808 9.071 14.808 10.021 15.393 10.607 C 15.979 11.192 16.929 11.192 17.515 10.607 L 27.061 1.061 Z M 0 1.5 L 26 1.5 L 26 -1.5 L 0 -1.5 L 0 1.5 Z"} fill={"#464646"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left rounded-[4px] bg-[#f1f1f1]"} />
          <div className={"absolute left-[49px] top-[37px] w-[26px] h-[0px] box-border origin-top-left"} style={{transform: "matrix(-1,0,-0,-1,0,0)"}}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26 1" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 0 -1.5 C -0.828 -1.5 -1.5 -0.828 -1.5 0 C -1.5 0.828 -0.828 1.5 0 1.5 L 0 -1.5 Z M 27.061 1.061 C 27.646 0.475 27.646 -0.475 27.061 -1.061 L 17.515 -10.607 C 16.929 -11.192 15.979 -11.192 15.393 -10.607 C 14.808 -10.021 14.808 -9.071 15.393 -8.485 L 23.879 0 L 15.393 8.485 C 14.808 9.071 14.808 10.021 15.393 10.607 C 15.979 11.192 16.929 11.192 17.515 10.607 L 27.061 1.061 Z M 0 1.5 L 26 1.5 L 26 -1.5 L 0 -1.5 L 0 1.5 Z"} fill={"#464646"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[0px] top-[2999px] w-[1784px] h-[642px] box-border origin-top-left bg-[#1f1f1f]"} />
      <div className={"absolute left-[114px] top-[3485px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[13px] top-[8px] w-[11px] h-[20px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[11px] h-[20px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11 20" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 11 0 L 12.15 0 C 12.15 -0.635 11.635 -1.15 11 -1.15 L 11 0 Z M 4.465 1.464 L 5.278 2.278 L 5.278 2.278 L 4.465 1.464 Z M 3 8 L 3 9.15 C 3.635 9.15 4.15 8.635 4.15 8 L 3 8 Z M 0 8 L 0 6.85 C -0.635 6.85 -1.15 7.365 -1.15 8 L 0 8 Z M 0 12 L -1.15 12 C -1.15 12.635 -0.635 13.15 0 13.15 L 0 12 Z M 3 12 L 4.15 12 C 4.15 11.365 3.635 10.85 3 10.85 L 3 12 Z M 3 20 L 1.85 20 C 1.85 20.635 2.365 21.15 3 21.15 L 3 20 Z M 7 20 L 7 21.15 C 7.635 21.15 8.15 20.635 8.15 20 L 7 20 Z M 7 12 L 7 10.85 C 6.365 10.85 5.85 11.365 5.85 12 L 7 12 Z M 10 12 L 10 13.15 C 10.528 13.15 10.988 12.791 11.116 12.279 L 10 12 Z M 11 8 L 12.116 8.279 C 12.202 7.935 12.124 7.571 11.906 7.292 C 11.689 7.013 11.354 6.85 11 6.85 L 11 8 Z M 7 8 L 5.85 8 C 5.85 8.635 6.365 9.15 7 9.15 L 7 8 Z M 7.293 4.293 L 6.48 3.48 L 6.48 3.48 L 7.293 4.293 Z M 11 4 L 11 5.15 C 11.635 5.15 12.15 4.635 12.15 4 L 11 4 Z M 11 -1.15 L 8 -1.15 L 8 1.15 L 11 1.15 L 11 -1.15 Z M 8 -1.15 C 6.369 -1.15 4.805 -0.502 3.651 0.651 L 5.278 2.278 C 6 1.556 6.979 1.15 8 1.15 L 8 -1.15 Z M 3.651 0.651 C 2.498 1.805 1.85 3.369 1.85 5 L 4.15 5 C 4.15 3.979 4.556 3 5.278 2.278 L 3.651 0.651 Z M 1.85 5 L 1.85 8 L 4.15 8 L 4.15 5 L 1.85 5 Z M 3 6.85 L 0 6.85 L 0 9.15 L 3 9.15 L 3 6.85 Z M -1.15 8 L -1.15 12 L 1.15 12 L 1.15 8 L -1.15 8 Z M 0 13.15 L 3 13.15 L 3 10.85 L 0 10.85 L 0 13.15 Z M 1.85 12 L 1.85 20 L 4.15 20 L 4.15 12 L 1.85 12 Z M 3 21.15 L 7 21.15 L 7 18.85 L 3 18.85 L 3 21.15 Z M 8.15 20 L 8.15 12 L 5.85 12 L 5.85 20 L 8.15 20 Z M 7 13.15 L 10 13.15 L 10 10.85 L 7 10.85 L 7 13.15 Z M 11.116 12.279 L 12.116 8.279 L 9.884 7.721 L 8.884 11.721 L 11.116 12.279 Z M 11 6.85 L 7 6.85 L 7 9.15 L 11 9.15 L 11 6.85 Z M 8.15 8 L 8.15 5 L 5.85 5 L 5.85 8 L 8.15 8 Z M 8.15 5 C 8.15 5.04 8.134 5.078 8.106 5.106 L 6.48 3.48 C 6.077 3.883 5.85 4.43 5.85 5 L 8.15 5 Z M 8.106 5.106 C 8.078 5.134 8.04 5.15 8 5.15 L 8 2.85 C 7.43 2.85 6.883 3.076 6.48 3.48 L 8.106 5.106 Z M 8 5.15 L 11 5.15 L 11 2.85 L 8 2.85 L 8 5.15 Z M 12.15 4 L 12.15 0 L 9.85 0 L 9.85 4 L 12.15 4 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[176px] top-[3485px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[7px] top-[9px] w-[22.069px] h-[18px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[22.069px] h-[18px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 22.069 18" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 22.069 0.01 L 23.23 0.472 C 23.428 -0.025 23.288 -0.592 22.882 -0.94 C 22.476 -1.287 21.893 -1.338 21.433 -1.066 L 22.069 0.01 Z M 18.919 1.545 L 17.976 2.365 C 18.299 2.736 18.809 2.884 19.28 2.742 L 18.919 1.545 Z M 16.619 0.134 L 16.922 -1.078 L 16.922 -1.078 L 16.619 0.134 Z M 11.81 1.97 L 12.844 2.672 L 12.844 2.672 L 11.81 1.97 Z M 11.034 4.554 L 12.284 4.554 C 12.284 4.549 12.284 4.543 12.284 4.538 L 11.034 4.554 Z M 11.034 5.557 L 11.067 6.807 C 11.744 6.789 12.284 6.235 12.284 5.557 L 11.034 5.557 Z M 5.95 4.419 L 6.512 3.303 L 6.512 3.303 L 5.95 4.419 Z M 2.006 1.013 L 3.029 0.295 C 2.77 -0.074 2.333 -0.275 1.885 -0.231 C 1.437 -0.187 1.047 0.094 0.864 0.506 L 2.006 1.013 Z M 7.022 14.054 L 7.724 15.088 C 8.1 14.833 8.307 14.395 8.267 13.943 C 8.227 13.491 7.944 13.096 7.53 12.912 L 7.022 14.054 Z M 0 16.06 L 0.05 14.811 C -0.529 14.788 -1.047 15.165 -1.204 15.723 C -1.36 16.28 -1.113 16.872 -0.607 17.153 L 0 16.06 Z M 20.063 4.524 L 21.313 4.524 L 21.313 4.52 L 20.063 4.524 Z M 19.982 3.692 L 19.105 2.802 C 18.808 3.095 18.676 3.516 18.755 3.926 L 19.982 3.692 Z M 22.069 0.01 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.432 -1.065 21.431 -1.065 21.429 -1.064 C 21.426 -1.062 21.421 -1.059 21.414 -1.055 C 21.401 -1.047 21.38 -1.035 21.353 -1.019 C 21.299 -0.988 21.219 -0.942 21.119 -0.886 C 20.92 -0.772 20.643 -0.619 20.333 -0.455 C 19.683 -0.112 18.992 0.217 18.559 0.348 L 19.28 2.742 C 19.972 2.533 20.856 2.096 21.5 1.756 C 21.837 1.578 22.136 1.412 22.351 1.29 C 22.459 1.229 22.546 1.179 22.607 1.144 C 22.637 1.126 22.661 1.112 22.678 1.102 C 22.686 1.097 22.692 1.094 22.697 1.091 C 22.699 1.09 22.701 1.089 22.702 1.088 C 22.703 1.087 22.704 1.087 22.704 1.087 C 22.704 1.087 22.704 1.087 22.704 1.087 C 22.705 1.086 22.705 1.086 22.705 1.086 C 22.705 1.086 22.705 1.086 22.069 0.01 Z M 19.862 0.725 C 19.09 -0.163 18.064 -0.793 16.922 -1.078 L 16.316 1.347 C 16.96 1.508 17.54 1.864 17.976 2.365 L 19.862 0.725 Z M 16.922 -1.078 C 15.781 -1.364 14.579 -1.292 13.48 -0.872 L 14.371 1.463 C 14.992 1.226 15.671 1.186 16.316 1.347 L 16.922 -1.078 Z M 13.48 -0.872 C 12.381 -0.453 11.437 0.294 10.776 1.268 L 12.844 2.672 C 13.217 2.122 13.75 1.7 14.371 1.463 L 13.48 -0.872 Z M 10.776 1.268 C 10.115 2.241 9.769 3.394 9.785 4.571 L 12.284 4.538 C 12.275 3.873 12.471 3.222 12.844 2.672 L 10.776 1.268 Z M 9.784 4.554 L 9.784 5.557 L 12.284 5.557 L 12.284 4.554 L 9.784 4.554 Z M 11.002 4.308 C 9.445 4.348 7.903 4.003 6.512 3.303 L 5.388 5.536 C 7.147 6.421 9.098 6.858 11.067 6.807 L 11.002 4.308 Z M 6.512 3.303 C 5.121 2.603 3.924 1.569 3.029 0.295 L 0.983 1.732 C 2.115 3.343 3.628 4.65 5.388 5.536 L 6.512 3.303 Z M 2.006 1.013 C 0.864 0.506 0.864 0.506 0.863 0.507 C 0.863 0.507 0.863 0.508 0.863 0.508 C 0.862 0.509 0.862 0.51 0.861 0.512 C 0.86 0.514 0.859 0.517 0.857 0.521 C 0.854 0.529 0.85 0.538 0.845 0.55 C 0.835 0.574 0.821 0.606 0.805 0.646 C 0.772 0.727 0.728 0.841 0.676 0.984 C 0.573 1.27 0.439 1.676 0.31 2.174 C 0.054 3.163 -0.19 4.546 -0.12 6.086 C -0.05 7.631 0.339 9.359 1.373 10.992 C 2.413 12.634 4.057 14.104 6.514 15.196 L 7.53 12.912 C 5.472 11.997 4.233 10.834 3.485 9.655 C 2.733 8.467 2.432 7.186 2.377 5.972 C 2.322 4.753 2.516 3.628 2.731 2.8 C 2.837 2.388 2.946 2.057 3.027 1.834 C 3.067 1.723 3.1 1.638 3.122 1.585 C 3.133 1.558 3.141 1.539 3.145 1.528 C 3.148 1.523 3.149 1.52 3.15 1.518 C 3.15 1.518 3.15 1.518 3.15 1.518 C 3.15 1.518 3.15 1.519 3.149 1.519 C 3.149 1.519 3.149 1.52 3.149 1.52 C 3.149 1.52 3.149 1.521 2.006 1.013 Z M 6.32 13.02 C 4.475 14.272 2.278 14.9 0.05 14.811 L -0.05 17.309 C 2.712 17.419 5.437 16.641 7.724 15.088 L 6.32 13.02 Z M -0.607 17.153 C 4.253 19.853 9.718 19.884 14.004 17.603 C 18.321 15.305 21.313 10.73 21.313 4.524 L 18.813 4.524 C 18.813 9.855 16.288 13.555 12.83 15.396 C 9.341 17.253 4.776 17.283 0.607 14.968 L -0.607 17.153 Z M 21.313 4.52 C 21.312 4.163 21.277 3.807 21.21 3.457 L 18.755 3.926 C 18.793 4.125 18.812 4.326 18.813 4.528 L 21.313 4.52 Z M 20.86 4.582 C 21.538 3.913 22.139 2.816 22.53 2.027 C 22.738 1.607 22.912 1.221 23.034 0.941 C 23.094 0.801 23.143 0.686 23.176 0.605 C 23.193 0.564 23.206 0.532 23.215 0.51 C 23.22 0.499 23.223 0.49 23.226 0.484 C 23.227 0.48 23.228 0.478 23.229 0.476 C 23.229 0.475 23.23 0.474 23.23 0.473 C 23.23 0.473 23.23 0.473 23.23 0.473 C 23.23 0.473 23.23 0.472 23.23 0.472 C 23.23 0.472 23.23 0.472 22.069 0.01 C 20.907 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.907 -0.452 C 20.907 -0.451 20.907 -0.45 20.906 -0.448 C 20.904 -0.444 20.902 -0.438 20.898 -0.429 C 20.891 -0.412 20.881 -0.386 20.866 -0.351 C 20.838 -0.282 20.795 -0.18 20.74 -0.055 C 20.631 0.198 20.475 0.544 20.29 0.917 C 19.893 1.717 19.451 2.46 19.105 2.802 L 20.86 4.582 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[238px] top-[3485px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[6px] top-[5px] w-[24px] h-[24px] box-border origin-top-left"}>
          <div className={"absolute left-[2px] top-[2px] w-[20px] h-[20px] box-border origin-top-left"}>
            <div className={"absolute left-[5.556px] top-[5.556px] w-[8.889px] h-[8.889px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 8.889 8.889" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 4.444 10.039 C 7.534 10.039 10.039 7.534 10.039 4.444 L 7.739 4.444 C 7.739 6.264 6.264 7.739 4.444 7.739 L 4.444 10.039 Z M 10.039 4.444 C 10.039 1.355 7.534 -1.15 4.444 -1.15 L 4.444 1.15 C 6.264 1.15 7.739 2.625 7.739 4.444 L 10.039 4.444 Z M 4.444 -1.15 C 1.355 -1.15 -1.15 1.355 -1.15 4.444 L 1.15 4.444 C 1.15 2.625 2.625 1.15 4.444 1.15 L 4.444 -1.15 Z M -1.15 4.444 C -1.15 7.534 1.355 10.039 4.444 10.039 L 4.444 7.739 C 2.625 7.739 1.15 6.264 1.15 4.444 L -1.15 4.444 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[20px] h-[20px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 20 20" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 1.25 14.444 L 1.25 5.556 L -1.25 5.556 L -1.25 14.444 L 1.25 14.444 Z M 1.25 5.556 C 1.25 3.178 3.178 1.25 5.556 1.25 L 5.556 -1.25 C 1.797 -1.25 -1.25 1.797 -1.25 5.556 L 1.25 5.556 Z M 5.556 1.25 L 14.444 1.25 L 14.444 -1.25 L 5.556 -1.25 L 5.556 1.25 Z M 14.444 1.25 C 16.822 1.25 18.75 3.178 18.75 5.556 L 21.25 5.556 C 21.25 1.797 18.203 -1.25 14.444 -1.25 L 14.444 1.25 Z M 18.75 5.556 L 18.75 14.444 L 21.25 14.444 L 21.25 5.556 L 18.75 5.556 Z M 18.75 14.444 C 18.75 16.822 16.822 18.75 14.444 18.75 L 14.444 21.25 C 18.203 21.25 21.25 18.203 21.25 14.444 L 18.75 14.444 Z M 14.444 18.75 L 5.556 18.75 L 5.556 21.25 L 14.444 21.25 L 14.444 18.75 Z M 5.556 18.75 C 3.178 18.75 1.25 16.822 1.25 14.444 L -1.25 14.444 C -1.25 18.203 1.797 21.25 5.556 21.25 L 5.556 18.75 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[16.111px] top-[3.888px] w-[0.012px] h-[0.013px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 1 1" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M -0.929 -0.823 C -1.391 -0.31 -1.349 0.48 -0.836 0.942 C -0.323 1.404 0.467 1.362 0.929 0.849 L -0.929 -0.823 Z M 0.941 0.836 C 1.403 0.323 1.361 -0.467 0.848 -0.929 C 0.335 -1.391 -0.456 -1.349 -0.917 -0.836 L 0.941 0.836 Z M 0.929 0.849 L 0.941 0.836 L -0.917 -0.836 L -0.929 -0.823 L 0.929 0.849 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[300px] top-[3485px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[7px] top-[7px] w-[22px] h-[22px] box-border origin-top-left overflow-hidden"}>
          <div className={"absolute left-[0px] top-[0px] w-[22px] h-[22px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/d3113ae5d38f42325172d25ee512520ef84dd396.webp')"}} />
          <div className={"absolute left-[-3px] top-[-3px] w-[28px] h-[28px] box-border origin-top-left bg-[#ffffff]"} />
        </div>
      </div>
      <div className={"absolute left-[127px] top-[3223px] w-[251px] h-[62.807px] box-border origin-top-left"}>
        <div className={"absolute left-[211.506px] top-[14.144px] w-[5.21px] h-[28.287px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 5.21 28.287" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 5.21 0 L 0 0 L 0 28.287 L 5.21 28.287 L 5.21 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[251px] h-[62.807px] box-border origin-top-left"}>
          <div className={"absolute left-[175.12px] top-[14.144px] w-[29.915px] h-[28.367px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 29.915 28.367" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 14.957 21.016 L 24.705 11.666 L 24.705 28.367 L 29.915 28.367 L 29.915 0 L 14.957 14.463 L 0 0 L 0 28.367 L 5.126 28.367 L 5.126 11.666 L 14.957 21.016 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[0px] top-[0px] w-[251px] h-[62.807px] box-border origin-top-left"}>
            <div className={"absolute left-[222.345px] top-[14.144px] w-[28.655px] h-[28.287px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 28.655 28.287" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 23.445 13.025 C 23.445 8.55 19.579 4.954 14.957 4.954 L 5.21 4.954 L 5.21 23.413 L 14.957 23.413 C 19.663 23.413 23.445 19.737 23.445 15.342 L 23.445 13.105 L 23.445 13.025 Z M 0 4.954 L 0 0 L 14.957 0 C 22.52 0 28.655 5.833 28.655 13.025 L 28.655 15.262 C 28.655 22.454 22.52 28.287 14.957 28.287 L 0 28.287 L 0 4.874 L 0 4.954 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[139.071px] top-[14.224px] w-[31.343px] h-[28.287px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 31.343 28.287" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 31.343 14.144 C 31.343 6.313 24.621 0 16.47 0 L 14.873 0 C 6.722 0 0 6.393 0 14.144 C 0 21.895 6.722 28.287 14.873 28.287 L 16.47 28.287 C 24.705 28.287 31.343 21.895 31.343 14.144 Z M 15.714 4.315 C 21.344 4.315 25.966 8.71 25.966 14.064 C 25.966 19.417 21.344 23.812 15.714 23.812 C 10.084 23.812 5.462 19.417 5.462 14.064 C 5.462 8.71 10.084 4.315 15.714 4.315 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[107.895px] top-[14.224px] w-[27.394px] h-[28.287px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 27.394 28.287" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 20.672 28.287 L 27.394 28.287 L 19.075 18.938 C 20.167 18.698 21.26 18.379 22.184 17.899 C 25.293 16.301 27.394 13.105 27.394 9.589 C 27.394 4.315 22.856 0 17.31 0 L 0 0 L 0 28.287 L 5.126 28.287 L 5.126 4.874 L 17.31 4.874 C 19.999 4.874 22.184 6.952 22.184 9.509 C 22.184 12.066 19.999 14.144 17.31 14.144 L 8.067 14.144 L 12.437 19.018 L 20.672 28.207 L 20.672 28.287 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[250.916px] h-[62.807px] box-border origin-top-left"}>
              <div className={"absolute left-[57.561px] top-[14.144px] w-[23.781px] h-[28.367px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 23.781 28.367" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 0 0 L 23.781 0 L 20.756 4.954 L 5.126 4.954 L 5.126 11.746 L 18.655 11.746 L 16.218 16.621 L 5.126 16.621 L 5.126 19.897 L 5.126 23.413 L 5.126 28.367 L 0 28.367 L 0 16.621 L 0 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[0px] top-[0px] w-[49.998px] h-[54.976px] box-border origin-top-left"}>
                <div className={"absolute left-[0px] top-[0px] w-[34.453px] h-[46.106px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 34.453 46.106" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 9.495 46.106 L 0 41.072 L 0 13.584 L 25.377 0 L 34.453 5.034 L 9.495 19.178 L 9.495 46.106 Z"} fill={"#ffffff"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[20.755px] top-[10.947px] w-[29.243px] h-[44.029px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 29.243 44.029" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 23.413 L 0 13.424 L 24.369 0 L 29.243 2.637 L 29.243 30.365 L 4.202 44.029 L 0 41.552 L 0 35.878 L 19.999 24.851 L 19.831 12.625 L 0 23.413 Z"} fill={"#ec1c24"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
              <div className={"absolute left-[74.955px] top-[14.144px] w-[30.419px] h-[28.367px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 30.419 28.367" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 15.21 0 L 0 28.367 L 5.546 28.367 L 15.21 10.308 L 24.873 28.367 L 30.419 28.367 L 15.21 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[143.609px] top-[49.303px] w-[107.307px] h-[13.504px] box-border origin-top-left"}>
                <div className={"absolute left-[0px] top-[0.08px] w-[12.689px] h-[13.424px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 12.689 13.424" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 12.689 13.185 L 10.504 13.185 C 10.42 12.785 10.336 12.306 10.252 11.906 C 9.495 12.865 8.151 13.424 6.218 13.424 C 2.269 13.424 0 10.548 0 6.872 C 0 3.196 2.353 0 6.722 0 C 11.092 0 12.353 1.918 12.605 4.075 L 9.664 4.075 C 9.411 3.196 8.655 2.157 6.638 2.157 C 4.622 2.157 3.025 4.395 3.025 6.712 C 3.025 9.029 3.949 11.187 6.638 11.187 C 9.327 11.187 9.664 9.509 9.664 8.39 C 9.664 8.31 6.638 8.31 6.638 8.31 L 6.638 5.993 L 12.521 5.993 L 12.521 13.265 L 12.689 13.185 Z"} fill={"#0d1633"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[25.377px] top-[0.24px] w-[10.588px] h-[13.025px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 10.588 13.025" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 2.857 7.831 L 2.857 13.025 L 0 13.025 L 0 0 L 5.966 0 C 8.907 0 10.588 1.598 10.588 3.596 C 10.588 5.593 9.579 6.313 8.571 6.632 C 9.243 6.872 10.252 7.511 10.252 9.829 L 10.252 10.468 C 10.252 11.347 10.252 12.306 10.42 12.945 L 7.647 12.945 C 7.395 12.386 7.395 11.427 7.395 9.988 L 7.395 9.829 C 7.395 8.39 7.059 7.751 4.79 7.751 L 2.857 7.751 L 2.857 7.831 Z M 2.857 5.593 L 5.294 5.593 C 6.891 5.593 7.563 5.034 7.563 3.915 C 7.563 2.797 6.806 2.237 5.378 2.237 L 2.857 2.237 L 2.857 5.593 Z"} fill={"#0d1633"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[47.309px] top-[0px] w-[13.277px] h-[13.424px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 13.277 13.424" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 13.277 6.712 C 13.277 10.308 11.008 13.424 6.554 13.424 C 2.101 13.424 0 10.468 0 6.712 C 0 2.957 2.521 0 6.722 0 C 10.924 0 13.277 2.637 13.277 6.632 L 13.277 6.712 Z M 3.109 6.712 C 3.109 9.269 4.286 11.187 6.722 11.187 C 9.159 11.187 10.252 9.109 10.252 6.792 C 10.252 4.475 9.159 2.397 6.638 2.397 C 4.118 2.397 3.109 4.235 3.109 6.712 Z"} fill={"#0d1633"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[72.771px] top-[0.24px] w-[11.428px] h-[13.185px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.428 13.185" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 2.857 0 L 2.857 7.751 C 2.857 10.228 4.202 10.947 5.714 10.947 C 7.227 10.947 8.487 10.068 8.487 7.751 L 8.487 0 L 11.428 0 L 11.428 7.591 C 11.428 12.066 8.655 13.185 5.714 13.185 C 2.773 13.185 0 11.986 0 7.671 L 0 0 L 2.941 0 L 2.857 0 Z"} fill={"#0d1633"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[96.804px] top-[0.24px] w-[10.504px] h-[13.025px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 10.504 13.025" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 0 L 5.63 0 C 8.571 0 10.504 1.518 10.504 3.995 C 10.504 6.472 8.235 8.151 5.546 8.151 L 2.941 8.151 L 2.941 13.025 L 0 13.025 L 0 0 Z M 2.941 5.913 L 5.21 5.913 C 6.554 5.913 7.563 5.434 7.563 4.075 C 7.563 2.717 6.554 2.237 5.294 2.237 L 2.941 2.237 L 2.941 5.913 Z"} fill={"#0d1633"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[1525px] top-[3255px] w-[90px] h-[25px] box-border origin-top-left text-[#ffffff] text-[20px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"تماس با ما"}
      </div>
      <div className={"absolute left-[984px] top-[3254px] w-[63px] h-[25px] box-border origin-top-left text-[#ffffff] text-[20px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"پیوندها"}
      </div>
      <div className={"absolute left-[1170px] top-[3302px] w-[452px] h-[18px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"آدرس کارخانه: کیلومتر 20 جاده خاوران، روبروی فرون آباد اول، کوچه صاحب الزمان"}
      </div>
      <div className={"absolute left-[1124px] top-[3333px] w-[491px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"آدرس دفترمرکزی و شوروم :  اتوبان ارتش. اقدسیه. اراج. نبش اراج. ساختمان نگین پلاک 156"}
      </div>
      <div className={"absolute left-[1359px] top-[3371px] w-[256px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"شماره تماس دفترمرکزی و شورم :  02178328000"}
      </div>
      <div className={"absolute left-[1439px] top-[3409px] w-[176px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"فکس دفتر مرکزی :  02122823107"}
      </div>
      <div className={"absolute left-[1392px] top-[3447px] w-[223px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"شماره تماس : 02136849085 - 02136849086"}
      </div>
      <div className={"absolute left-[1509px] top-[3485px] w-[106px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"فکس : 02136849474"}
      </div>
      <div className={"absolute left-[1463px] top-[3523px] w-[152px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"ایمیل :     info@faromid.com"}
      </div>
      <div className={"absolute left-[784px] top-[3302px] w-[276px] h-[170px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"صنایع چوب ایران\nاتحادیه تولید کنندگان و صادر کنندگان مبل ایران\nتعاونی فرآورده های چوبی\n انجمن روکش های مصنوعی\nشورای ملی مبلمان\nگمرک جمهوری اسلامی ایران\nوزارت صنعت ، معدن و تجارت\nاستاندارد ایران\nسامانه جامع تجارت\nبانک مرکزی      "}
      </div>
      <div className={"absolute left-[611px] top-[3304px] w-[132px] h-[153px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"اتاق بازرگانی\nاتاق بازرگانی ایران\nاتاق بازرگانی آلمان\nاتاق بازرگانی ایتالیا\n اتاق بازرگانی اتریش\nاتاق بازرگانی چین\nبهین یاب\nمیانگین موزون سنا\nبازار طلا و ارز"}
      </div>
      <div className={"absolute left-[1174px] top-[3271.5px] w-[348px] h-[0px] box-border origin-top-left"}>
        <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 348 1" preserveAspectRatio="none" className="block overflow-visible">
          <path d={"M 348 -1 L 0 -1 L 0 1 L 348 1 L 348 -1 Z"} fill={"#ff0000"} fillRule="nonzero" />
        </svg>
      </div>
      <div className={"absolute left-[127px] top-[3304px] w-[250px] h-[40px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-center [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"فرامید تولید کننده ام دی اف دورو سینکرونایز، \nفوق برجسته و سوپر مات-آنتی فینگر"}
      </div>
      <div className={"absolute left-[75px] top-[532px] w-[750px] h-[479.381px] box-border origin-top-left overflow-hidden"}>
        <div className={"absolute left-[0px] top-[0px] w-[750px] h-[479.381px] box-border origin-top-left bg-[#d9d9d9]"} />
        <div className={"absolute left-[-5.776px] top-[0px] w-[747.112px] h-[471.649px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/952e714f21d848a4f43100af707fad703479183e.webp')"}} />
      </div>
      <div className={"absolute left-[906px] top-[1837px] w-[752.899px] h-[479.381px] box-border origin-top-left overflow-hidden"}>
        <div className={"absolute left-[0px] top-[0px] w-[752.899px] h-[479.381px] box-border origin-top-left bg-[#d9d9d9]"} />
        <div className={"absolute left-[-3px] top-[-4px] w-[750px] h-[471.649px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/952e714f21d848a4f43100af707fad703479183e.webp')"}} />
      </div>
      <div className={"absolute left-[922px] top-[527px] w-[737.436px] h-[469.535px] box-border origin-top-left overflow-hidden"}>
        <div className={"absolute left-[0px] top-[0px] w-[737.436px] h-[469.535px] box-border origin-top-left bg-[#d9d9d9]"} />
        <div className={"absolute left-[-29.116px] top-[-98.451px] w-[814.319px] h-[687.832px] box-border origin-top-left overflow-hidden"}>
          <div className={"absolute left-[0px] top-[0px] w-[814.319px] h-[687.832px] box-border origin-top-left bg-[#d9d9d9]"} />
          <div className={"absolute left-[0px] top-[-52.712px] w-[814.319px] h-[807.399px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/54599740ae5947f5499c6cec10768e77c692aa33.webp')"}} />
        </div>
      </div>
      <div className={"absolute left-[75px] top-[1184px] w-[750px] h-[470px] box-border origin-top-left overflow-hidden"}>
        <div className={"absolute left-[0px] top-[0px] w-[750px] h-[470px] box-border origin-top-left bg-[#d9d9d9]"} />
        <div className={"absolute left-[-11px] top-[-247px] w-[777px] h-[1089px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/b9b8b19e05859645385b0b841d5112546ac6d38e.webp')"}} />
      </div>
      <div className={"absolute left-[922px] top-[1184px] w-[737px] h-[470px] box-border origin-top-left overflow-hidden"}>
        <div className={"absolute left-[0px] top-[0px] w-[737px] h-[470px] box-border origin-top-left bg-[#d9d9d9]"} />
        <div className={"absolute left-[-25.549px] top-[-150px] w-[765.497px] h-[896px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/784e31d97a69752e46d950511d73fe486e26d3d4.webp')"}} />
      </div>
      <div className={"absolute left-[123px] top-[1023.381px] w-[179px] h-[69px] box-border origin-top-left text-[#ffffff] text-[24px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:ltr]"}>
        {"G2LAB\nMonalia Hotel"}
      </div>
      <div className={"absolute left-[119px] top-[1676px] w-[179px] h-[69px] box-border origin-top-left text-[#ffffff] text-[24px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:ltr]"}>
        {"G2LAB\nMonalia Hotel"}
      </div>
      <div className={"absolute left-[895px] top-[2339px] w-[179px] h-[69px] box-border origin-top-left text-[#ffffff] text-[24px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:ltr]"}>
        {"G2LAB\nMonalia Hotel"}
      </div>
      <div className={"absolute left-[914px] top-[1026.381px] w-[321px] h-[63px] box-border origin-top-left text-[#ffffff] text-[24px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:ltr]"}>
        {"Studio Arketo\nRistorante ExMahalo"}
      </div>
      <div className={"absolute left-[912px] top-[1676px] w-[321px] h-[63px] box-border origin-top-left text-[#ffffff] text-[24px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:ltr]"}>
        {"Studio Arketo\nRistorante ExMahalo"}
      </div>
      <div className={"absolute left-[91px] top-[2339px] w-[321px] h-[63px] box-border origin-top-left text-[#ffffff] text-[24px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:ltr]"}>
        {"Studio Arketo\nRistorante ExMahalo"}
      </div>
      <div className={"absolute left-[75px] top-[1837px] w-[750px] h-[468px] box-border origin-top-left overflow-hidden"}>
        <div className={"absolute left-[0px] top-[0px] w-[750px] h-[468px] box-border origin-top-left bg-[#d9d9d9]"} />
        <div className={"absolute left-[-7.853px] top-[-34px] w-[755.89px] h-[730px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/gallery/7d5fd5f606bf882f577d870419f52b8fc626ed5a.webp')"}} />
      </div>
      <div className={"absolute left-[143px] top-[78.541px] w-[229.771px] h-[60.553px] box-border origin-top-left"}>
        <div className={"absolute left-[52.759px] top-[13.639px] w-[21.733px] h-[27.279px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 21.733 27.279" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 0 0 L 21.733 0 L 19.035 4.796 L 4.646 4.796 L 4.646 11.241 L 17.087 11.241 L 14.838 16.037 L 4.646 16.037 L 4.646 19.185 L 4.646 22.482 L 4.646 27.279 L 0 27.279 L 0 16.037 L 0 0 Z"} fill={"#fdfdff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[45.715px] h-[52.909px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[31.625px] h-[44.365px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 31.625 44.365" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 8.693 44.365 L 0 39.569 L 0 13.19 L 23.232 0 L 31.625 4.946 L 8.693 18.436 L 8.693 44.365 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[19.036px] top-[10.492px] w-[26.679px] h-[42.417px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26.679 42.417" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 0 22.632 L 0 13.04 L 22.333 0 L 26.679 2.698 L 26.679 29.377 L 3.897 42.417 L 0 40.019 L 0 34.623 L 18.286 23.981 L 18.136 12.29 L 0 22.632 Z"} fill={"#ec1c24"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
        <div className={"absolute left-[203.391px] top-[13.639px] w-[26.23px] h-[27.429px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26.23 27.429" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 21.583 12.59 C 21.583 8.393 18.136 4.796 13.789 4.796 L 4.796 4.796 L 4.796 22.632 L 13.789 22.632 C 18.136 22.632 21.583 19.185 21.583 14.838 L 21.583 12.59 Z M 0 4.796 L 0 0 L 13.639 0 C 20.534 0 26.23 5.696 26.23 12.59 L 26.23 14.838 C 26.23 21.733 20.534 27.429 13.639 27.429 L 0 27.429 L 0 4.946 L 0 4.796 Z"} fill={"#fdfdff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[193.498px] top-[13.639px] w-[4.796px] h-[27.279px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 4.796 27.279" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 4.796 0 L 0 0 L 0 27.279 L 4.796 27.279 L 4.796 0 Z"} fill={"#fdfdff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[160.225px] top-[13.639px] w-[27.429px] h-[27.279px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 27.429 27.279" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 13.789 20.234 L 22.632 11.241 L 22.632 27.279 L 27.429 27.279 L 27.429 0 L 13.789 13.939 L 0 0 L 0 27.279 L 4.796 27.279 L 4.796 11.241 L 13.789 20.234 Z"} fill={"#fdfdff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[127.252px] top-[13.639px] w-[28.778px] h-[27.279px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 28.778 27.279" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 28.778 13.639 C 28.778 6.145 22.632 0 15.138 0 L 13.639 0 C 6.145 0 0 6.145 0 13.639 C 0 21.133 6.145 27.279 13.639 27.279 L 15.138 27.279 C 22.632 27.279 28.778 21.133 28.778 13.639 Z M 14.389 4.197 C 19.485 4.197 23.682 8.393 23.682 13.639 C 23.682 18.885 19.485 22.932 14.389 22.932 C 9.293 22.932 4.946 18.735 4.946 13.639 C 4.946 8.543 9.143 4.197 14.389 4.197 Z"} fill={"#fdfdff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[68.646px] top-[13.639px] w-[27.728px] h-[27.279px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 27.728 27.279" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 13.939 0 L 0 27.279 L 5.096 27.279 L 13.939 9.892 L 22.782 27.279 L 27.728 27.279 L 13.939 0 Z"} fill={"#fdfdff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[98.774px] top-[13.789px] w-[25.03px] h-[27.279px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 25.03 27.279" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 18.885 27.129 L 25.03 27.129 L 17.386 18.136 C 18.436 17.986 19.335 17.536 20.234 17.087 C 23.082 15.588 25.03 12.44 25.03 9.143 C 25.03 4.047 20.834 0 15.888 0 L 0 0 L 0 27.279 L 4.646 27.279 L 4.646 4.796 L 15.738 4.796 C 18.136 4.796 20.234 6.745 20.234 9.293 C 20.234 11.841 18.286 13.789 15.738 13.789 L 7.344 13.789 L 11.391 18.436 L 18.885 27.279 L 18.885 27.129 Z"} fill={"#fdfdff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[131.747px] top-[47.513px] w-[98.024px] h-[13.04px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0.15px] w-[11.541px] h-[12.89px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.541 12.89" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 11.391 12.59 L 9.443 12.59 C 9.443 12.141 9.293 11.841 9.293 11.391 C 8.543 12.29 7.344 12.89 5.696 12.89 C 2.098 12.89 0 10.192 0 6.595 C 0 2.998 2.248 0 6.145 0 C 10.042 0 11.241 1.799 11.541 3.897 L 8.843 3.897 C 8.543 2.998 7.944 2.098 6.145 2.098 C 4.347 2.098 2.848 4.197 2.848 6.445 C 2.848 8.693 3.747 10.792 6.145 10.792 C 8.543 10.792 8.843 9.143 8.843 8.094 L 6.145 8.094 L 6.145 5.845 L 11.541 5.845 L 11.541 12.89 L 11.391 12.59 Z"} fill={"#a8a8a8"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[22.783px] top-[0.15px] w-[9.742px] h-[12.59px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 9.742 12.59" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 2.698 7.494 L 2.698 12.44 L 0 12.44 L 0 0 L 5.546 0 C 8.244 0 9.742 1.499 9.742 3.447 C 9.742 5.396 8.843 5.995 7.944 6.445 C 8.543 6.745 9.443 7.344 9.443 9.593 L 9.443 10.192 C 9.443 11.091 9.443 11.991 9.592 12.59 L 7.044 12.59 C 6.895 11.991 6.745 11.091 6.745 9.742 C 6.745 8.244 6.445 7.494 4.347 7.494 L 2.548 7.494 L 2.698 7.494 Z M 2.698 5.396 L 4.946 5.396 C 6.445 5.396 7.044 4.796 7.044 3.747 C 7.044 2.698 6.445 2.098 5.096 2.098 L 2.698 2.098 L 2.698 5.246 L 2.698 5.396 Z"} fill={"#a8a8a8"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[43.017px] top-[0px] w-[12.14px] h-[12.89px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 12.14 12.89" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 12.14 6.445 C 12.14 9.892 10.042 12.89 5.995 12.89 C 1.948 12.89 0 10.042 0 6.445 C 0 2.848 2.248 0 6.145 0 C 10.042 0 12.14 2.548 12.14 6.445 Z M 2.848 6.445 C 2.848 8.843 3.897 10.792 6.145 10.792 C 8.393 10.792 9.443 8.843 9.443 6.595 C 9.443 4.347 8.543 2.398 6.145 2.398 C 3.747 2.398 2.848 4.197 2.848 6.595 L 2.848 6.445 Z"} fill={"#a8a8a8"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[66.098px] top-[0.15px] w-[10.492px] h-[12.74px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 10.492 12.74" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 2.698 0 L 2.698 7.494 C 2.698 9.892 3.897 10.642 5.246 10.642 C 6.595 10.642 7.794 9.742 7.794 7.494 L 7.794 0 L 10.492 0 L 10.492 7.344 C 10.492 11.691 7.944 12.74 5.246 12.74 C 2.548 12.74 0 11.541 0 7.494 L 0 0.15 L 2.698 0.15 L 2.698 0 Z"} fill={"#a8a8a8"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[88.282px] top-[0.15px] w-[9.742px] h-[12.44px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 9.742 12.44" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 0 0 L 5.246 0 C 7.944 0 9.742 1.499 9.742 3.897 C 9.742 6.295 7.644 7.794 5.246 7.794 L 2.848 7.794 L 2.848 12.44 L 0.15 12.44 L 0.15 0 L 0 0 Z M 2.698 5.696 L 4.796 5.696 C 5.995 5.696 6.895 5.246 6.895 3.897 C 6.895 2.548 5.995 2.098 4.796 2.098 L 2.698 2.098 L 2.698 5.696 Z"} fill={"#a8a8a8"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[806px] top-[296px] w-[116px] h-[54px] box-border origin-top-left text-[#ffffff] text-[36px] font-[600] text-justify [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"پروژه ها"}
      </div>
      {/* Native accessible navigation and interactive regions */}
      <Link href="/" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[90px] top-[60px] w-[300px] h-[100px]" aria-label="صفحه اصلی فرامید" />
      <Link href={"/"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1501px] top-[89px] w-[118px] h-[40px]" aria-label={"صفحه اصلی"} />
      <Link href={"/products"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1368px] top-[91px] w-[105px] h-[40px]" aria-label={"محصولات"} />
      <Link href={"/about"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[858px] top-[90px] w-[84px] h-[40px]" aria-label={"درباره ما"} />
      <Link href={"/contact"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[575px] top-[94px] w-[107px] h-[40px]" aria-label={"تماس با ما"} />
      <Link href={"/careers"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[710px] top-[91px] w-[120px] h-[40px]" aria-label={"همکاری با ما"} />
      <Link href={"/exhibitions"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[970px] top-[93px] w-[113px] h-[40px]" aria-label={"نمایشگاه ها"} />
      <Link href={"/textures"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1272px] top-[83px] w-[72px] h-[52px]" aria-label={"تکسچر"} />
      <Link href={"/gallery"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1110px] top-[91px] w-[120px] h-[40px]" aria-label={"گالری تصاویر"} />
      <button type="button" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_0_0_3px_rgba(237,28,36,0.65)] left-[69.224px] top-[532px] w-[747.112px] h-[471.649px]" aria-label={"بزرگ‌نمایی modern-luxury-kitchen-interior-design-minimal-style_455177-70 2"} onClick={() => onOpenImage("/assets/home/952e714f21d848a4f43100af707fad703479183e.webp")} />
      <button type="button" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_0_0_3px_rgba(237,28,36,0.65)] left-[903px] top-[1833px] w-[750px] h-[471.649px]" aria-label={"بزرگ‌نمایی modern-luxury-kitchen-interior-design-minimal-style_455177-70 2"} onClick={() => onOpenImage("/assets/home/952e714f21d848a4f43100af707fad703479183e.webp")} />
      <button type="button" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_0_0_3px_rgba(237,28,36,0.65)] left-[892.884px] top-[375.837px] w-[814.319px] h-[807.399px]" aria-label={"بزرگ‌نمایی The-contemporary-island-in-this-kitchen-surrounded-by-stylish-bar-stools-adds-flair-to-the-home 1"} onClick={() => onOpenImage("/assets/home/54599740ae5947f5499c6cec10768e77c692aa33.webp")} />
      <button type="button" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_0_0_3px_rgba(237,28,36,0.65)] left-[64px] top-[937px] w-[777px] h-[1089px]" aria-label={"بزرگ‌نمایی 389b68d23f0858189c54d51d56518ea4 2"} onClick={() => onOpenImage("/assets/home/b9b8b19e05859645385b0b841d5112546ac6d38e.webp")} />
      <button type="button" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_0_0_3px_rgba(237,28,36,0.65)] left-[896.451px] top-[1034px] w-[765.497px] h-[896px]" aria-label={"بزرگ‌نمایی 7c8a03394bc83199f9e0bb02e4d05a6d 1"} onClick={() => onOpenImage("/assets/home/784e31d97a69752e46d950511d73fe486e26d3d4.webp")} />
      <button type="button" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_0_0_3px_rgba(237,28,36,0.65)] left-[67.147px] top-[1803px] w-[755.89px] h-[730px]" aria-label={"بزرگ‌نمایی 3131744c831f4adb1cce0b9f4fcb6e03 1"} onClick={() => onOpenImage("/assets/gallery/7d5fd5f606bf882f577d870419f52b8fc626ed5a.webp")} />
    </>
  );
}
