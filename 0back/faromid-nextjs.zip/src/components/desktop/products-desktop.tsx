"use client";
/* Pure JSX component. Desktop geometry and media are authored at build time,
 * so no design JSON, layout interpreter or external design service is used.
 * The absolute utility classes intentionally preserve the legacy pixel-perfect artwork. */
import Image from 'next/image';
import Link from 'next/link';
import {DesktopArtboardProductCarousel} from '@/components/product-carousel';

export function ProductsDesktop({onOpenImage}:{onOpenImage:(src:string)=>void}) {
  return (
    <>
      {/* Static Tailwind-rendered desktop artwork */}
      <div className={"absolute left-[-226px] top-[-90px] w-[2092px] h-[941px] box-border origin-top-left overflow-hidden"}>
        <div className={"absolute left-[0px] top-[0px] w-[2092px] h-[941px] box-border origin-top-left bg-[#d9d9d9]"} />
        <div className={"absolute left-[114.184px] top-[-336.969px] w-[1863.632px] h-[1863.632px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/backgrounds/b64de2f4b544c1901affa3f8dce63e6f47283ee7.webp')"}} />
      </div>
      <div className={"absolute left-[-2px] top-[836px] w-[1729px] h-[4464px] box-border origin-top-left bg-[#e5e5e5]"} />
      <div className={"absolute left-[720px] top-[916px] w-[288px] h-[39px] box-border origin-top-left text-[#353434] text-[32px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"محصولات آنتی فینگر"}
      </div>
      <div className={"absolute left-[893px] top-[1742px] w-[349px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
      <div className={"absolute left-[894px] top-[2446px] w-[349px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
      <div className={"absolute left-[1314px] top-[1742px] w-[338px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
      <div className={"absolute left-[1313px] top-[2446px] w-[338px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
      <div className={"absolute left-[487px] top-[1742px] w-[338px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
      <div className={"absolute left-[487px] top-[2446px] w-[338px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
      <div className={"absolute left-[81px] top-[1742px] w-[341px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
      <div className={"absolute left-[76px] top-[2448px] w-[341px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
      <div className={"absolute left-[1427px] top-[2139px] w-[207px] h-[98px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[3px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"CLEAN TOUCH"}
        </div>
        <div className={"absolute left-[115px] top-[38px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"7185"}
        </div>
        <div className={"absolute left-[65px] top-[74px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"121*228"}
        </div>
        <div className={"absolute left-[150px] top-[0px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"مدل:"}
        </div>
        <div className={"absolute left-[148px] top-[74px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"ابعاد:"}
        </div>
        <div className={"absolute left-[167px] top-[38px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"کد:"}
        </div>
        <div className={"absolute left-[197px] top-[10px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[197px] top-[48px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[198px] top-[84px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      </div>
      <div className={"absolute left-[1541px] top-[2881px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"7185"}
      </div>
      <div className={"absolute left-[1491px] top-[2917px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"121*228"}
      </div>
      <div className={"absolute left-[1576px] top-[2843px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"مدل:"}
      </div>
      <div className={"absolute left-[1574px] top-[2917px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"ابعاد:"}
      </div>
      <div className={"absolute left-[1593px] top-[2881px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"کد:"}
      </div>
      <div className={"absolute left-[1623px] top-[2853px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[1623px] top-[2891px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[1624px] top-[2927px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[1015px] top-[2142px] w-[206px] h-[98px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[3px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"CLEAN TOUCH"}
        </div>
        <div className={"absolute left-[114px] top-[38px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"7185"}
        </div>
        <div className={"absolute left-[65px] top-[74px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"121*228"}
        </div>
        <div className={"absolute left-[149px] top-[0px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"مدل:"}
        </div>
        <div className={"absolute left-[147px] top-[74px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"ابعاد:"}
        </div>
        <div className={"absolute left-[166px] top-[38px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"کد:"}
        </div>
        <div className={"absolute left-[196px] top-[10px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[196px] top-[48px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[197px] top-[84px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      </div>
      <div className={"absolute left-[1016px] top-[2849px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"CLEAN TOUCH"}
      </div>
      <div className={"absolute left-[1130px] top-[2884px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"7185"}
      </div>
      <div className={"absolute left-[1081px] top-[2920px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"121*228"}
      </div>
      <div className={"absolute left-[1165px] top-[2846px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"مدل:"}
      </div>
      <div className={"absolute left-[1163px] top-[2920px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"ابعاد:"}
      </div>
      <div className={"absolute left-[1182px] top-[2884px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"کد:"}
      </div>
      <div className={"absolute left-[1224px] top-[2856px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[1224px] top-[2894px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[1225px] top-[2930px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[593px] top-[2142px] w-[207px] h-[98px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[3px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"CLEAN TOUCH"}
        </div>
        <div className={"absolute left-[116px] top-[38px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"7185"}
        </div>
        <div className={"absolute left-[66px] top-[74px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"121*228"}
        </div>
        <div className={"absolute left-[150px] top-[0px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"مدل:"}
        </div>
        <div className={"absolute left-[148px] top-[74px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"ابعاد:"}
        </div>
        <div className={"absolute left-[167px] top-[38px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"کد:"}
        </div>
        <div className={"absolute left-[197px] top-[10px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[197px] top-[48px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[198px] top-[84px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      </div>
      <div className={"absolute left-[593px] top-[2849px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"CLEAN TOUCH"}
      </div>
      <div className={"absolute left-[709px] top-[2884px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"7185"}
      </div>
      <div className={"absolute left-[659px] top-[2920px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"121*228"}
      </div>
      <div className={"absolute left-[743px] top-[2846px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"مدل:"}
      </div>
      <div className={"absolute left-[741px] top-[2920px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"ابعاد:"}
      </div>
      <div className={"absolute left-[760px] top-[2884px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"کد:"}
      </div>
      <div className={"absolute left-[790px] top-[2856px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[790px] top-[2894px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[791px] top-[2930px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[187px] top-[2137px] w-[207px] h-[98px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[3px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"CLEAN TOUCH"}
        </div>
        <div className={"absolute left-[115px] top-[38px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"7185"}
        </div>
        <div className={"absolute left-[65px] top-[74px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"121*228"}
        </div>
        <div className={"absolute left-[150px] top-[0px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"مدل:"}
        </div>
        <div className={"absolute left-[148px] top-[74px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"ابعاد:"}
        </div>
        <div className={"absolute left-[167px] top-[38px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"کد:"}
        </div>
        <div className={"absolute left-[197px] top-[10px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[197px] top-[48px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[198px] top-[84px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      </div>
      <div className={"absolute left-[166px] top-[2846px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"CLEAN TOUCH"}
      </div>
      <div className={"absolute left-[281px] top-[2881px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"7185"}
      </div>
      <div className={"absolute left-[247px] top-[2917px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"121*228"}
      </div>
      <div className={"absolute left-[332px] top-[2843px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"مدل:"}
      </div>
      <div className={"absolute left-[330px] top-[2917px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"ابعاد:"}
      </div>
      <div className={"absolute left-[349px] top-[2881px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"کد:"}
      </div>
      <div className={"absolute left-[379px] top-[2853px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[379px] top-[2891px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[380px] top-[2927px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
      <div className={"absolute left-[76px] top-[858px] w-[367px] h-[687px] box-border origin-top-left"}>
        <div className={"absolute left-[1px] top-[173px] w-[341px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
        <div className={"absolute left-[107px] top-[571px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"CLEAN TOUCH"}
        </div>
        <div className={"absolute left-[222px] top-[606px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"7185"}
        </div>
        <div className={"absolute left-[172px] top-[642px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
          {"121*228"}
        </div>
        <div className={"absolute left-[257px] top-[568px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"مدل:"}
        </div>
        <div className={"absolute left-[255px] top-[642px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"ابعاد:"}
        </div>
        <div className={"absolute left-[274px] top-[606px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
          {"کد:"}
        </div>
        <div className={"absolute left-[304px] top-[578px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[304px] top-[616px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[305px] top-[652px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        <div className={"absolute left-[0px] top-[0px] w-[367px] h-[652px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/54c9bd196212361d4e1686d4b54de2b42613e3a0.webp')"}} />
      </div>
      <div className={"absolute left-[74px] top-[1557px] w-[370.688px] h-[659px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/54c9bd196212361d4e1686d4b54de2b42613e3a0.webp')"}} />
      <div className={"absolute left-[69px] top-[2263px] w-[370.688px] h-[659px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/54c9bd196212361d4e1686d4b54de2b42613e3a0.webp')"}} />
      <div className={"absolute left-[459px] top-[2256px] w-[375.75px] h-[668px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/ad6ca4d4a677ae16d2d92698df8690b2fd7b7438.webp')"}} />
      <div className={"absolute left-[891px] top-[822px] w-[404px] h-[723px] box-border origin-top-left"}>
        <div className={"absolute left-[4px] top-[209px] w-[349px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
        <div className={"absolute left-[132px] top-[609px] w-[206px] h-[98px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[3px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"CLEAN TOUCH"}
          </div>
          <div className={"absolute left-[114px] top-[38px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"7185"}
          </div>
          <div className={"absolute left-[65px] top-[74px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"121*228"}
          </div>
          <div className={"absolute left-[149px] top-[0px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
            {"مدل:"}
          </div>
          <div className={"absolute left-[147px] top-[74px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
            {"ابعاد:"}
          </div>
          <div className={"absolute left-[166px] top-[38px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
            {"کد:"}
          </div>
          <div className={"absolute left-[196px] top-[10px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
          <div className={"absolute left-[196px] top-[48px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
          <div className={"absolute left-[197px] top-[84px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[404px] h-[718px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/a84f0ecfbf6cf4e8a6f8b4067491197c1078b784.webp')"}} />
      </div>
      <div className={"absolute left-[887px] top-[2233px] w-[404px] h-[718px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/a84f0ecfbf6cf4e8a6f8b4067491197c1078b784.webp')"}} />
      <div className={"absolute left-[1283px] top-[822px] w-[404px] h-[723px] box-border origin-top-left"}>
        <div className={"absolute left-[33px] top-[209px] w-[338px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
        <div className={"absolute left-[146px] top-[606px] w-[207px] h-[98px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[3px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"CLEAN TOUCH"}
          </div>
          <div className={"absolute left-[115px] top-[38px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"7185"}
          </div>
          <div className={"absolute left-[65px] top-[74px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"121*228"}
          </div>
          <div className={"absolute left-[150px] top-[0px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
            {"مدل:"}
          </div>
          <div className={"absolute left-[148px] top-[74px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
            {"ابعاد:"}
          </div>
          <div className={"absolute left-[167px] top-[38px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
            {"کد:"}
          </div>
          <div className={"absolute left-[197px] top-[10px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
          <div className={"absolute left-[197px] top-[48px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
          <div className={"absolute left-[198px] top-[84px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[404px] h-[718px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/9b2d5021e04fc5b3ec613b4da0e86751ac7db323.webp')"}} />
      </div>
      <div className={"absolute left-[1284px] top-[2233px] w-[404px] h-[718px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/9b2d5021e04fc5b3ec613b4da0e86751ac7db323.webp')"}} />
      <div className={"absolute left-[873px] top-[1580px] w-[364.5px] h-[648px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/products/0ceaaa8b478d2197cb2e8cfcbc5a20d882509e3a.webp')"}} />
      <div className={"absolute left-[1328px] top-[1762px] w-[307.157px] h-[373px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/products/453f0ced0e6852ef482064e0d8969a83d902e76c.webp')"}} />
      <div className={"absolute left-[475px] top-[859px] w-[362.25px] h-[686px] box-border origin-top-left"}>
        <div className={"absolute left-[11px] top-[172px] w-[338px] h-[514px] box-border origin-top-left bg-[#ffffff]"} style={{boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.250)"}} />
        <div className={"absolute left-[119px] top-[572px] w-[207px] h-[98px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[3px] w-[146px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"CLEAN TOUCH"}
          </div>
          <div className={"absolute left-[116px] top-[38px] w-[47px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"7185"}
          </div>
          <div className={"absolute left-[66px] top-[74px] w-[81px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"121*228"}
          </div>
          <div className={"absolute left-[150px] top-[0px] w-[44px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
            {"مدل:"}
          </div>
          <div className={"absolute left-[148px] top-[74px] w-[46px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
            {"ابعاد:"}
          </div>
          <div className={"absolute left-[167px] top-[38px] w-[27px] h-[24px] box-border origin-top-left text-[#000000] text-[20px] font-[600] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
            {"کد:"}
          </div>
          <div className={"absolute left-[197px] top-[10px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
          <div className={"absolute left-[197px] top-[48px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
          <div className={"absolute left-[198px] top-[84px] w-[9px] h-[9px] box-border origin-top-left rounded-[50%] rounded-full bg-[#ff0000]"} />
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[362.25px] h-[644px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/products/702021aa650b98b7874c37cd74509e0a8e5c10d1.webp')"}} />
      </div>
      <div className={"absolute left-[725px] top-[3269px] w-[277px] h-[73px] box-border origin-top-left"}>
        <div className={"absolute left-[102px] top-[0px] w-[73px] h-[73px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left"}>
            <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left rounded-[4px] bg-[#f1f1f1]"} />
          </div>
          <div className={"absolute left-[30px] top-[13px] w-[18px] h-[44px] box-border origin-top-left text-[#ff0000] text-[36px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
            {"1"}
          </div>
        </div>
        <div className={"absolute left-[204px] top-[0px] w-[73px] h-[73px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left"}>
            <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left rounded-[4px] bg-[#f1f1f1]"} />
            <div className={"absolute left-[23px] top-[37px] w-[26px] h-[0px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26 1" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 0 -1.5 C -0.828 -1.5 -1.5 -0.828 -1.5 0 C -1.5 0.828 -0.828 1.5 0 1.5 L 0 -1.5 Z M 27.061 1.061 C 27.646 0.475 27.646 -0.475 27.061 -1.061 L 17.515 -10.607 C 16.929 -11.192 15.979 -11.192 15.393 -10.607 C 14.808 -10.021 14.808 -9.071 15.393 -8.485 L 23.879 0 L 15.393 8.485 C 14.808 9.071 14.808 10.021 15.393 10.607 C 15.979 11.192 16.929 11.192 17.515 10.607 L 27.061 1.061 Z M 0 1.5 L 26 1.5 L 26 -1.5 L 0 -1.5 L 0 1.5 Z"} fill={"#464646"} fillRule="nonzero" />
              </svg>
            </div>
          </div>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left"}>
            <div className={"absolute left-[0px] top-[0px] w-[73px] h-[73px] box-border origin-top-left rounded-[4px] bg-[#f1f1f1]"} />
            <div className={"absolute left-[48px] top-[37px] w-[26px] h-[0px] box-border origin-top-left"} style={{transform: "matrix(-1,0,-0,-1,0,0)"}}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26 1" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 0 -1.5 C -0.828 -1.5 -1.5 -0.828 -1.5 0 C -1.5 0.828 -0.828 1.5 0 1.5 L 0 -1.5 Z M 27.061 1.061 C 27.646 0.475 27.646 -0.475 27.061 -1.061 L 17.515 -10.607 C 16.929 -11.192 15.979 -11.192 15.393 -10.607 C 14.808 -10.021 14.808 -9.071 15.393 -8.485 L 23.879 0 L 15.393 8.485 C 14.808 9.071 14.808 10.021 15.393 10.607 C 15.979 11.192 16.929 11.192 17.515 10.607 L 27.061 1.061 Z M 0 1.5 L 26 1.5 L 26 -1.5 L 0 -1.5 L 0 1.5 Z"} fill={"#464646"} fillRule="nonzero" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[471px] top-[1565px] w-[366.187px] h-[651px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/products/a9b8f64f6dfb762948f9a72c5e198caaaee8153d.webp')"}} />
      <div className={"absolute left-[-2px] top-[3526px] w-[1744px] h-[642px] box-border origin-top-left bg-[#1f1f1f]"} />
      <div className={"absolute left-[103px] top-[3977px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[13px] top-[8px] w-[11px] h-[20px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[11px] h-[20px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11 20" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 11 0 L 12.15 0 C 12.15 -0.635 11.635 -1.15 11 -1.15 L 11 0 Z M 4.465 1.464 L 5.278 2.278 L 5.278 2.278 L 4.465 1.464 Z M 3 8 L 3 9.15 C 3.635 9.15 4.15 8.635 4.15 8 L 3 8 Z M 0 8 L 0 6.85 C -0.635 6.85 -1.15 7.365 -1.15 8 L 0 8 Z M 0 12 L -1.15 12 C -1.15 12.635 -0.635 13.15 0 13.15 L 0 12 Z M 3 12 L 4.15 12 C 4.15 11.365 3.635 10.85 3 10.85 L 3 12 Z M 3 20 L 1.85 20 C 1.85 20.635 2.365 21.15 3 21.15 L 3 20 Z M 7 20 L 7 21.15 C 7.635 21.15 8.15 20.635 8.15 20 L 7 20 Z M 7 12 L 7 10.85 C 6.365 10.85 5.85 11.365 5.85 12 L 7 12 Z M 10 12 L 10 13.15 C 10.528 13.15 10.988 12.791 11.116 12.279 L 10 12 Z M 11 8 L 12.116 8.279 C 12.202 7.935 12.124 7.571 11.906 7.292 C 11.689 7.013 11.354 6.85 11 6.85 L 11 8 Z M 7 8 L 5.85 8 C 5.85 8.635 6.365 9.15 7 9.15 L 7 8 Z M 7.293 4.293 L 6.48 3.48 L 6.48 3.48 L 7.293 4.293 Z M 11 4 L 11 5.15 C 11.635 5.15 12.15 4.635 12.15 4 L 11 4 Z M 11 -1.15 L 8 -1.15 L 8 1.15 L 11 1.15 L 11 -1.15 Z M 8 -1.15 C 6.369 -1.15 4.805 -0.502 3.651 0.651 L 5.278 2.278 C 6 1.556 6.979 1.15 8 1.15 L 8 -1.15 Z M 3.651 0.651 C 2.498 1.805 1.85 3.369 1.85 5 L 4.15 5 C 4.15 3.979 4.556 3 5.278 2.278 L 3.651 0.651 Z M 1.85 5 L 1.85 8 L 4.15 8 L 4.15 5 L 1.85 5 Z M 3 6.85 L 0 6.85 L 0 9.15 L 3 9.15 L 3 6.85 Z M -1.15 8 L -1.15 12 L 1.15 12 L 1.15 8 L -1.15 8 Z M 0 13.15 L 3 13.15 L 3 10.85 L 0 10.85 L 0 13.15 Z M 1.85 12 L 1.85 20 L 4.15 20 L 4.15 12 L 1.85 12 Z M 3 21.15 L 7 21.15 L 7 18.85 L 3 18.85 L 3 21.15 Z M 8.15 20 L 8.15 12 L 5.85 12 L 5.85 20 L 8.15 20 Z M 7 13.15 L 10 13.15 L 10 10.85 L 7 10.85 L 7 13.15 Z M 11.116 12.279 L 12.116 8.279 L 9.884 7.721 L 8.884 11.721 L 11.116 12.279 Z M 11 6.85 L 7 6.85 L 7 9.15 L 11 9.15 L 11 6.85 Z M 8.15 8 L 8.15 5 L 5.85 5 L 5.85 8 L 8.15 8 Z M 8.15 5 C 8.15 5.04 8.134 5.078 8.106 5.106 L 6.48 3.48 C 6.077 3.883 5.85 4.43 5.85 5 L 8.15 5 Z M 8.106 5.106 C 8.078 5.134 8.04 5.15 8 5.15 L 8 2.85 C 7.43 2.85 6.883 3.076 6.48 3.48 L 8.106 5.106 Z M 8 5.15 L 11 5.15 L 11 2.85 L 8 2.85 L 8 5.15 Z M 12.15 4 L 12.15 0 L 9.85 0 L 9.85 4 L 12.15 4 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[165px] top-[3977px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[7px] top-[9px] w-[22.069px] h-[18px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[22.069px] h-[18px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 22.069 18" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 22.069 0.01 L 23.23 0.472 C 23.428 -0.025 23.288 -0.592 22.882 -0.94 C 22.476 -1.287 21.893 -1.338 21.433 -1.066 L 22.069 0.01 Z M 18.919 1.545 L 17.976 2.365 C 18.299 2.736 18.809 2.884 19.28 2.742 L 18.919 1.545 Z M 16.619 0.134 L 16.922 -1.078 L 16.922 -1.078 L 16.619 0.134 Z M 11.81 1.97 L 12.844 2.672 L 12.844 2.672 L 11.81 1.97 Z M 11.034 4.554 L 12.284 4.554 C 12.284 4.549 12.284 4.543 12.284 4.538 L 11.034 4.554 Z M 11.034 5.557 L 11.067 6.807 C 11.744 6.789 12.284 6.235 12.284 5.557 L 11.034 5.557 Z M 5.95 4.419 L 6.512 3.303 L 6.512 3.303 L 5.95 4.419 Z M 2.006 1.013 L 3.029 0.295 C 2.77 -0.074 2.333 -0.275 1.885 -0.231 C 1.437 -0.187 1.047 0.094 0.864 0.506 L 2.006 1.013 Z M 7.022 14.054 L 7.724 15.088 C 8.1 14.833 8.307 14.395 8.267 13.943 C 8.227 13.491 7.944 13.096 7.53 12.912 L 7.022 14.054 Z M 0 16.06 L 0.05 14.811 C -0.529 14.788 -1.047 15.165 -1.204 15.723 C -1.36 16.28 -1.113 16.872 -0.607 17.153 L 0 16.06 Z M 20.063 4.524 L 21.313 4.524 L 21.313 4.52 L 20.063 4.524 Z M 19.982 3.692 L 19.105 2.802 C 18.808 3.095 18.676 3.516 18.755 3.926 L 19.982 3.692 Z M 22.069 0.01 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.432 -1.065 21.431 -1.065 21.429 -1.064 C 21.426 -1.062 21.421 -1.059 21.414 -1.055 C 21.401 -1.047 21.38 -1.035 21.353 -1.019 C 21.299 -0.988 21.219 -0.942 21.119 -0.886 C 20.92 -0.772 20.643 -0.619 20.333 -0.455 C 19.683 -0.112 18.992 0.217 18.559 0.348 L 19.28 2.742 C 19.972 2.533 20.856 2.096 21.5 1.756 C 21.837 1.578 22.136 1.412 22.351 1.29 C 22.459 1.229 22.546 1.179 22.607 1.144 C 22.637 1.126 22.661 1.112 22.678 1.102 C 22.686 1.097 22.692 1.094 22.697 1.091 C 22.699 1.09 22.701 1.089 22.702 1.088 C 22.703 1.087 22.704 1.087 22.704 1.087 C 22.704 1.087 22.704 1.087 22.704 1.087 C 22.705 1.086 22.705 1.086 22.705 1.086 C 22.705 1.086 22.705 1.086 22.069 0.01 Z M 19.862 0.725 C 19.09 -0.163 18.064 -0.793 16.922 -1.078 L 16.316 1.347 C 16.96 1.508 17.54 1.864 17.976 2.365 L 19.862 0.725 Z M 16.922 -1.078 C 15.781 -1.364 14.579 -1.292 13.48 -0.872 L 14.371 1.463 C 14.992 1.226 15.671 1.186 16.316 1.347 L 16.922 -1.078 Z M 13.48 -0.872 C 12.381 -0.453 11.437 0.294 10.776 1.268 L 12.844 2.672 C 13.217 2.122 13.75 1.7 14.371 1.463 L 13.48 -0.872 Z M 10.776 1.268 C 10.115 2.241 9.769 3.394 9.785 4.571 L 12.284 4.538 C 12.275 3.873 12.471 3.222 12.844 2.672 L 10.776 1.268 Z M 9.784 4.554 L 9.784 5.557 L 12.284 5.557 L 12.284 4.554 L 9.784 4.554 Z M 11.002 4.308 C 9.445 4.348 7.903 4.003 6.512 3.303 L 5.388 5.536 C 7.147 6.421 9.098 6.858 11.067 6.807 L 11.002 4.308 Z M 6.512 3.303 C 5.121 2.603 3.924 1.569 3.029 0.295 L 0.983 1.732 C 2.115 3.343 3.628 4.65 5.388 5.536 L 6.512 3.303 Z M 2.006 1.013 C 0.864 0.506 0.864 0.506 0.863 0.507 C 0.863 0.507 0.863 0.508 0.863 0.508 C 0.862 0.509 0.862 0.51 0.861 0.512 C 0.86 0.514 0.859 0.517 0.857 0.521 C 0.854 0.529 0.85 0.538 0.845 0.55 C 0.835 0.574 0.821 0.606 0.805 0.646 C 0.772 0.727 0.728 0.841 0.676 0.984 C 0.573 1.27 0.439 1.676 0.31 2.174 C 0.054 3.163 -0.19 4.546 -0.12 6.086 C -0.05 7.631 0.339 9.359 1.373 10.992 C 2.413 12.634 4.057 14.104 6.514 15.196 L 7.53 12.912 C 5.472 11.997 4.233 10.834 3.485 9.655 C 2.733 8.467 2.432 7.186 2.377 5.972 C 2.322 4.753 2.516 3.628 2.731 2.8 C 2.837 2.388 2.946 2.057 3.027 1.834 C 3.067 1.723 3.1 1.638 3.122 1.585 C 3.133 1.558 3.141 1.539 3.145 1.528 C 3.148 1.523 3.149 1.52 3.15 1.518 C 3.15 1.518 3.15 1.518 3.15 1.518 C 3.15 1.518 3.15 1.519 3.149 1.519 C 3.149 1.519 3.149 1.52 3.149 1.52 C 3.149 1.52 3.149 1.521 2.006 1.013 Z M 6.32 13.02 C 4.475 14.272 2.278 14.9 0.05 14.811 L -0.05 17.309 C 2.712 17.419 5.437 16.641 7.724 15.088 L 6.32 13.02 Z M -0.607 17.153 C 4.253 19.853 9.718 19.884 14.004 17.603 C 18.321 15.305 21.313 10.73 21.313 4.524 L 18.813 4.524 C 18.813 9.855 16.288 13.555 12.83 15.396 C 9.341 17.253 4.776 17.283 0.607 14.968 L -0.607 17.153 Z M 21.313 4.52 C 21.312 4.163 21.277 3.807 21.21 3.457 L 18.755 3.926 C 18.793 4.125 18.812 4.326 18.813 4.528 L 21.313 4.52 Z M 20.86 4.582 C 21.538 3.913 22.139 2.816 22.53 2.027 C 22.738 1.607 22.912 1.221 23.034 0.941 C 23.094 0.801 23.143 0.686 23.176 0.605 C 23.193 0.564 23.206 0.532 23.215 0.51 C 23.22 0.499 23.223 0.49 23.226 0.484 C 23.227 0.48 23.228 0.478 23.229 0.476 C 23.229 0.475 23.23 0.474 23.23 0.473 C 23.23 0.473 23.23 0.473 23.23 0.473 C 23.23 0.473 23.23 0.472 23.23 0.472 C 23.23 0.472 23.23 0.472 22.069 0.01 C 20.907 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.907 -0.452 C 20.907 -0.451 20.907 -0.45 20.906 -0.448 C 20.904 -0.444 20.902 -0.438 20.898 -0.429 C 20.891 -0.412 20.881 -0.386 20.866 -0.351 C 20.838 -0.282 20.795 -0.18 20.74 -0.055 C 20.631 0.198 20.475 0.544 20.29 0.917 C 19.893 1.717 19.451 2.46 19.105 2.802 L 20.86 4.582 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[227px] top-[3977px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[6px] top-[5px] w-[24px] h-[24px] box-border origin-top-left"}>
          <div className={"absolute left-[2px] top-[2px] w-[20px] h-[20px] box-border origin-top-left"}>
            <div className={"absolute left-[5.556px] top-[5.556px] w-[8.889px] h-[8.889px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 8.889 8.889" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 4.444 10.039 C 7.534 10.039 10.039 7.534 10.039 4.444 L 7.739 4.444 C 7.739 6.264 6.264 7.739 4.444 7.739 L 4.444 10.039 Z M 10.039 4.444 C 10.039 1.355 7.534 -1.15 4.444 -1.15 L 4.444 1.15 C 6.264 1.15 7.739 2.625 7.739 4.444 L 10.039 4.444 Z M 4.444 -1.15 C 1.355 -1.15 -1.15 1.355 -1.15 4.444 L 1.15 4.444 C 1.15 2.625 2.625 1.15 4.444 1.15 L 4.444 -1.15 Z M -1.15 4.444 C -1.15 7.534 1.355 10.039 4.444 10.039 L 4.444 7.739 C 2.625 7.739 1.15 6.264 1.15 4.444 L -1.15 4.444 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[20px] h-[20px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 20 20" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 1.25 14.444 L 1.25 5.556 L -1.25 5.556 L -1.25 14.444 L 1.25 14.444 Z M 1.25 5.556 C 1.25 3.178 3.178 1.25 5.556 1.25 L 5.556 -1.25 C 1.797 -1.25 -1.25 1.797 -1.25 5.556 L 1.25 5.556 Z M 5.556 1.25 L 14.444 1.25 L 14.444 -1.25 L 5.556 -1.25 L 5.556 1.25 Z M 14.444 1.25 C 16.822 1.25 18.75 3.178 18.75 5.556 L 21.25 5.556 C 21.25 1.797 18.203 -1.25 14.444 -1.25 L 14.444 1.25 Z M 18.75 5.556 L 18.75 14.444 L 21.25 14.444 L 21.25 5.556 L 18.75 5.556 Z M 18.75 14.444 C 18.75 16.822 16.822 18.75 14.444 18.75 L 14.444 21.25 C 18.203 21.25 21.25 18.203 21.25 14.444 L 18.75 14.444 Z M 14.444 18.75 L 5.556 18.75 L 5.556 21.25 L 14.444 21.25 L 14.444 18.75 Z M 5.556 18.75 C 3.178 18.75 1.25 16.822 1.25 14.444 L -1.25 14.444 C -1.25 18.203 1.797 21.25 5.556 21.25 L 5.556 18.75 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[16.111px] top-[3.888px] w-[0.012px] h-[0.013px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 1 1" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M -0.929 -0.823 C -1.391 -0.31 -1.349 0.48 -0.836 0.942 C -0.323 1.404 0.467 1.362 0.929 0.849 L -0.929 -0.823 Z M 0.941 0.836 C 1.403 0.323 1.361 -0.467 0.848 -0.929 C 0.335 -1.391 -0.456 -1.349 -0.917 -0.836 L 0.941 0.836 Z M 0.929 0.849 L 0.941 0.836 L -0.917 -0.836 L -0.929 -0.823 L 0.929 0.849 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[289px] top-[3977px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[7px] top-[7px] w-[22px] h-[22px] box-border origin-top-left overflow-hidden"}>
          <div className={"absolute left-[0px] top-[0px] w-[22px] h-[22px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/d3113ae5d38f42325172d25ee512520ef84dd396.webp')"}} />
          <div className={"absolute left-[-3px] top-[-3px] w-[28px] h-[28px] box-border origin-top-left bg-[#ffffff]"} />
        </div>
      </div>
      <div className={"absolute left-[92.946px] top-[3698px] w-[284.008px] h-[71.898px] box-border origin-top-left"}>
        <div className={"absolute left-[239.319px] top-[16.191px] w-[5.895px] h-[32.381px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 5.895 32.381" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 5.895 0 L 0 0 L 0 32.381 L 5.895 32.381 L 5.895 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[284.008px] h-[71.898px] box-border origin-top-left"}>
          <div className={"absolute left-[198.149px] top-[16.191px] w-[33.849px] h-[32.473px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 33.849 32.473" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 16.924 24.057 L 27.954 13.355 L 27.954 32.473 L 33.849 32.473 L 33.849 0 L 16.924 16.557 L 0 0 L 0 32.473 L 5.8 32.473 L 5.8 13.355 L 16.924 24.057 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[0px] top-[0px] w-[284.008px] h-[71.898px] box-border origin-top-left"}>
            <div className={"absolute left-[251.585px] top-[16.191px] w-[32.423px] h-[32.381px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 32.423 32.381" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 26.528 14.91 C 26.528 9.788 22.154 5.671 16.924 5.671 L 5.895 5.671 L 5.895 26.802 L 16.924 26.802 C 22.249 26.802 26.528 22.594 26.528 17.563 L 26.528 15.002 L 26.528 14.91 Z M 0 5.671 L 0 0 L 16.924 0 C 25.482 0 32.423 6.678 32.423 14.91 L 32.423 17.471 C 32.423 25.704 25.482 32.381 16.924 32.381 L 0 32.381 L 0 5.58 L 0 5.671 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[157.359px] top-[16.282px] w-[35.465px] h-[32.381px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 35.465 32.381" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 35.465 16.191 C 35.465 7.226 27.859 0 18.636 0 L 16.829 0 C 7.607 0 0 7.318 0 16.191 C 0 25.064 7.607 32.381 16.829 32.381 L 18.636 32.381 C 27.954 32.381 35.465 25.064 35.465 16.191 Z M 17.78 4.94 C 24.151 4.94 29.38 9.971 29.38 16.099 C 29.38 22.228 24.151 27.259 17.78 27.259 C 11.41 27.259 6.18 22.228 6.18 16.099 C 6.18 9.971 11.41 4.94 17.78 4.94 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[122.084px] top-[16.282px] w-[30.996px] h-[32.381px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 30.996 32.381" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 23.39 32.381 L 30.996 32.381 L 21.583 21.679 C 22.82 21.405 24.056 21.039 25.101 20.49 C 28.619 18.66 30.996 15.002 30.996 10.977 C 30.996 4.94 25.862 0 19.587 0 L 0 0 L 0 32.381 L 5.8 32.381 L 5.8 5.58 L 19.587 5.58 C 22.629 5.58 25.101 7.958 25.101 10.885 C 25.101 13.812 22.629 16.191 19.587 16.191 L 9.128 16.191 L 14.072 21.771 L 23.39 32.29 L 23.39 32.381 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[283.913px] h-[71.898px] box-border origin-top-left"}>
              <div className={"absolute left-[65.131px] top-[16.191px] w-[26.908px] h-[32.473px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26.908 32.473" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 0 0 L 26.908 0 L 23.485 5.671 L 5.8 5.671 L 5.8 13.446 L 21.108 13.446 L 18.351 19.026 L 5.8 19.026 L 5.8 22.777 L 5.8 26.802 L 5.8 32.473 L 0 32.473 L 0 19.026 L 0 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[0px] top-[0px] w-[56.573px] h-[62.933px] box-border origin-top-left"}>
                <div className={"absolute left-[0px] top-[0px] w-[38.983px] h-[52.78px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 38.983 52.78" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 10.744 52.78 L 0 47.017 L 0 15.55 L 28.715 0 L 38.983 5.763 L 10.744 21.953 L 10.744 52.78 Z"} fill={"#ffffff"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[23.485px] top-[12.532px] w-[33.088px] h-[50.401px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 33.088 50.401" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 26.802 L 0 15.367 L 27.574 0 L 33.088 3.019 L 33.088 34.76 L 4.754 50.401 L 0 47.566 L 0 41.071 L 22.629 28.448 L 22.439 14.453 L 0 26.802 Z"} fill={"#ec1c24"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
              <div className={"absolute left-[84.812px] top-[16.191px] w-[34.419px] h-[32.473px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 34.419 32.473" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 17.21 0 L 0 32.473 L 6.275 32.473 L 17.21 11.8 L 28.144 32.473 L 34.419 32.473 L 17.21 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[162.494px] top-[56.439px] w-[121.419px] h-[15.459px] box-border origin-top-left"}>
                <div className={"absolute left-[-0px] top-[0.092px] w-[14.357px] h-[15.367px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 14.357 15.367" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 14.357 15.093 L 11.885 15.093 C 11.79 14.636 11.695 14.087 11.6 13.629 C 10.744 14.727 9.223 15.367 7.036 15.367 C 2.567 15.367 0 12.074 0 7.867 C 0 3.659 2.662 0 7.606 0 C 12.551 0 13.977 2.195 14.262 4.665 L 10.934 4.665 C 10.649 3.659 9.793 2.47 7.511 2.47 C 5.229 2.47 3.423 5.031 3.423 7.684 C 3.423 10.336 4.469 12.806 7.511 12.806 C 10.554 12.806 10.934 10.885 10.934 9.605 C 10.934 9.513 7.511 9.513 7.511 9.513 L 7.511 6.86 L 14.167 6.86 L 14.167 15.184 L 14.357 15.093 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[28.714px] top-[0.274px] w-[11.98px] h-[14.91px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.98 14.91" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 3.233 8.964 L 3.233 14.91 L 0 14.91 L 0 0 L 6.751 0 C 10.079 0 11.98 1.829 11.98 4.116 C 11.98 6.403 10.839 7.226 9.698 7.592 C 10.459 7.867 11.6 8.598 11.6 11.251 L 11.6 11.983 C 11.6 12.989 11.6 14.087 11.79 14.819 L 8.652 14.819 C 8.367 14.178 8.367 13.081 8.367 11.434 L 8.367 11.251 C 8.367 9.605 7.987 8.873 5.42 8.873 L 3.233 8.873 L 3.233 8.964 Z M 3.233 6.403 L 5.99 6.403 C 7.797 6.403 8.557 5.763 8.557 4.482 C 8.557 3.202 7.702 2.561 6.085 2.561 L 3.233 2.561 L 3.233 6.403 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[53.531px] top-[0px] w-[15.023px] h-[15.367px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 15.023 15.367" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 15.023 7.684 C 15.023 11.8 12.456 15.367 7.416 15.367 C 2.377 15.367 0 11.983 0 7.684 C 0 3.385 2.852 0 7.606 0 C 12.361 0 15.023 3.019 15.023 7.592 L 15.023 7.684 Z M 3.518 7.684 C 3.518 10.611 4.849 12.806 7.606 12.806 C 10.364 12.806 11.6 10.428 11.6 7.775 C 11.6 5.122 10.364 2.744 7.511 2.744 C 4.659 2.744 3.518 4.848 3.518 7.684 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[82.34px] top-[0.274px] w-[12.931px] h-[15.093px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 12.931 15.093" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 3.233 0 L 3.233 8.873 C 3.233 11.709 4.754 12.532 6.466 12.532 C 8.177 12.532 9.603 11.526 9.603 8.873 L 9.603 0 L 12.931 0 L 12.931 8.69 C 12.931 13.812 9.793 15.093 6.466 15.093 C 3.138 15.093 0 13.721 0 8.781 L 0 0 L 3.328 0 L 3.233 0 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[109.534px] top-[0.274px] w-[11.885px] h-[14.91px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.885 14.91" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 0 L 6.37 0 C 9.698 0 11.885 1.738 11.885 4.574 C 11.885 7.409 9.318 9.33 6.275 9.33 L 3.328 9.33 L 3.328 14.91 L 0 14.91 L 0 0 Z M 3.328 6.769 L 5.895 6.769 C 7.416 6.769 8.557 6.22 8.557 4.665 C 8.557 3.11 7.416 2.561 5.99 2.561 L 3.328 2.561 L 3.328 6.769 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[1513px] top-[3747px] w-[90px] h-[25px] box-border origin-top-left text-[#ffffff] text-[20px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"تماس با ما"}
      </div>
      <div className={"absolute left-[973px] top-[3746px] w-[63px] h-[25px] box-border origin-top-left text-[#ffffff] text-[20px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"پیوندها"}
      </div>
      <div className={"absolute left-[1158px] top-[3794px] w-[452px] h-[18px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"آدرس کارخانه: کیلومتر 20 جاده خاوران، روبروی فرون آباد اول، کوچه صاحب الزمان"}
      </div>
      <div className={"absolute left-[1112px] top-[3825px] w-[491px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"آدرس دفترمرکزی و شوروم :  اتوبان ارتش. اقدسیه. اراج. نبش اراج. ساختمان نگین پلاک 156"}
      </div>
      <div className={"absolute left-[1348px] top-[3863px] w-[256px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"شماره تماس دفترمرکزی و شورم :  02178328000"}
      </div>
      <div className={"absolute left-[1427px] top-[3901px] w-[176px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"فکس دفتر مرکزی :  02122823107"}
      </div>
      <div className={"absolute left-[1380px] top-[3939px] w-[223px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"شماره تماس : 02136849085 - 02136849086"}
      </div>
      <div className={"absolute left-[1497px] top-[3977px] w-[106px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"فکس : 02136849474"}
      </div>
      <div className={"absolute left-[1451px] top-[4015px] w-[152px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"ایمیل :     info@faromid.com"}
      </div>
      <div className={"absolute left-[772px] top-[3794px] w-[276px] h-[170px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"صنایع چوب ایران\nاتحادیه تولید کنندگان و صادر کنندگان مبل ایران\nتعاونی فرآورده های چوبی\n انجمن روکش های مصنوعی\nشورای ملی مبلمان\nگمرک جمهوری اسلامی ایران\nوزارت صنعت ، معدن و تجارت\nاستاندارد ایران\nسامانه جامع تجارت\nبانک مرکزی      "}
      </div>
      <div className={"absolute left-[599px] top-[3796px] w-[132px] h-[153px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"اتاق بازرگانی\nاتاق بازرگانی ایران\nاتاق بازرگانی آلمان\nاتاق بازرگانی ایتالیا\n اتاق بازرگانی اتریش\nاتاق بازرگانی چین\nبهین یاب\nمیانگین موزون سنا\nبازار طلا و ارز"}
      </div>
      <div className={"absolute left-[1162px] top-[3763.5px] w-[348px] h-[0px] box-border origin-top-left"}>
        <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 348 1" preserveAspectRatio="none" className="block overflow-visible">
          <path d={"M 348 -1 L 0 -1 L 0 1 L 348 1 L 348 -1 Z"} fill={"#ff0000"} fillRule="nonzero" />
        </svg>
      </div>
      <div className={"absolute left-[116px] top-[3796px] w-[250px] h-[40px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-center [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"فرامید تولید کننده ام دی اف دورو سینکرونایز، \nفوق برجسته و سوپر مات-آنتی فینگر"}
      </div>
      <div className={"absolute left-[475px] top-[76px] w-[1197px] h-[69px] box-border origin-top-left opacity-[0.8] rounded-[5px] bg-[#ffffff]"} />
      <div className={"absolute left-[198px] top-[73px] w-[258.792px] h-[68px] box-border origin-top-left"}>
        <div className={"absolute left-[218.072px] top-[15.313px] w-[5.372px] h-[30.626px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 5.372 30.626" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 5.372 0 L 0 0 L 0 30.626 L 5.372 30.626 L 5.372 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[258.792px] h-[68px] box-border origin-top-left"}>
          <div className={"absolute left-[180.557px] top-[15.313px] w-[30.844px] h-[30.712px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 30.844 30.712" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 15.422 22.753 L 25.472 12.631 L 25.472 30.712 L 30.844 30.712 L 30.844 0 L 15.422 15.659 L 0 0 L 0 30.712 L 5.285 30.712 L 5.285 12.631 L 15.422 22.753 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[0px] top-[0px] w-[258.792px] h-[68px] box-border origin-top-left"}>
            <div className={"absolute left-[229.248px] top-[15.313px] w-[29.544px] h-[30.626px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 29.544 30.626" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 24.172 14.102 C 24.172 9.257 20.187 5.364 15.422 5.364 L 5.372 5.364 L 5.372 25.349 L 15.422 25.349 C 20.274 25.349 24.172 21.369 24.172 16.611 L 24.172 14.188 L 24.172 14.102 Z M 0 5.364 L 0 0 L 15.422 0 C 23.219 0 29.544 6.316 29.544 14.102 L 29.544 16.524 C 29.544 24.31 23.219 30.626 15.422 30.626 L 0 30.626 L 0 5.277 L 0 5.364 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[143.388px] top-[15.399px] w-[32.317px] h-[30.626px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 32.317 30.626" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 32.317 15.313 C 32.317 6.835 25.385 0 16.981 0 L 15.335 0 C 6.931 0 0 6.921 0 15.313 C 0 23.705 6.931 30.626 15.335 30.626 L 16.981 30.626 C 25.472 30.626 32.317 23.705 32.317 15.313 Z M 16.202 4.672 C 22.006 4.672 26.772 9.43 26.772 15.226 C 26.772 21.023 22.006 25.781 16.202 25.781 C 10.397 25.781 5.632 21.023 5.632 15.226 C 5.632 9.43 10.397 4.672 16.202 4.672 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[111.245px] top-[15.399px] w-[28.244px] h-[30.626px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 28.244 30.626" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 21.313 30.626 L 28.244 30.626 L 19.667 20.504 C 20.793 20.244 21.92 19.898 22.873 19.379 C 26.078 17.649 28.244 14.188 28.244 10.382 C 28.244 4.672 23.566 0 17.848 0 L 0 0 L 0 30.626 L 5.285 30.626 L 5.285 5.277 L 17.848 5.277 C 20.62 5.277 22.873 7.527 22.873 10.295 C 22.873 13.064 20.62 15.313 17.848 15.313 L 8.317 15.313 L 12.823 20.59 L 21.313 30.539 L 21.313 30.626 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[258.705px] h-[68px] box-border origin-top-left"}>
              <div className={"absolute left-[59.348px] top-[15.313px] w-[24.519px] h-[30.712px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 24.519 30.712" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 0 0 L 24.519 0 L 21.4 5.364 L 5.285 5.364 L 5.285 12.718 L 19.234 12.718 L 16.721 17.995 L 5.285 17.995 L 5.285 21.542 L 5.285 25.349 L 5.285 30.712 L 0 30.712 L 0 17.995 L 0 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[0px] top-[0px] w-[51.55px] h-[59.522px] box-border origin-top-left"}>
                <div className={"absolute left-[0px] top-[0px] w-[35.522px] h-[49.919px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 35.522 49.919" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 9.79 49.919 L 0 44.468 L 0 14.707 L 26.165 0 L 35.522 5.45 L 9.79 20.763 L 9.79 49.919 Z"} fill={"#ffffff"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[21.4px] top-[11.853px] w-[30.151px] h-[47.669px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 30.151 47.669" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 25.349 L 0 14.534 L 25.125 0 L 30.151 2.855 L 30.151 32.875 L 4.332 47.669 L 0 44.987 L 0 38.845 L 20.62 26.906 L 20.447 13.669 L 0 25.349 Z"} fill={"#ec1c24"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
              <div className={"absolute left-[77.282px] top-[15.313px] w-[31.363px] h-[30.712px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 31.363 30.712" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 15.682 0 L 0 30.712 L 5.718 30.712 L 15.682 11.16 L 25.645 30.712 L 31.363 30.712 L 15.682 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[148.067px] top-[53.379px] w-[110.639px] h-[14.621px] box-border origin-top-left"}>
                <div className={"absolute left-[-0px] top-[0.087px] w-[13.083px] h-[14.534px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 13.083 14.534" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 13.083 14.275 L 10.83 14.275 C 10.743 13.842 10.657 13.323 10.57 12.891 C 9.79 13.929 8.404 14.534 6.411 14.534 C 2.339 14.534 0 11.42 0 7.44 C 0 3.461 2.426 0 6.931 0 C 11.436 0 12.736 2.076 12.996 4.412 L 9.964 4.412 C 9.704 3.461 8.924 2.336 6.845 2.336 C 4.765 2.336 3.119 4.758 3.119 7.267 C 3.119 9.776 4.072 12.112 6.845 12.112 C 9.617 12.112 9.964 10.295 9.964 9.084 C 9.964 8.997 6.845 8.997 6.845 8.997 L 6.845 6.489 L 12.909 6.489 L 12.909 14.361 L 13.083 14.275 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[26.165px] top-[0.26px] w-[10.917px] h-[14.102px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 10.917 14.102" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 2.946 8.478 L 2.946 14.102 L 0 14.102 L 0 0 L 6.151 0 C 9.184 0 10.917 1.73 10.917 3.893 C 10.917 6.056 9.877 6.835 8.837 7.181 C 9.53 7.44 10.57 8.132 10.57 10.641 L 10.57 11.333 C 10.57 12.285 10.57 13.323 10.743 14.015 L 7.884 14.015 C 7.624 13.41 7.624 12.371 7.624 10.814 L 7.624 10.641 C 7.624 9.084 7.278 8.392 4.938 8.392 L 2.946 8.392 L 2.946 8.478 Z M 2.946 6.056 L 5.458 6.056 C 7.104 6.056 7.798 5.45 7.798 4.239 C 7.798 3.028 7.018 2.422 5.545 2.422 L 2.946 2.422 L 2.946 6.056 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[48.778px] top-[0px] w-[13.689px] h-[14.534px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 13.689 14.534" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 13.689 7.267 C 13.689 11.16 11.35 14.534 6.758 14.534 C 2.166 14.534 0 11.333 0 7.267 C 0 3.201 2.599 0 6.931 0 C 11.263 0 13.689 2.855 13.689 7.181 L 13.689 7.267 Z M 3.206 7.267 C 3.206 10.036 4.419 12.112 6.931 12.112 C 9.444 12.112 10.57 9.863 10.57 7.354 C 10.57 4.845 9.444 2.595 6.845 2.595 C 4.245 2.595 3.206 4.585 3.206 7.267 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[75.03px] top-[0.26px] w-[11.783px] h-[14.275px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.783 14.275" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 2.946 0 L 2.946 8.392 C 2.946 11.074 4.332 11.852 5.891 11.852 C 7.451 11.852 8.751 10.901 8.751 8.392 L 8.751 0 L 11.783 0 L 11.783 8.219 C 11.783 13.064 8.924 14.275 5.891 14.275 C 2.859 14.275 0 12.977 0 8.305 L 0 0 L 3.032 0 L 2.946 0 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[99.809px] top-[0.26px] w-[10.83px] h-[14.102px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 10.83 14.102" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 0 L 5.805 0 C 8.837 0 10.83 1.644 10.83 4.326 C 10.83 7.008 8.491 8.824 5.718 8.824 L 3.032 8.824 L 3.032 14.102 L 0 14.102 L 0 0 Z M 3.032 6.402 L 5.372 6.402 C 6.758 6.402 7.798 5.883 7.798 4.412 C 7.798 2.941 6.758 2.422 5.458 2.422 L 3.032 2.422 L 3.032 6.402 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[1508px] top-[99px] w-[100px] h-[22px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"صفحه اصلی"}
      </div>
      <div className={"absolute left-[1375px] top-[101px] w-[87px] h-[19px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"محصولات"}
      </div>
      <div className={"absolute left-[866px] top-[100px] w-[66px] h-[20px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"درباره ما"}
      </div>
      <div className={"absolute left-[553px] top-[104px] w-[103px] h-[15px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"تماس با ما"}
      </div>
      <div className={"absolute left-[718px] top-[101px] w-[102px] h-[18px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"همکاری با ما"}
      </div>
      <div className={"absolute left-[978px] top-[103px] w-[95px] h-[15px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"نمایشگاه ها"}
      </div>
      <div className={"absolute left-[1280px] top-[93px] w-[54px] h-[36px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"تکسچر"}
      </div>
      <div className={"absolute left-[1117px] top-[101px] w-[102px] h-[24px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"گالری تصاویر"}
      </div>
      <div className={"absolute left-[167px] top-[369px] w-[1560px] h-[160px] box-border origin-top-left"} style={{backgroundImage: "linear-gradient(105deg, rgba(82,81,81,0.000) 7%, #000000 47%, rgba(133,131,131,0.000) 88%)"}} />
      <div className={"absolute left-[457px] top-[369px] w-[813px] h-[140px] box-border origin-top-left text-[#ffffff] text-[128px] font-[600] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"ANTI FINGER"}
      </div>
      <div className="absolute left-[54px] top-[808px] z-[250] w-[1625px] bg-[#e5e5e5]/97 px-[10px] py-[16px] shadow-[inset_0_0_0_1px_#d5d5d5]">
        <DesktopArtboardProductCarousel perSlide={4} />
      </div>
      {/* Native accessible navigation and interactive regions */}
      <Link href="/" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[90px] top-[60px] w-[300px] h-[100px]" aria-label="صفحه اصلی فرامید" />
      <Link href={"/"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1500px] top-[89px] w-[118px] h-[40px]" aria-label={"صفحه اصلی"} />
      <Link href={"/products"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1367px] top-[91px] w-[105px] h-[40px]" aria-label={"محصولات"} />
      <Link href={"/about"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[858px] top-[90px] w-[84px] h-[40px]" aria-label={"درباره ما"} />
      <Link href={"/contact"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[545px] top-[94px] w-[121px] h-[40px]" aria-label={"تماس با ما"} />
      <Link href={"/careers"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[710px] top-[91px] w-[120px] h-[40px]" aria-label={"همکاری با ما"} />
      <Link href={"/exhibitions"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[970px] top-[93px] w-[113px] h-[40px]" aria-label={"نمایشگاه ها"} />
      <Link href={"/textures"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1272px] top-[83px] w-[72px] h-[52px]" aria-label={"تکسچر"} />
      <Link href={"/gallery"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1109px] top-[91px] w-[120px] h-[40px]" aria-label={"گالری تصاویر"} />
    </>
  );
}
