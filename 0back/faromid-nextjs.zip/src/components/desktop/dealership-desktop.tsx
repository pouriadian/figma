"use client";
/* Pure JSX component. Desktop geometry and media are authored at build time,
 * so no design JSON, layout interpreter or external design service is used.
 * The absolute utility classes intentionally preserve the legacy pixel-perfect artwork. */
import Image from 'next/image';
import Link from 'next/link';

export function DealershipDesktop({onOpenImage}:{onOpenImage:(src:string)=>void}) {
  return (
    <>
      {/* Static Tailwind-rendered desktop artwork */}
      <div className={"absolute left-[682px] top-[-1px] w-[1051px] h-[947px] box-border origin-top-left overflow-visible"}>
        <div className={"absolute left-[0px] top-[0px] w-[1051px] h-[947px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/dealership/ebffed74cf2a9cc7dce3227d0f1e1ffa12696965.webp')"}} />
      </div>
      <div className={"absolute left-[-168px] top-[0px] w-[1321px] h-[944px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/dealership/7a1c123ccba2ae8742f098b200b59b7eb3e9d180.webp')"}} />
      <div className={"absolute left-[678px] top-[0px] w-[1051px] h-[904px] box-border origin-top-left bg-[#d9d9d9]"} />
      <div className={"absolute left-[1537px] top-[-835px] w-[2626px] h-[3938px] box-border origin-top-left"} />
      <div className={"absolute left-[-40px] top-[1282px] w-[1769px] h-[3612px] box-border origin-top-left bg-[#cdcdcd]"} />
      <div className={"absolute left-[499px] top-[73px] w-[1151px] h-[75px] box-border origin-top-left opacity-[0.9] rounded-[5px] bg-[rgba(24,24,24,0.700)]"} />
      <div className={"absolute left-[1510px] top-[100px] w-[100px] h-[22px] box-border origin-top-left text-[#ffffff] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"صفحه اصلی"}
      </div>
      <div className={"absolute left-[1376px] top-[101px] w-[87px] h-[19px] box-border origin-top-left text-[#ffffff] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"محصولات"}
      </div>
      <div className={"absolute left-[867px] top-[101px] w-[66px] h-[20px] box-border origin-top-left text-[#ffffff] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"درباره ما"}
      </div>
      <div className={"absolute left-[583px] top-[104px] w-[89px] h-[13px] box-border origin-top-left text-[#ffffff] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"تماس با ما"}
      </div>
      <div className={"absolute left-[719px] top-[102px] w-[102px] h-[18px] box-border origin-top-left text-[#ffffff] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"همکاری با ما"}
      </div>
      <div className={"absolute left-[979px] top-[103px] w-[95px] h-[15px] box-border origin-top-left text-[#ffffff] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"نمایشگاه ها"}
      </div>
      <div className={"absolute left-[1281px] top-[93px] w-[54px] h-[36px] box-border origin-top-left text-[#ffffff] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"تکسچر"}
      </div>
      <div className={"absolute left-[1118px] top-[99px] w-[102px] h-[24px] box-border origin-top-left text-[#ffffff] text-[20px] font-[400] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"گالری تصاویر"}
      </div>
      <div className={"absolute left-[719px] top-[417px] w-[902px] h-[127px] box-border origin-top-left text-[#000000] text-[20px] font-[400] text-justify [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"فلسفه کاری در فرامید مبتنی بر احترام و اخلاق حرفه‌ای می‌باشد که منجر به ایجاد محیط کاری دوسـتانه بر اساس معیارهای بین‌المللی و توأم با پیشرفت تمامی اعضا می‌گردد. چالش‌های حرفه‌ای کار در یک سازمان بزرگ، آموخته‌های علمی و مهارت‌های عملی اعضای سازمان را افزایش می‌دهد و موفقیت‌های روز افزون را به ارمغان خواهد آورد."}
      </div>
      <div className={"absolute left-[1488px] top-[359px] w-[133px] h-[36px] box-border origin-top-left text-[#000000] text-[24px] font-[600] text-justify [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"اخذ نمایندگی"}
      </div>
      <div className={"absolute left-[1488px] top-[359px] w-[133px] h-[36px] box-border origin-top-left text-[#000000] text-[24px] font-[600] text-justify [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"اخذ نمایندگی"}
      </div>
      <div className={"absolute left-[0px] top-[904px] w-[1744px] h-[561px] box-border origin-top-left bg-[#000000]"} />
      <div className={"absolute left-[119px] top-[1274px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[13px] top-[8px] w-[11px] h-[20px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[11px] h-[20px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11 20" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 11 0 L 12.15 0 C 12.15 -0.635 11.635 -1.15 11 -1.15 L 11 0 Z M 4.465 1.464 L 5.278 2.278 L 5.278 2.278 L 4.465 1.464 Z M 3 8 L 3 9.15 C 3.635 9.15 4.15 8.635 4.15 8 L 3 8 Z M 0 8 L 0 6.85 C -0.635 6.85 -1.15 7.365 -1.15 8 L 0 8 Z M 0 12 L -1.15 12 C -1.15 12.635 -0.635 13.15 0 13.15 L 0 12 Z M 3 12 L 4.15 12 C 4.15 11.365 3.635 10.85 3 10.85 L 3 12 Z M 3 20 L 1.85 20 C 1.85 20.635 2.365 21.15 3 21.15 L 3 20 Z M 7 20 L 7 21.15 C 7.635 21.15 8.15 20.635 8.15 20 L 7 20 Z M 7 12 L 7 10.85 C 6.365 10.85 5.85 11.365 5.85 12 L 7 12 Z M 10 12 L 10 13.15 C 10.528 13.15 10.988 12.791 11.116 12.279 L 10 12 Z M 11 8 L 12.116 8.279 C 12.202 7.935 12.124 7.571 11.906 7.292 C 11.689 7.013 11.354 6.85 11 6.85 L 11 8 Z M 7 8 L 5.85 8 C 5.85 8.635 6.365 9.15 7 9.15 L 7 8 Z M 7.293 4.293 L 6.48 3.48 L 6.48 3.48 L 7.293 4.293 Z M 11 4 L 11 5.15 C 11.635 5.15 12.15 4.635 12.15 4 L 11 4 Z M 11 -1.15 L 8 -1.15 L 8 1.15 L 11 1.15 L 11 -1.15 Z M 8 -1.15 C 6.369 -1.15 4.805 -0.502 3.651 0.651 L 5.278 2.278 C 6 1.556 6.979 1.15 8 1.15 L 8 -1.15 Z M 3.651 0.651 C 2.498 1.805 1.85 3.369 1.85 5 L 4.15 5 C 4.15 3.979 4.556 3 5.278 2.278 L 3.651 0.651 Z M 1.85 5 L 1.85 8 L 4.15 8 L 4.15 5 L 1.85 5 Z M 3 6.85 L 0 6.85 L 0 9.15 L 3 9.15 L 3 6.85 Z M -1.15 8 L -1.15 12 L 1.15 12 L 1.15 8 L -1.15 8 Z M 0 13.15 L 3 13.15 L 3 10.85 L 0 10.85 L 0 13.15 Z M 1.85 12 L 1.85 20 L 4.15 20 L 4.15 12 L 1.85 12 Z M 3 21.15 L 7 21.15 L 7 18.85 L 3 18.85 L 3 21.15 Z M 8.15 20 L 8.15 12 L 5.85 12 L 5.85 20 L 8.15 20 Z M 7 13.15 L 10 13.15 L 10 10.85 L 7 10.85 L 7 13.15 Z M 11.116 12.279 L 12.116 8.279 L 9.884 7.721 L 8.884 11.721 L 11.116 12.279 Z M 11 6.85 L 7 6.85 L 7 9.15 L 11 9.15 L 11 6.85 Z M 8.15 8 L 8.15 5 L 5.85 5 L 5.85 8 L 8.15 8 Z M 8.15 5 C 8.15 5.04 8.134 5.078 8.106 5.106 L 6.48 3.48 C 6.077 3.883 5.85 4.43 5.85 5 L 8.15 5 Z M 8.106 5.106 C 8.078 5.134 8.04 5.15 8 5.15 L 8 2.85 C 7.43 2.85 6.883 3.076 6.48 3.48 L 8.106 5.106 Z M 8 5.15 L 11 5.15 L 11 2.85 L 8 2.85 L 8 5.15 Z M 12.15 4 L 12.15 0 L 9.85 0 L 9.85 4 L 12.15 4 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[181px] top-[1274px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[7px] top-[9px] w-[22.069px] h-[18px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[22.069px] h-[18px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 22.069 18" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 22.069 0.01 L 23.23 0.472 C 23.428 -0.025 23.288 -0.592 22.882 -0.94 C 22.476 -1.287 21.893 -1.338 21.433 -1.066 L 22.069 0.01 Z M 18.919 1.545 L 17.976 2.365 C 18.299 2.736 18.809 2.884 19.28 2.742 L 18.919 1.545 Z M 16.619 0.134 L 16.922 -1.078 L 16.922 -1.078 L 16.619 0.134 Z M 11.81 1.97 L 12.844 2.672 L 12.844 2.672 L 11.81 1.97 Z M 11.034 4.554 L 12.284 4.554 C 12.284 4.549 12.284 4.543 12.284 4.538 L 11.034 4.554 Z M 11.034 5.557 L 11.067 6.807 C 11.744 6.789 12.284 6.235 12.284 5.557 L 11.034 5.557 Z M 5.95 4.419 L 6.512 3.303 L 6.512 3.303 L 5.95 4.419 Z M 2.006 1.013 L 3.029 0.295 C 2.77 -0.074 2.333 -0.275 1.885 -0.231 C 1.437 -0.187 1.047 0.094 0.864 0.506 L 2.006 1.013 Z M 7.022 14.054 L 7.724 15.088 C 8.1 14.833 8.307 14.395 8.267 13.943 C 8.227 13.491 7.944 13.096 7.53 12.912 L 7.022 14.054 Z M 0 16.06 L 0.05 14.811 C -0.529 14.788 -1.047 15.165 -1.204 15.723 C -1.36 16.28 -1.113 16.872 -0.607 17.153 L 0 16.06 Z M 20.063 4.524 L 21.313 4.524 L 21.313 4.52 L 20.063 4.524 Z M 19.982 3.692 L 19.105 2.802 C 18.808 3.095 18.676 3.516 18.755 3.926 L 19.982 3.692 Z M 22.069 0.01 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.432 -1.065 21.431 -1.065 21.429 -1.064 C 21.426 -1.062 21.421 -1.059 21.414 -1.055 C 21.401 -1.047 21.38 -1.035 21.353 -1.019 C 21.299 -0.988 21.219 -0.942 21.119 -0.886 C 20.92 -0.772 20.643 -0.619 20.333 -0.455 C 19.683 -0.112 18.992 0.217 18.559 0.348 L 19.28 2.742 C 19.972 2.533 20.856 2.096 21.5 1.756 C 21.837 1.578 22.136 1.412 22.351 1.29 C 22.459 1.229 22.546 1.179 22.607 1.144 C 22.637 1.126 22.661 1.112 22.678 1.102 C 22.686 1.097 22.692 1.094 22.697 1.091 C 22.699 1.09 22.701 1.089 22.702 1.088 C 22.703 1.087 22.704 1.087 22.704 1.087 C 22.704 1.087 22.704 1.087 22.704 1.087 C 22.705 1.086 22.705 1.086 22.705 1.086 C 22.705 1.086 22.705 1.086 22.069 0.01 Z M 19.862 0.725 C 19.09 -0.163 18.064 -0.793 16.922 -1.078 L 16.316 1.347 C 16.96 1.508 17.54 1.864 17.976 2.365 L 19.862 0.725 Z M 16.922 -1.078 C 15.781 -1.364 14.579 -1.292 13.48 -0.872 L 14.371 1.463 C 14.992 1.226 15.671 1.186 16.316 1.347 L 16.922 -1.078 Z M 13.48 -0.872 C 12.381 -0.453 11.437 0.294 10.776 1.268 L 12.844 2.672 C 13.217 2.122 13.75 1.7 14.371 1.463 L 13.48 -0.872 Z M 10.776 1.268 C 10.115 2.241 9.769 3.394 9.785 4.571 L 12.284 4.538 C 12.275 3.873 12.471 3.222 12.844 2.672 L 10.776 1.268 Z M 9.784 4.554 L 9.784 5.557 L 12.284 5.557 L 12.284 4.554 L 9.784 4.554 Z M 11.002 4.308 C 9.445 4.348 7.903 4.003 6.512 3.303 L 5.388 5.536 C 7.147 6.421 9.098 6.858 11.067 6.807 L 11.002 4.308 Z M 6.512 3.303 C 5.121 2.603 3.924 1.569 3.029 0.295 L 0.983 1.732 C 2.115 3.343 3.628 4.65 5.388 5.536 L 6.512 3.303 Z M 2.006 1.013 C 0.864 0.506 0.864 0.506 0.863 0.507 C 0.863 0.507 0.863 0.508 0.863 0.508 C 0.862 0.509 0.862 0.51 0.861 0.512 C 0.86 0.514 0.859 0.517 0.857 0.521 C 0.854 0.529 0.85 0.538 0.845 0.55 C 0.835 0.574 0.821 0.606 0.805 0.646 C 0.772 0.727 0.728 0.841 0.676 0.984 C 0.573 1.27 0.439 1.676 0.31 2.174 C 0.054 3.163 -0.19 4.546 -0.12 6.086 C -0.05 7.631 0.339 9.359 1.373 10.992 C 2.413 12.634 4.057 14.104 6.514 15.196 L 7.53 12.912 C 5.472 11.997 4.233 10.834 3.485 9.655 C 2.733 8.467 2.432 7.186 2.377 5.972 C 2.322 4.753 2.516 3.628 2.731 2.8 C 2.837 2.388 2.946 2.057 3.027 1.834 C 3.067 1.723 3.1 1.638 3.122 1.585 C 3.133 1.558 3.141 1.539 3.145 1.528 C 3.148 1.523 3.149 1.52 3.15 1.518 C 3.15 1.518 3.15 1.518 3.15 1.518 C 3.15 1.518 3.15 1.519 3.149 1.519 C 3.149 1.519 3.149 1.52 3.149 1.52 C 3.149 1.52 3.149 1.521 2.006 1.013 Z M 6.32 13.02 C 4.475 14.272 2.278 14.9 0.05 14.811 L -0.05 17.309 C 2.712 17.419 5.437 16.641 7.724 15.088 L 6.32 13.02 Z M -0.607 17.153 C 4.253 19.853 9.718 19.884 14.004 17.603 C 18.321 15.305 21.313 10.73 21.313 4.524 L 18.813 4.524 C 18.813 9.855 16.288 13.555 12.83 15.396 C 9.341 17.253 4.776 17.283 0.607 14.968 L -0.607 17.153 Z M 21.313 4.52 C 21.312 4.163 21.277 3.807 21.21 3.457 L 18.755 3.926 C 18.793 4.125 18.812 4.326 18.813 4.528 L 21.313 4.52 Z M 20.86 4.582 C 21.538 3.913 22.139 2.816 22.53 2.027 C 22.738 1.607 22.912 1.221 23.034 0.941 C 23.094 0.801 23.143 0.686 23.176 0.605 C 23.193 0.564 23.206 0.532 23.215 0.51 C 23.22 0.499 23.223 0.49 23.226 0.484 C 23.227 0.48 23.228 0.478 23.229 0.476 C 23.229 0.475 23.23 0.474 23.23 0.473 C 23.23 0.473 23.23 0.473 23.23 0.473 C 23.23 0.473 23.23 0.472 23.23 0.472 C 23.23 0.472 23.23 0.472 22.069 0.01 C 20.907 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.907 -0.452 C 20.907 -0.451 20.907 -0.45 20.906 -0.448 C 20.904 -0.444 20.902 -0.438 20.898 -0.429 C 20.891 -0.412 20.881 -0.386 20.866 -0.351 C 20.838 -0.282 20.795 -0.18 20.74 -0.055 C 20.631 0.198 20.475 0.544 20.29 0.917 C 19.893 1.717 19.451 2.46 19.105 2.802 L 20.86 4.582 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[243px] top-[1274px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[6px] top-[5px] w-[24px] h-[24px] box-border origin-top-left"}>
          <div className={"absolute left-[2px] top-[2px] w-[20px] h-[20px] box-border origin-top-left"}>
            <div className={"absolute left-[5.556px] top-[5.556px] w-[8.889px] h-[8.889px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 8.889 8.889" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 4.444 10.039 C 7.534 10.039 10.039 7.534 10.039 4.444 L 7.739 4.444 C 7.739 6.264 6.264 7.739 4.444 7.739 L 4.444 10.039 Z M 10.039 4.444 C 10.039 1.355 7.534 -1.15 4.444 -1.15 L 4.444 1.15 C 6.264 1.15 7.739 2.625 7.739 4.444 L 10.039 4.444 Z M 4.444 -1.15 C 1.355 -1.15 -1.15 1.355 -1.15 4.444 L 1.15 4.444 C 1.15 2.625 2.625 1.15 4.444 1.15 L 4.444 -1.15 Z M -1.15 4.444 C -1.15 7.534 1.355 10.039 4.444 10.039 L 4.444 7.739 C 2.625 7.739 1.15 6.264 1.15 4.444 L -1.15 4.444 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[20px] h-[20px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 20 20" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 1.25 14.444 L 1.25 5.556 L -1.25 5.556 L -1.25 14.444 L 1.25 14.444 Z M 1.25 5.556 C 1.25 3.178 3.178 1.25 5.556 1.25 L 5.556 -1.25 C 1.797 -1.25 -1.25 1.797 -1.25 5.556 L 1.25 5.556 Z M 5.556 1.25 L 14.444 1.25 L 14.444 -1.25 L 5.556 -1.25 L 5.556 1.25 Z M 14.444 1.25 C 16.822 1.25 18.75 3.178 18.75 5.556 L 21.25 5.556 C 21.25 1.797 18.203 -1.25 14.444 -1.25 L 14.444 1.25 Z M 18.75 5.556 L 18.75 14.444 L 21.25 14.444 L 21.25 5.556 L 18.75 5.556 Z M 18.75 14.444 C 18.75 16.822 16.822 18.75 14.444 18.75 L 14.444 21.25 C 18.203 21.25 21.25 18.203 21.25 14.444 L 18.75 14.444 Z M 14.444 18.75 L 5.556 18.75 L 5.556 21.25 L 14.444 21.25 L 14.444 18.75 Z M 5.556 18.75 C 3.178 18.75 1.25 16.822 1.25 14.444 L -1.25 14.444 C -1.25 18.203 1.797 21.25 5.556 21.25 L 5.556 18.75 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[16.111px] top-[3.888px] w-[0.012px] h-[0.013px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 1 1" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M -0.929 -0.823 C -1.391 -0.31 -1.349 0.48 -0.836 0.942 C -0.323 1.404 0.467 1.362 0.929 0.849 L -0.929 -0.823 Z M 0.941 0.836 C 1.403 0.323 1.361 -0.467 0.848 -0.929 C 0.335 -1.391 -0.456 -1.349 -0.917 -0.836 L 0.941 0.836 Z M 0.929 0.849 L 0.941 0.836 L -0.917 -0.836 L -0.929 -0.823 L 0.929 0.849 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[305px] top-[1274px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[7px] top-[7px] w-[22px] h-[22px] box-border origin-top-left overflow-hidden"}>
          <div className={"absolute left-[0px] top-[0px] w-[22px] h-[22px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/d3113ae5d38f42325172d25ee512520ef84dd396.webp')"}} />
          <div className={"absolute left-[-3px] top-[-3px] w-[28px] h-[28px] box-border origin-top-left bg-[#ffffff]"} />
        </div>
      </div>
      <div className={"absolute left-[109px] top-[1024px] w-[284.172px] h-[71.898px] box-border origin-top-left"}>
        <div className={"absolute left-[239.458px] top-[16.191px] w-[5.898px] h-[32.381px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 5.898 32.381" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 5.898 0 L 0 0 L 0 32.381 L 5.898 32.381 L 5.898 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[284.172px] h-[71.898px] box-border origin-top-left"}>
          <div className={"absolute left-[198.264px] top-[16.191px] w-[33.869px] h-[32.473px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 33.869 32.473" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 16.934 24.057 L 27.97 13.355 L 27.97 32.473 L 33.869 32.473 L 33.869 0 L 16.934 16.557 L 0 0 L 0 32.473 L 5.803 32.473 L 5.803 13.355 L 16.934 24.057 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[0px] top-[0px] w-[284.172px] h-[71.898px] box-border origin-top-left"}>
            <div className={"absolute left-[251.731px] top-[16.191px] w-[32.441px] h-[32.381px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 32.441 32.381" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 26.543 14.91 C 26.543 9.788 22.167 5.671 16.934 5.671 L 5.898 5.671 L 5.898 26.802 L 16.934 26.802 C 22.262 26.802 26.543 22.594 26.543 17.563 L 26.543 15.002 L 26.543 14.91 Z M 0 5.671 L 0 0 L 16.934 0 C 25.497 0 32.441 6.678 32.441 14.91 L 32.441 17.471 C 32.441 25.704 25.497 32.381 16.934 32.381 L 0 32.381 L 0 5.58 L 0 5.671 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[157.451px] top-[16.282px] w-[35.486px] h-[32.381px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 35.486 32.381" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 35.486 16.191 C 35.486 7.226 27.875 0 18.647 0 L 16.839 0 C 7.611 0 0 7.318 0 16.191 C 0 25.064 7.611 32.381 16.839 32.381 L 18.647 32.381 C 27.97 32.381 35.486 25.064 35.486 16.191 Z M 17.79 4.94 C 24.165 4.94 29.397 9.971 29.397 16.099 C 29.397 22.228 24.165 27.259 17.79 27.259 C 11.416 27.259 6.184 22.228 6.184 16.099 C 6.184 9.971 11.416 4.94 17.79 4.94 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[122.155px] top-[16.282px] w-[31.014px] h-[32.381px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 31.014 32.381" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 23.404 32.381 L 31.014 32.381 L 21.596 21.679 C 22.833 21.405 24.069 21.039 25.116 20.49 C 28.636 18.66 31.014 15.002 31.014 10.977 C 31.014 4.94 25.877 0 19.598 0 L 0 0 L 0 32.381 L 5.803 32.381 L 5.803 5.58 L 19.598 5.58 C 22.642 5.58 25.116 7.958 25.116 10.885 C 25.116 13.812 22.642 16.191 19.598 16.191 L 9.133 16.191 L 14.08 21.771 L 23.404 32.29 L 23.404 32.381 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[284.077px] h-[71.898px] box-border origin-top-left"}>
              <div className={"absolute left-[65.168px] top-[16.191px] w-[26.924px] h-[32.473px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26.924 32.473" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 0 0 L 26.924 0 L 23.499 5.671 L 5.803 5.671 L 5.803 13.446 L 21.12 13.446 L 18.361 19.026 L 5.803 19.026 L 5.803 22.777 L 5.803 26.802 L 5.803 32.473 L 0 32.473 L 0 19.026 L 0 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[0px] top-[0px] w-[56.606px] h-[62.933px] box-border origin-top-left"}>
                <div className={"absolute left-[0px] top-[0px] w-[39.006px] h-[52.78px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 39.006 52.78" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 10.75 52.78 L 0 47.017 L 0 15.55 L 28.731 0 L 39.006 5.763 L 10.75 21.953 L 10.75 52.78 Z"} fill={"#ffffff"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[23.499px] top-[12.532px] w-[33.107px] h-[50.401px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 33.107 50.401" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 26.802 L 0 15.367 L 27.59 0 L 33.107 3.019 L 33.107 34.76 L 4.757 50.401 L 0 47.566 L 0 41.071 L 22.642 28.448 L 22.452 14.453 L 0 26.802 Z"} fill={"#ec1c24"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
              <div className={"absolute left-[84.862px] top-[16.191px] w-[34.439px] h-[32.473px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 34.439 32.473" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 17.22 0 L 0 32.473 L 6.279 32.473 L 17.22 11.8 L 28.16 32.473 L 34.439 32.473 L 17.22 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[162.588px] top-[56.439px] w-[121.489px] h-[15.459px] box-border origin-top-left"}>
                <div className={"absolute left-[-0px] top-[0.092px] w-[14.366px] h-[15.367px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 14.366 15.367" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 14.366 15.093 L 11.892 15.093 C 11.797 14.636 11.702 14.087 11.607 13.629 C 10.75 14.727 9.228 15.367 7.04 15.367 C 2.569 15.367 0 12.074 0 7.867 C 0 3.659 2.664 0 7.611 0 C 12.558 0 13.985 2.195 14.27 4.665 L 10.941 4.665 C 10.655 3.659 9.799 2.47 7.516 2.47 C 5.232 2.47 3.425 5.031 3.425 7.684 C 3.425 10.336 4.471 12.806 7.516 12.806 C 10.56 12.806 10.941 10.885 10.941 9.605 C 10.941 9.513 7.516 9.513 7.516 9.513 L 7.516 6.86 L 14.175 6.86 L 14.175 15.184 L 14.366 15.093 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[28.731px] top-[0.274px] w-[11.987px] h-[14.91px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.987 14.91" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 3.235 8.964 L 3.235 14.91 L 0 14.91 L 0 0 L 6.755 0 C 10.084 0 11.987 1.829 11.987 4.116 C 11.987 6.403 10.846 7.226 9.704 7.592 C 10.465 7.867 11.607 8.598 11.607 11.251 L 11.607 11.983 C 11.607 12.989 11.607 14.087 11.797 14.819 L 8.657 14.819 C 8.372 14.178 8.372 13.081 8.372 11.434 L 8.372 11.251 C 8.372 9.605 7.991 8.873 5.423 8.873 L 3.235 8.873 L 3.235 8.964 Z M 3.235 6.403 L 5.994 6.403 C 7.801 6.403 8.562 5.763 8.562 4.482 C 8.562 3.202 7.706 2.561 6.089 2.561 L 3.235 2.561 L 3.235 6.403 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[53.562px] top-[0px] w-[15.032px] h-[15.367px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 15.032 15.367" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 15.032 7.684 C 15.032 11.8 12.463 15.367 7.421 15.367 C 2.378 15.367 0 11.983 0 7.684 C 0 3.385 2.854 0 7.611 0 C 12.368 0 15.032 3.019 15.032 7.592 L 15.032 7.684 Z M 3.52 7.684 C 3.52 10.611 4.852 12.806 7.611 12.806 C 10.37 12.806 11.607 10.428 11.607 7.775 C 11.607 5.122 10.37 2.744 7.516 2.744 C 4.662 2.744 3.52 4.848 3.52 7.684 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[82.388px] top-[0.274px] w-[12.939px] h-[15.093px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 12.939 15.093" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 3.235 0 L 3.235 8.873 C 3.235 11.709 4.757 12.532 6.469 12.532 C 8.182 12.532 9.609 11.526 9.609 8.873 L 9.609 0 L 12.939 0 L 12.939 8.69 C 12.939 13.812 9.799 15.093 6.469 15.093 C 3.139 15.093 0 13.721 0 8.781 L 0 0 L 3.33 0 L 3.235 0 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[109.597px] top-[0.274px] w-[11.892px] h-[14.91px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.892 14.91" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 0 L 6.374 0 C 9.704 0 11.892 1.738 11.892 4.574 C 11.892 7.409 9.323 9.33 6.279 9.33 L 3.33 9.33 L 3.33 14.91 L 0 14.91 L 0 0 Z M 3.33 6.769 L 5.898 6.769 C 7.421 6.769 8.562 6.22 8.562 4.665 C 8.562 3.11 7.421 2.561 5.994 2.561 L 3.33 2.561 L 3.33 6.769 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[1530px] top-[1044px] w-[90px] h-[25px] box-border origin-top-left text-[#ffffff] text-[20px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"تماس با ما"}
      </div>
      <div className={"absolute left-[989px] top-[1043px] w-[63px] h-[25px] box-border origin-top-left text-[#ffffff] text-[20px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"پیوندها"}
      </div>
      <div className={"absolute left-[1175px] top-[1091px] w-[452px] h-[18px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"آدرس کارخانه: کیلومتر 20 جاده خاوران، روبروی فرون آباد اول، کوچه صاحب الزمان"}
      </div>
      <div className={"absolute left-[1129px] top-[1122px] w-[491px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"آدرس دفترمرکزی و شوروم :  اتوبان ارتش. اقدسیه. اراج. نبش اراج. ساختمان نگین پلاک 156"}
      </div>
      <div className={"absolute left-[1364px] top-[1160px] w-[256px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"شماره تماس دفترمرکزی و شورم :  02178328000"}
      </div>
      <div className={"absolute left-[1444px] top-[1198px] w-[176px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"فکس دفتر مرکزی :  02122823107"}
      </div>
      <div className={"absolute left-[1385px] top-[544px] w-[236px] h-[30px] box-border origin-top-left text-[#2d2d2d] text-[20px] font-[500] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {" دفتر مرکزی :  02122823107"}
      </div>
      <div className={"absolute left-[1397px] top-[1236px] w-[223px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"شماره تماس : 02136849085 - 02136849086"}
      </div>
      <div className={"absolute left-[1514px] top-[1274px] w-[106px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"فکس : 02136849474"}
      </div>
      <div className={"absolute left-[1468px] top-[1312px] w-[152px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"ایمیل :     info@faromid.com"}
      </div>
      <div className={"absolute left-[789px] top-[1091px] w-[276px] h-[170px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"صنایع چوب ایران\nاتحادیه تولید کنندگان و صادر کنندگان مبل ایران\nتعاونی فرآورده های چوبی\n انجمن روکش های مصنوعی\nشورای ملی مبلمان\nگمرک جمهوری اسلامی ایران\nوزارت صنعت ، معدن و تجارت\nاستاندارد ایران\nسامانه جامع تجارت\nبانک مرکزی      "}
      </div>
      <div className={"absolute left-[616px] top-[1093px] w-[132px] h-[153px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"اتاق بازرگانی\nاتاق بازرگانی ایران\nاتاق بازرگانی آلمان\nاتاق بازرگانی ایتالیا\n اتاق بازرگانی اتریش\nاتاق بازرگانی چین\nبهین یاب\nمیانگین موزون سنا\nبازار طلا و ارز"}
      </div>
      <div className={"absolute left-[1179px] top-[1060.5px] w-[348px] h-[0px] box-border origin-top-left"}>
        <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 348 1" preserveAspectRatio="none" className="block overflow-visible">
          <path d={"M 348 -1 L 0 -1 L 0 1 L 348 1 L 348 -1 Z"} fill={"#ff0000"} fillRule="nonzero" />
        </svg>
      </div>
      <div className={"absolute left-[130px] top-[1126px] w-[250px] h-[40px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-center [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"فرامید تولید کننده ام دی اف دورو سینکرونایز، \nفوق برجسته و سوپر مات-آنتی فینگر"}
      </div>
      <div className={"absolute left-[1401px] top-[663px] w-[203px] h-[59.055px] box-border origin-top-left rounded-[4px] bg-[#e50000]"} />
      <div className={"absolute left-[1417px] top-[672px] w-[186px] h-[63px] box-border origin-top-left text-[#ffffff] text-[22px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"فرم اخذ نمایندگی"}
      </div>
      <div className={"absolute left-[213px] top-[73px] w-[269.595px] h-[73.094px] box-border origin-top-left"}>
        <div className={"absolute left-[61.944px] top-[16.014px] w-[25.516px] h-[32.028px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 25.516 32.028" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 0 0 L 25.516 0 L 22.349 5.631 L 5.455 5.631 L 5.455 13.198 L 20.061 13.198 L 17.422 18.829 L 5.455 18.829 L 5.455 22.525 L 5.455 26.396 L 5.455 32.028 L 0 32.028 L 0 18.829 L 0 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[53.673px] h-[62.119px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[37.131px] h-[52.089px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 37.131 52.089" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 10.207 52.089 L 0 46.458 L 0 15.486 L 27.276 0 L 37.131 5.807 L 10.207 21.645 L 10.207 52.089 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[22.35px] top-[12.318px] w-[31.324px] h-[49.801px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 31.324 49.801" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 0 26.572 L 0 15.31 L 26.22 0 L 31.324 3.168 L 31.324 34.491 L 4.575 49.801 L 0 46.985 L 0 40.65 L 21.469 28.156 L 21.293 14.43 L 0 26.572 Z"} fill={"#ec1c24"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
        <div className={"absolute left-[238.799px] top-[16.014px] w-[30.796px] h-[32.204px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 30.796 32.204" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 25.34 14.782 C 25.34 9.855 21.293 5.631 16.19 5.631 L 5.631 5.631 L 5.631 26.572 L 16.19 26.572 C 21.293 26.572 25.34 22.525 25.34 17.422 L 25.34 14.782 Z M 0 5.631 L 0 0 L 16.014 0 C 24.109 0 30.796 6.687 30.796 14.782 L 30.796 17.422 C 30.796 25.516 24.109 32.204 16.014 32.204 L 0 32.204 L 0 5.807 L 0 5.631 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[227.183px] top-[16.014px] w-[5.631px] h-[32.028px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 5.631 32.028" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 5.631 0 L 0 0 L 0 32.028 L 5.631 32.028 L 5.631 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[188.118px] top-[16.014px] w-[32.204px] h-[32.028px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 32.204 32.028" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 16.19 23.757 L 26.572 13.198 L 26.572 32.028 L 32.204 32.028 L 32.204 0 L 16.19 16.366 L 0 0 L 0 32.028 L 5.631 32.028 L 5.631 13.198 L 16.19 23.757 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[149.404px] top-[16.014px] w-[33.787px] h-[32.028px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 33.787 32.028" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 33.787 16.014 C 33.787 7.215 26.572 0 17.774 0 L 16.014 0 C 7.215 0 0 7.215 0 16.014 C 0 24.813 7.215 32.028 16.014 32.028 L 17.774 32.028 C 26.572 32.028 33.787 24.813 33.787 16.014 Z M 16.894 4.927 C 22.877 4.927 27.804 9.855 27.804 16.014 C 27.804 22.173 22.877 26.924 16.894 26.924 C 10.91 26.924 5.807 21.997 5.807 16.014 C 5.807 10.031 10.735 4.927 16.894 4.927 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[80.597px] top-[16.014px] w-[32.555px] h-[32.028px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 32.555 32.028" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 16.366 0 L 0 32.028 L 5.983 32.028 L 16.366 11.614 L 26.748 32.028 L 32.555 32.028 L 16.366 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[115.969px] top-[16.19px] w-[29.388px] h-[32.028px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 29.388 32.028" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 22.173 31.852 L 29.388 31.852 L 20.413 21.293 C 21.645 21.117 22.701 20.589 23.757 20.061 C 27.1 18.301 29.388 14.606 29.388 10.734 C 29.388 4.751 24.461 0 18.653 0 L 0 0 L 0 32.028 L 5.455 32.028 L 5.455 5.631 L 18.477 5.631 C 21.293 5.631 23.757 7.919 23.757 10.91 C 23.757 13.902 21.469 16.19 18.477 16.19 L 8.623 16.19 L 13.374 21.645 L 22.173 32.028 L 22.173 31.852 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[152.683px] top-[57.784px] w-[115.089px] h-[15.31px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0.176px] w-[13.55px] h-[15.134px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 13.55 15.134" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 13.374 14.782 L 11.086 14.782 C 11.086 14.254 10.91 13.902 10.91 13.374 C 10.031 14.43 8.623 15.134 6.687 15.134 C 2.464 15.134 0 11.966 0 7.743 C 0 3.52 2.64 0 7.215 0 C 11.79 0 13.198 2.112 13.55 4.575 L 10.383 4.575 C 10.031 3.52 9.327 2.464 7.215 2.464 C 5.103 2.464 3.344 4.927 3.344 7.567 C 3.344 10.207 4.399 12.67 7.215 12.67 C 10.031 12.67 10.383 10.735 10.383 9.503 L 7.215 9.503 L 7.215 6.863 L 13.55 6.863 L 13.55 15.134 L 13.374 14.782 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[26.749px] top-[0.176px] w-[11.438px] h-[14.782px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.438 14.782" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 3.168 8.799 L 3.168 14.606 L 0 14.606 L 0 0 L 6.511 0 C 9.679 0 11.438 1.76 11.438 4.047 C 11.438 6.335 10.383 7.039 9.327 7.567 C 10.031 7.919 11.086 8.623 11.086 11.262 L 11.086 11.966 C 11.086 13.022 11.086 14.078 11.262 14.782 L 8.271 14.782 C 8.095 14.078 7.919 13.022 7.919 11.438 C 7.919 9.679 7.567 8.799 5.103 8.799 L 2.992 8.799 L 3.168 8.799 Z M 3.168 6.335 L 5.807 6.335 C 7.567 6.335 8.271 5.631 8.271 4.399 C 8.271 3.168 7.567 2.464 5.983 2.464 L 3.168 2.464 L 3.168 6.159 L 3.168 6.335 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[50.506px] top-[0px] w-[14.254px] h-[15.134px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 14.254 15.134" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 14.254 7.567 C 14.254 11.614 11.79 15.134 7.039 15.134 C 2.288 15.134 0 11.79 0 7.567 C 0 3.344 2.64 0 7.215 0 C 11.79 0 14.254 2.992 14.254 7.567 Z M 3.344 7.567 C 3.344 10.383 4.575 12.67 7.215 12.67 C 9.855 12.67 11.086 10.383 11.086 7.743 C 11.086 5.103 10.031 2.816 7.215 2.816 C 4.399 2.816 3.344 4.927 3.344 7.743 L 3.344 7.567 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[77.604px] top-[0.176px] w-[12.318px] h-[14.958px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 12.318 14.958" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 3.168 0 L 3.168 8.799 C 3.168 11.614 4.575 12.494 6.159 12.494 C 7.743 12.494 9.151 11.438 9.151 8.799 L 9.151 0 L 12.318 0 L 12.318 8.623 C 12.318 13.726 9.327 14.958 6.159 14.958 C 2.992 14.958 0 13.55 0 8.799 L 0 0.176 L 3.168 0.176 L 3.168 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[103.65px] top-[0.176px] w-[11.438px] h-[14.606px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.438 14.606" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 0 0 L 6.159 0 C 9.327 0 11.438 1.76 11.438 4.575 C 11.438 7.391 8.975 9.151 6.159 9.151 L 3.344 9.151 L 3.344 14.606 L 0.176 14.606 L 0.176 0 L 0 0 Z M 3.168 6.687 L 5.631 6.687 C 7.039 6.687 8.095 6.159 8.095 4.575 C 8.095 2.992 7.039 2.464 5.631 2.464 L 3.168 2.464 L 3.168 6.687 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[57px] top-[254px] w-[1593px] h-[518px] box-border origin-top-left border-[1px] border-solid border-[#ff0000]"} />
      {/* Native accessible navigation and interactive regions */}
      <Link href="/" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[90px] top-[60px] w-[300px] h-[100px]" aria-label="صفحه اصلی فرامید" />
      <Link href={"/"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1502px] top-[90px] w-[118px] h-[40px]" aria-label={"صفحه اصلی"} />
      <Link href={"/products"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1368px] top-[91px] w-[105px] h-[40px]" aria-label={"محصولات"} />
      <Link href={"/about"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[859px] top-[91px] w-[84px] h-[40px]" aria-label={"درباره ما"} />
      <Link href={"/contact"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[575px] top-[94px] w-[107px] h-[40px]" aria-label={"تماس با ما"} />
      <Link href={"/careers"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[711px] top-[92px] w-[120px] h-[40px]" aria-label={"همکاری با ما"} />
      <Link href={"/exhibitions"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[971px] top-[93px] w-[113px] h-[40px]" aria-label={"نمایشگاه ها"} />
      <Link href={"/textures"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1273px] top-[83px] w-[72px] h-[52px]" aria-label={"تکسچر"} />
      <Link href={"/gallery"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1110px] top-[89px] w-[120px] h-[40px]" aria-label={"گالری تصاویر"} />
      <a href={"mailto:info@faromid.com?subject=%D8%AF%D8%B1%D8%AE%D9%88%D8%A7%D8%B3%D8%AA%20%D8%A7%D8%AE%D8%B0%20%D9%86%D9%85%D8%A7%DB%8C%D9%86%D8%AF%DA%AF%DB%8C"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1401px] top-[656px] w-[218px] h-[95px]" aria-label={"درخواست اخذ نمایندگی"} />
    </>
  );
}
