"use client";
/* Pure JSX component. Desktop geometry and media are authored at build time,
 * so no design JSON, layout interpreter or external design service is used.
 * The absolute utility classes intentionally preserve the legacy pixel-perfect artwork. */
import Image from 'next/image';
import Link from 'next/link';

export function AboutDesktop({onOpenImage}:{onOpenImage:(src:string)=>void}) {
  return (
    <>
      {/* Static Tailwind-rendered desktop artwork */}
      <div className={"absolute left-[0px] top-[-1px] w-[1793px] h-[710px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/backgrounds/3a83e1dd6e6f470491bea0c34a5df899390ba83b.webp')"}} />
      <div className={"absolute left-[548px] top-[73px] w-[1124px] h-[75px] box-border origin-top-left opacity-[0.8] rounded-[5px] bg-[#ffffff]"} />
      <div className={"absolute left-[244px] top-[72.507px] w-[284px] h-[75.493px] box-border origin-top-left"}>
        <div className={"absolute left-[239.313px] top-[17px] w-[5.895px] h-[34.001px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 5.895 34.001" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 5.895 0 L 0 0 L 0 34.001 L 5.895 34.001 L 5.895 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[284px] h-[75.493px] box-border origin-top-left"}>
          <div className={"absolute left-[198.144px] top-[17px] w-[33.848px] h-[34.097px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 33.848 34.097" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 16.924 25.261 L 27.953 14.023 L 27.953 34.097 L 33.848 34.097 L 33.848 0 L 16.924 17.385 L 0 0 L 0 34.097 L 5.8 34.097 L 5.8 14.023 L 16.924 25.261 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[0px] top-[0px] w-[284px] h-[75.493px] box-border origin-top-left"}>
            <div className={"absolute left-[251.578px] top-[17px] w-[32.422px] h-[34.001px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 32.422 34.001" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 26.527 15.656 C 26.527 10.277 22.153 5.955 16.924 5.955 L 5.895 5.955 L 5.895 28.142 L 16.924 28.142 C 22.248 28.142 26.527 23.724 26.527 18.441 L 26.527 15.752 L 26.527 15.656 Z M 0 5.955 L 0 0 L 16.924 0 C 25.481 0 32.422 7.011 32.422 15.656 L 32.422 18.345 C 32.422 26.989 25.481 34.001 16.924 34.001 L 0 34.001 L 0 5.859 L 0 5.955 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[157.355px] top-[17.096px] w-[35.464px] h-[34.001px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 35.464 34.001" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 35.464 17 C 35.464 7.588 27.858 0 18.635 0 L 16.829 0 C 7.606 0 0 7.684 0 17 C 0 26.317 7.606 34.001 16.829 34.001 L 18.635 34.001 C 27.953 34.001 35.464 26.317 35.464 17 Z M 17.78 5.187 C 24.15 5.187 29.379 10.469 29.379 16.904 C 29.379 23.34 24.15 28.622 17.78 28.622 C 11.409 28.622 6.18 23.34 6.18 16.904 C 6.18 10.469 11.409 5.187 17.78 5.187 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[122.081px] top-[17.096px] w-[30.996px] h-[34.001px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 30.996 34.001" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 23.389 34.001 L 30.996 34.001 L 21.583 22.763 C 22.819 22.475 24.055 22.091 25.101 21.515 C 28.619 19.594 30.996 15.752 30.996 11.526 C 30.996 5.187 25.861 0 19.586 0 L 0 0 L 0 34.001 L 5.8 34.001 L 5.8 5.859 L 19.586 5.859 C 22.629 5.859 25.101 8.356 25.101 11.43 C 25.101 14.503 22.629 17 19.586 17 L 9.128 17 L 14.072 22.859 L 23.389 33.905 L 23.389 34.001 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[283.905px] h-[75.493px] box-border origin-top-left"}>
              <div className={"absolute left-[65.129px] top-[17px] w-[26.907px] h-[34.097px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26.907 34.097" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 0 0 L 26.907 0 L 23.484 5.955 L 5.8 5.955 L 5.8 14.119 L 21.107 14.119 L 18.35 19.978 L 5.8 19.978 L 5.8 23.916 L 5.8 28.142 L 5.8 34.097 L 0 34.097 L 0 19.978 L 0 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[0px] top-[0px] w-[56.572px] h-[66.081px] box-border origin-top-left"}>
                <div className={"absolute left-[0px] top-[0px] w-[38.982px] h-[55.42px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 38.982 55.42" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 10.744 55.42 L 0 49.369 L 0 16.328 L 28.714 0 L 38.982 6.051 L 10.744 23.051 L 10.744 55.42 Z"} fill={"#ffffff"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[23.484px] top-[13.158px] w-[33.087px] h-[52.922px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 33.087 52.922" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 28.142 L 0 16.136 L 27.573 0 L 33.087 3.17 L 33.087 36.498 L 4.754 52.922 L 0 49.945 L 0 43.125 L 22.629 29.871 L 22.439 15.176 L 0 28.142 Z"} fill={"#ec1c24"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
              <div className={"absolute left-[84.81px] top-[17px] w-[34.418px] h-[34.097px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 34.418 34.097" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 17.209 0 L 0 34.097 L 6.275 34.097 L 17.209 12.39 L 28.143 34.097 L 34.418 34.097 L 17.209 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[162.49px] top-[59.261px] w-[121.415px] h-[16.232px] box-border origin-top-left"}>
                <div className={"absolute left-[-0px] top-[0.096px] w-[14.357px] h-[16.136px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 14.357 16.136" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 14.357 15.848 L 11.885 15.848 C 11.79 15.368 11.695 14.791 11.6 14.311 C 10.744 15.464 9.223 16.136 7.036 16.136 C 2.567 16.136 0 12.678 0 8.26 C 0 3.842 2.662 0 7.606 0 C 12.55 0 13.977 2.305 14.262 4.898 L 10.934 4.898 C 10.649 3.842 9.793 2.593 7.511 2.593 C 5.229 2.593 3.423 5.283 3.423 8.068 C 3.423 10.853 4.469 13.447 7.511 13.447 C 10.554 13.447 10.934 11.43 10.934 10.085 C 10.934 9.989 7.511 9.989 7.511 9.989 L 7.511 7.204 L 14.167 7.204 L 14.167 15.944 L 14.357 15.848 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[28.713px] top-[0.288px] w-[11.98px] h-[15.656px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.98 15.656" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 3.233 9.413 L 3.233 15.656 L 0 15.656 L 0 0 L 6.751 0 C 10.078 0 11.98 1.921 11.98 4.322 C 11.98 6.723 10.839 7.588 9.698 7.972 C 10.459 8.26 11.6 9.028 11.6 11.814 L 11.6 12.582 C 11.6 13.639 11.6 14.791 11.79 15.56 L 8.652 15.56 C 8.367 14.887 8.367 13.735 8.367 12.006 L 8.367 11.814 C 8.367 10.085 7.987 9.317 5.419 9.317 L 3.233 9.317 L 3.233 9.413 Z M 3.233 6.723 L 5.99 6.723 C 7.796 6.723 8.557 6.051 8.557 4.706 C 8.557 3.362 7.701 2.689 6.085 2.689 L 3.233 2.689 L 3.233 6.723 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[53.529px] top-[-0px] w-[15.022px] h-[16.136px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 15.022 16.136" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 15.022 8.068 C 15.022 12.39 12.455 16.136 7.416 16.136 C 2.377 16.136 0 12.582 0 8.068 C 0 3.554 2.852 0 7.606 0 C 12.36 0 15.022 3.17 15.022 7.972 L 15.022 8.068 Z M 3.518 8.068 C 3.518 11.142 4.849 13.447 7.606 13.447 C 10.364 13.447 11.6 10.949 11.6 8.164 C 11.6 5.379 10.364 2.881 7.511 2.881 C 4.659 2.881 3.518 5.091 3.518 8.068 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[82.338px] top-[0.288px] w-[12.931px] h-[15.848px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 12.931 15.848" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 3.233 0 L 3.233 9.317 C 3.233 12.294 4.754 13.159 6.465 13.159 C 8.177 13.159 9.603 12.102 9.603 9.317 L 9.603 0 L 12.931 0 L 12.931 9.125 C 12.931 14.503 9.793 15.848 6.465 15.848 C 3.138 15.848 0 14.407 0 9.221 L 0 0 L 3.328 0 L 3.233 0 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[109.531px] top-[0.288px] w-[11.885px] h-[15.656px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.885 15.656" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 0 L 6.37 0 C 9.698 0 11.885 1.825 11.885 4.802 C 11.885 7.78 9.318 9.797 6.275 9.797 L 3.328 9.797 L 3.328 15.656 L 0 15.656 L 0 0 Z M 3.328 7.108 L 5.895 7.108 C 7.416 7.108 8.557 6.531 8.557 4.898 C 8.557 3.266 7.416 2.689 5.99 2.689 L 3.328 2.689 L 3.328 7.108 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[1509px] top-[99px] w-[100px] h-[22px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"صفحه اصلی"}
      </div>
      <div className={"absolute left-[1380px] top-[101px] w-[87px] h-[19px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"محصولات"}
      </div>
      <div className={"absolute left-[895px] top-[100px] w-[66px] h-[20px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"درباره ما"}
      </div>
      <div className={"absolute left-[614px] top-[104px] w-[89px] h-[13px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"تماس با ما"}
      </div>
      <div className={"absolute left-[751px] top-[101px] w-[102px] h-[18px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"همکاری با ما"}
      </div>
      <div className={"absolute left-[1003px] top-[103px] w-[95px] h-[15px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"نمایشگاه ها"}
      </div>
      <div className={"absolute left-[1284px] top-[93px] w-[54px] h-[36px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl] flex items-center"}>
        {"تکسچر"}
      </div>
      <div className={"absolute left-[1140px] top-[101px] w-[102px] h-[24px] box-border origin-top-left text-[#606060] text-[20px] font-[400] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"گالری تصاویر"}
      </div>
      <div className={"absolute left-[1502px] top-[740px] w-[141px] h-[31px] box-border origin-top-left text-[#232323] text-[26px] font-[600] text-justify [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"درباره فرامید"}
      </div>
      <div className={"absolute left-[-16px] top-[1313px] w-[1744px] h-[536px] box-border origin-top-left bg-[#1f1f1f]"} />
      <div className={"absolute left-[114px] top-[1640px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[13px] top-[8px] w-[11px] h-[20px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[11px] h-[20px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11 20" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 11 0 L 12.15 0 C 12.15 -0.635 11.635 -1.15 11 -1.15 L 11 0 Z M 4.465 1.464 L 5.278 2.278 L 5.278 2.278 L 4.465 1.464 Z M 3 8 L 3 9.15 C 3.635 9.15 4.15 8.635 4.15 8 L 3 8 Z M 0 8 L 0 6.85 C -0.635 6.85 -1.15 7.365 -1.15 8 L 0 8 Z M 0 12 L -1.15 12 C -1.15 12.635 -0.635 13.15 0 13.15 L 0 12 Z M 3 12 L 4.15 12 C 4.15 11.365 3.635 10.85 3 10.85 L 3 12 Z M 3 20 L 1.85 20 C 1.85 20.635 2.365 21.15 3 21.15 L 3 20 Z M 7 20 L 7 21.15 C 7.635 21.15 8.15 20.635 8.15 20 L 7 20 Z M 7 12 L 7 10.85 C 6.365 10.85 5.85 11.365 5.85 12 L 7 12 Z M 10 12 L 10 13.15 C 10.528 13.15 10.988 12.791 11.116 12.279 L 10 12 Z M 11 8 L 12.116 8.279 C 12.202 7.935 12.124 7.571 11.906 7.292 C 11.689 7.013 11.354 6.85 11 6.85 L 11 8 Z M 7 8 L 5.85 8 C 5.85 8.635 6.365 9.15 7 9.15 L 7 8 Z M 7.293 4.293 L 6.48 3.48 L 6.48 3.48 L 7.293 4.293 Z M 11 4 L 11 5.15 C 11.635 5.15 12.15 4.635 12.15 4 L 11 4 Z M 11 -1.15 L 8 -1.15 L 8 1.15 L 11 1.15 L 11 -1.15 Z M 8 -1.15 C 6.369 -1.15 4.805 -0.502 3.651 0.651 L 5.278 2.278 C 6 1.556 6.979 1.15 8 1.15 L 8 -1.15 Z M 3.651 0.651 C 2.498 1.805 1.85 3.369 1.85 5 L 4.15 5 C 4.15 3.979 4.556 3 5.278 2.278 L 3.651 0.651 Z M 1.85 5 L 1.85 8 L 4.15 8 L 4.15 5 L 1.85 5 Z M 3 6.85 L 0 6.85 L 0 9.15 L 3 9.15 L 3 6.85 Z M -1.15 8 L -1.15 12 L 1.15 12 L 1.15 8 L -1.15 8 Z M 0 13.15 L 3 13.15 L 3 10.85 L 0 10.85 L 0 13.15 Z M 1.85 12 L 1.85 20 L 4.15 20 L 4.15 12 L 1.85 12 Z M 3 21.15 L 7 21.15 L 7 18.85 L 3 18.85 L 3 21.15 Z M 8.15 20 L 8.15 12 L 5.85 12 L 5.85 20 L 8.15 20 Z M 7 13.15 L 10 13.15 L 10 10.85 L 7 10.85 L 7 13.15 Z M 11.116 12.279 L 12.116 8.279 L 9.884 7.721 L 8.884 11.721 L 11.116 12.279 Z M 11 6.85 L 7 6.85 L 7 9.15 L 11 9.15 L 11 6.85 Z M 8.15 8 L 8.15 5 L 5.85 5 L 5.85 8 L 8.15 8 Z M 8.15 5 C 8.15 5.04 8.134 5.078 8.106 5.106 L 6.48 3.48 C 6.077 3.883 5.85 4.43 5.85 5 L 8.15 5 Z M 8.106 5.106 C 8.078 5.134 8.04 5.15 8 5.15 L 8 2.85 C 7.43 2.85 6.883 3.076 6.48 3.48 L 8.106 5.106 Z M 8 5.15 L 11 5.15 L 11 2.85 L 8 2.85 L 8 5.15 Z M 12.15 4 L 12.15 0 L 9.85 0 L 9.85 4 L 12.15 4 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[176px] top-[1676px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[7px] top-[9px] w-[22.069px] h-[18px] box-border origin-top-left"}>
          <div className={"absolute left-[0px] top-[0px] w-[22.069px] h-[18px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 22.069 18" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 22.069 0.01 L 23.23 0.472 C 23.428 -0.025 23.288 -0.592 22.882 -0.94 C 22.476 -1.287 21.893 -1.338 21.433 -1.066 L 22.069 0.01 Z M 18.919 1.545 L 17.976 2.365 C 18.299 2.736 18.809 2.884 19.28 2.742 L 18.919 1.545 Z M 16.619 0.134 L 16.922 -1.078 L 16.922 -1.078 L 16.619 0.134 Z M 11.81 1.97 L 12.844 2.672 L 12.844 2.672 L 11.81 1.97 Z M 11.034 4.554 L 12.284 4.554 C 12.284 4.549 12.284 4.543 12.284 4.538 L 11.034 4.554 Z M 11.034 5.557 L 11.067 6.807 C 11.744 6.789 12.284 6.235 12.284 5.557 L 11.034 5.557 Z M 5.95 4.419 L 6.512 3.303 L 6.512 3.303 L 5.95 4.419 Z M 2.006 1.013 L 3.029 0.295 C 2.77 -0.074 2.333 -0.275 1.885 -0.231 C 1.437 -0.187 1.047 0.094 0.864 0.506 L 2.006 1.013 Z M 7.022 14.054 L 7.724 15.088 C 8.1 14.833 8.307 14.395 8.267 13.943 C 8.227 13.491 7.944 13.096 7.53 12.912 L 7.022 14.054 Z M 0 16.06 L 0.05 14.811 C -0.529 14.788 -1.047 15.165 -1.204 15.723 C -1.36 16.28 -1.113 16.872 -0.607 17.153 L 0 16.06 Z M 20.063 4.524 L 21.313 4.524 L 21.313 4.52 L 20.063 4.524 Z M 19.982 3.692 L 19.105 2.802 C 18.808 3.095 18.676 3.516 18.755 3.926 L 19.982 3.692 Z M 22.069 0.01 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.433 -1.066 21.433 -1.066 21.433 -1.066 C 21.432 -1.065 21.431 -1.065 21.429 -1.064 C 21.426 -1.062 21.421 -1.059 21.414 -1.055 C 21.401 -1.047 21.38 -1.035 21.353 -1.019 C 21.299 -0.988 21.219 -0.942 21.119 -0.886 C 20.92 -0.772 20.643 -0.619 20.333 -0.455 C 19.683 -0.112 18.992 0.217 18.559 0.348 L 19.28 2.742 C 19.972 2.533 20.856 2.096 21.5 1.756 C 21.837 1.578 22.136 1.412 22.351 1.29 C 22.459 1.229 22.546 1.179 22.607 1.144 C 22.637 1.126 22.661 1.112 22.678 1.102 C 22.686 1.097 22.692 1.094 22.697 1.091 C 22.699 1.09 22.701 1.089 22.702 1.088 C 22.703 1.087 22.704 1.087 22.704 1.087 C 22.704 1.087 22.704 1.087 22.704 1.087 C 22.705 1.086 22.705 1.086 22.705 1.086 C 22.705 1.086 22.705 1.086 22.069 0.01 Z M 19.862 0.725 C 19.09 -0.163 18.064 -0.793 16.922 -1.078 L 16.316 1.347 C 16.96 1.508 17.54 1.864 17.976 2.365 L 19.862 0.725 Z M 16.922 -1.078 C 15.781 -1.364 14.579 -1.292 13.48 -0.872 L 14.371 1.463 C 14.992 1.226 15.671 1.186 16.316 1.347 L 16.922 -1.078 Z M 13.48 -0.872 C 12.381 -0.453 11.437 0.294 10.776 1.268 L 12.844 2.672 C 13.217 2.122 13.75 1.7 14.371 1.463 L 13.48 -0.872 Z M 10.776 1.268 C 10.115 2.241 9.769 3.394 9.785 4.571 L 12.284 4.538 C 12.275 3.873 12.471 3.222 12.844 2.672 L 10.776 1.268 Z M 9.784 4.554 L 9.784 5.557 L 12.284 5.557 L 12.284 4.554 L 9.784 4.554 Z M 11.002 4.308 C 9.445 4.348 7.903 4.003 6.512 3.303 L 5.388 5.536 C 7.147 6.421 9.098 6.858 11.067 6.807 L 11.002 4.308 Z M 6.512 3.303 C 5.121 2.603 3.924 1.569 3.029 0.295 L 0.983 1.732 C 2.115 3.343 3.628 4.65 5.388 5.536 L 6.512 3.303 Z M 2.006 1.013 C 0.864 0.506 0.864 0.506 0.863 0.507 C 0.863 0.507 0.863 0.508 0.863 0.508 C 0.862 0.509 0.862 0.51 0.861 0.512 C 0.86 0.514 0.859 0.517 0.857 0.521 C 0.854 0.529 0.85 0.538 0.845 0.55 C 0.835 0.574 0.821 0.606 0.805 0.646 C 0.772 0.727 0.728 0.841 0.676 0.984 C 0.573 1.27 0.439 1.676 0.31 2.174 C 0.054 3.163 -0.19 4.546 -0.12 6.086 C -0.05 7.631 0.339 9.359 1.373 10.992 C 2.413 12.634 4.057 14.104 6.514 15.196 L 7.53 12.912 C 5.472 11.997 4.233 10.834 3.485 9.655 C 2.733 8.467 2.432 7.186 2.377 5.972 C 2.322 4.753 2.516 3.628 2.731 2.8 C 2.837 2.388 2.946 2.057 3.027 1.834 C 3.067 1.723 3.1 1.638 3.122 1.585 C 3.133 1.558 3.141 1.539 3.145 1.528 C 3.148 1.523 3.149 1.52 3.15 1.518 C 3.15 1.518 3.15 1.518 3.15 1.518 C 3.15 1.518 3.15 1.519 3.149 1.519 C 3.149 1.519 3.149 1.52 3.149 1.52 C 3.149 1.52 3.149 1.521 2.006 1.013 Z M 6.32 13.02 C 4.475 14.272 2.278 14.9 0.05 14.811 L -0.05 17.309 C 2.712 17.419 5.437 16.641 7.724 15.088 L 6.32 13.02 Z M -0.607 17.153 C 4.253 19.853 9.718 19.884 14.004 17.603 C 18.321 15.305 21.313 10.73 21.313 4.524 L 18.813 4.524 C 18.813 9.855 16.288 13.555 12.83 15.396 C 9.341 17.253 4.776 17.283 0.607 14.968 L -0.607 17.153 Z M 21.313 4.52 C 21.312 4.163 21.277 3.807 21.21 3.457 L 18.755 3.926 C 18.793 4.125 18.812 4.326 18.813 4.528 L 21.313 4.52 Z M 20.86 4.582 C 21.538 3.913 22.139 2.816 22.53 2.027 C 22.738 1.607 22.912 1.221 23.034 0.941 C 23.094 0.801 23.143 0.686 23.176 0.605 C 23.193 0.564 23.206 0.532 23.215 0.51 C 23.22 0.499 23.223 0.49 23.226 0.484 C 23.227 0.48 23.228 0.478 23.229 0.476 C 23.229 0.475 23.23 0.474 23.23 0.473 C 23.23 0.473 23.23 0.473 23.23 0.473 C 23.23 0.473 23.23 0.472 23.23 0.472 C 23.23 0.472 23.23 0.472 22.069 0.01 C 20.907 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.908 -0.452 C 20.908 -0.452 20.908 -0.452 20.907 -0.452 C 20.907 -0.451 20.907 -0.45 20.906 -0.448 C 20.904 -0.444 20.902 -0.438 20.898 -0.429 C 20.891 -0.412 20.881 -0.386 20.866 -0.351 C 20.838 -0.282 20.795 -0.18 20.74 -0.055 C 20.631 0.198 20.475 0.544 20.29 0.917 C 19.893 1.717 19.451 2.46 19.105 2.802 L 20.86 4.582 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div className={"absolute left-[238px] top-[1676px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[6px] top-[5px] w-[24px] h-[24px] box-border origin-top-left"}>
          <div className={"absolute left-[2px] top-[2px] w-[20px] h-[20px] box-border origin-top-left"}>
            <div className={"absolute left-[5.556px] top-[5.556px] w-[8.889px] h-[8.889px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 8.889 8.889" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 4.444 10.039 C 7.534 10.039 10.039 7.534 10.039 4.444 L 7.739 4.444 C 7.739 6.264 6.264 7.739 4.444 7.739 L 4.444 10.039 Z M 10.039 4.444 C 10.039 1.355 7.534 -1.15 4.444 -1.15 L 4.444 1.15 C 6.264 1.15 7.739 2.625 7.739 4.444 L 10.039 4.444 Z M 4.444 -1.15 C 1.355 -1.15 -1.15 1.355 -1.15 4.444 L 1.15 4.444 C 1.15 2.625 2.625 1.15 4.444 1.15 L 4.444 -1.15 Z M -1.15 4.444 C -1.15 7.534 1.355 10.039 4.444 10.039 L 4.444 7.739 C 2.625 7.739 1.15 6.264 1.15 4.444 L -1.15 4.444 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[20px] h-[20px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 20 20" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 1.25 14.444 L 1.25 5.556 L -1.25 5.556 L -1.25 14.444 L 1.25 14.444 Z M 1.25 5.556 C 1.25 3.178 3.178 1.25 5.556 1.25 L 5.556 -1.25 C 1.797 -1.25 -1.25 1.797 -1.25 5.556 L 1.25 5.556 Z M 5.556 1.25 L 14.444 1.25 L 14.444 -1.25 L 5.556 -1.25 L 5.556 1.25 Z M 14.444 1.25 C 16.822 1.25 18.75 3.178 18.75 5.556 L 21.25 5.556 C 21.25 1.797 18.203 -1.25 14.444 -1.25 L 14.444 1.25 Z M 18.75 5.556 L 18.75 14.444 L 21.25 14.444 L 21.25 5.556 L 18.75 5.556 Z M 18.75 14.444 C 18.75 16.822 16.822 18.75 14.444 18.75 L 14.444 21.25 C 18.203 21.25 21.25 18.203 21.25 14.444 L 18.75 14.444 Z M 14.444 18.75 L 5.556 18.75 L 5.556 21.25 L 14.444 21.25 L 14.444 18.75 Z M 5.556 18.75 C 3.178 18.75 1.25 16.822 1.25 14.444 L -1.25 14.444 C -1.25 18.203 1.797 21.25 5.556 21.25 L 5.556 18.75 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[16.111px] top-[3.888px] w-[0.012px] h-[0.013px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 1 1" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M -0.929 -0.823 C -1.391 -0.31 -1.349 0.48 -0.836 0.942 C -0.323 1.404 0.467 1.362 0.929 0.849 L -0.929 -0.823 Z M 0.941 0.836 C 1.403 0.323 1.361 -0.467 0.848 -0.929 C 0.335 -1.391 -0.456 -1.349 -0.917 -0.836 L 0.941 0.836 Z M 0.929 0.849 L 0.941 0.836 L -0.917 -0.836 L -0.929 -0.823 L 0.929 0.849 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[300px] top-[1676px] w-[36px] h-[36px] box-border origin-top-left"}>
        <div className={"absolute left-[0px] top-[0px] w-[36px] h-[36px] box-border origin-top-left rounded-[4px] bg-[#313131]"} />
        <div className={"absolute left-[7px] top-[7px] w-[22px] h-[22px] box-border origin-top-left overflow-hidden"}>
          <div className={"absolute left-[0px] top-[0px] w-[22px] h-[22px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/home/d3113ae5d38f42325172d25ee512520ef84dd396.webp')"}} />
          <div className={"absolute left-[-3px] top-[-3px] w-[28px] h-[28px] box-border origin-top-left bg-[#ffffff]"} />
        </div>
      </div>
      <div className={"absolute left-[104px] top-[1412.952px] w-[284.172px] h-[78.989px] box-border origin-top-left"}>
        <div className={"absolute left-[239.458px] top-[17.788px] w-[5.898px] h-[35.575px] box-border origin-top-left"}>
          <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 5.898 35.575" preserveAspectRatio="none" className="block overflow-visible">
            <path d={"M 5.898 0 L 0 0 L 0 35.575 L 5.898 35.575 L 5.898 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
          </svg>
        </div>
        <div className={"absolute left-[0px] top-[0px] w-[284.172px] h-[78.989px] box-border origin-top-left"}>
          <div className={"absolute left-[198.264px] top-[17.788px] w-[33.869px] h-[35.676px] box-border origin-top-left"}>
            <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 33.869 35.676" preserveAspectRatio="none" className="block overflow-visible">
              <path d={"M 16.934 26.43 L 27.97 14.672 L 27.97 35.676 L 33.869 35.676 L 33.869 0 L 16.934 18.19 L 0 0 L 0 35.676 L 5.803 35.676 L 5.803 14.672 L 16.934 26.43 Z"} fill={"#ffffff"} fillRule="nonzero" />
            </svg>
          </div>
          <div className={"absolute left-[0px] top-[0px] w-[284.172px] h-[78.989px] box-border origin-top-left"}>
            <div className={"absolute left-[251.731px] top-[17.788px] w-[32.441px] h-[35.575px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 32.441 35.575" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 26.543 16.381 C 26.543 10.753 22.167 6.231 16.934 6.231 L 5.898 6.231 L 5.898 29.445 L 16.934 29.445 C 22.262 29.445 26.543 24.822 26.543 19.295 L 26.543 16.481 L 26.543 16.381 Z M 0 6.231 L 0 0 L 16.934 0 C 25.497 0 32.441 7.336 32.441 16.381 L 32.441 19.195 C 32.441 28.239 25.497 35.575 16.934 35.575 L 0 35.575 L 0 6.13 L 0 6.231 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[157.451px] top-[17.888px] w-[35.486px] h-[35.575px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 35.486 35.575" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 35.486 17.788 C 35.486 7.939 27.875 0 18.647 0 L 16.839 0 C 7.611 0 0 8.04 0 17.788 C 0 27.536 7.611 35.575 16.839 35.575 L 18.647 35.575 C 27.97 35.575 35.486 27.536 35.486 17.788 Z M 17.79 5.427 C 24.165 5.427 29.397 10.954 29.397 17.687 C 29.397 24.42 24.165 29.948 17.79 29.948 C 11.416 29.948 6.184 24.42 6.184 17.687 C 6.184 10.954 11.416 5.427 17.79 5.427 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[122.155px] top-[17.888px] w-[31.014px] h-[35.575px] box-border origin-top-left"}>
              <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 31.014 35.575" preserveAspectRatio="none" className="block overflow-visible">
                <path d={"M 23.404 35.575 L 31.014 35.575 L 21.596 23.817 C 22.833 23.516 24.069 23.114 25.116 22.511 C 28.636 20.501 31.014 16.481 31.014 12.059 C 31.014 5.427 25.877 0 19.598 0 L 0 0 L 0 35.575 L 5.803 35.575 L 5.803 6.13 L 19.598 6.13 C 22.642 6.13 25.116 8.743 25.116 11.959 C 25.116 15.175 22.642 17.788 19.598 17.788 L 9.133 17.788 L 14.08 23.918 L 23.404 35.475 L 23.404 35.575 Z"} fill={"#ffffff"} fillRule="nonzero" />
              </svg>
            </div>
            <div className={"absolute left-[0px] top-[0px] w-[284.077px] h-[78.989px] box-border origin-top-left"}>
              <div className={"absolute left-[65.168px] top-[17.788px] w-[26.924px] h-[35.676px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 26.924 35.676" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 0 0 L 26.924 0 L 23.499 6.231 L 5.803 6.231 L 5.803 14.773 L 21.12 14.773 L 18.361 20.903 L 5.803 20.903 L 5.803 25.023 L 5.803 29.445 L 5.803 35.676 L 0 35.676 L 0 20.903 L 0 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[0px] top-[0px] w-[56.606px] h-[69.141px] box-border origin-top-left"}>
                <div className={"absolute left-[0px] top-[0px] w-[39.006px] h-[57.986px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 39.006 57.986" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 10.75 57.986 L 0 51.654 L 0 17.084 L 28.731 0 L 39.006 6.331 L 10.75 24.119 L 10.75 57.986 Z"} fill={"#ffffff"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[23.499px] top-[13.768px] w-[33.107px] h-[55.373px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 33.107 55.373" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 29.445 L 0 16.883 L 27.59 0 L 33.107 3.316 L 33.107 38.188 L 4.757 55.373 L 0 52.257 L 0 45.122 L 22.642 31.254 L 22.452 15.878 L 0 29.445 Z"} fill={"#ec1c24"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
              <div className={"absolute left-[84.862px] top-[17.788px] w-[34.439px] h-[35.676px] box-border origin-top-left"}>
                <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 34.439 35.676" preserveAspectRatio="none" className="block overflow-visible">
                  <path d={"M 17.22 0 L 0 35.676 L 6.279 35.676 L 17.22 12.964 L 28.16 35.676 L 34.439 35.676 L 17.22 0 Z"} fill={"#ffffff"} fillRule="nonzero" />
                </svg>
              </div>
              <div className={"absolute left-[162.588px] top-[62.005px] w-[121.489px] h-[16.984px] box-border origin-top-left"}>
                <div className={"absolute left-[-0px] top-[0.101px] w-[14.366px] h-[16.883px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 14.366 16.883" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 14.366 16.582 L 11.892 16.582 C 11.797 16.079 11.702 15.476 11.607 14.974 C 10.75 16.18 9.228 16.883 7.04 16.883 C 2.569 16.883 0 13.265 0 8.643 C 0 4.02 2.664 0 7.611 0 C 12.558 0 13.985 2.412 14.27 5.125 L 10.941 5.125 C 10.655 4.02 9.799 2.713 7.516 2.713 C 5.232 2.713 3.425 5.527 3.425 8.442 C 3.425 11.356 4.471 14.069 7.516 14.069 C 10.56 14.069 10.941 11.959 10.941 10.552 C 10.941 10.451 7.516 10.451 7.516 10.451 L 7.516 7.537 L 14.175 7.537 L 14.175 16.682 L 14.366 16.582 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[28.731px] top-[0.301px] w-[11.987px] h-[16.381px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.987 16.381" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 3.235 9.849 L 3.235 16.381 L 0 16.381 L 0 0 L 6.755 0 C 10.084 0 11.987 2.01 11.987 4.522 C 11.987 7.035 10.846 7.939 9.704 8.341 C 10.465 8.643 11.607 9.447 11.607 12.361 L 11.607 13.165 C 11.607 14.27 11.607 15.476 11.797 16.28 L 8.657 16.28 C 8.372 15.577 8.372 14.371 8.372 12.562 L 8.372 12.361 C 8.372 10.552 7.991 9.748 5.423 9.748 L 3.235 9.748 L 3.235 9.849 Z M 3.235 7.035 L 5.994 7.035 C 7.801 7.035 8.562 6.331 8.562 4.924 C 8.562 3.517 7.706 2.814 6.089 2.814 L 3.235 2.814 L 3.235 7.035 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[53.562px] top-[0px] w-[15.032px] h-[16.883px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 15.032 16.883" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 15.032 8.442 C 15.032 12.964 12.463 16.883 7.421 16.883 C 2.378 16.883 0 13.165 0 8.442 C 0 3.718 2.854 0 7.611 0 C 12.368 0 15.032 3.316 15.032 8.341 L 15.032 8.442 Z M 3.52 8.442 C 3.52 11.657 4.852 14.069 7.611 14.069 C 10.37 14.069 11.607 11.456 11.607 8.542 C 11.607 5.628 10.37 3.015 7.516 3.015 C 4.662 3.015 3.52 5.326 3.52 8.442 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[82.388px] top-[0.301px] w-[12.939px] h-[16.582px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 12.939 16.582" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 3.235 0 L 3.235 9.748 C 3.235 12.863 4.757 13.768 6.469 13.768 C 8.182 13.768 9.609 12.662 9.609 9.748 L 9.609 0 L 12.939 0 L 12.939 9.547 C 12.939 15.175 9.799 16.582 6.469 16.582 C 3.139 16.582 0 15.074 0 9.648 L 0 0 L 3.33 0 L 3.235 0 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
                <div className={"absolute left-[109.597px] top-[0.301px] w-[11.892px] h-[16.381px] box-border origin-top-left"}>
                  <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 11.892 16.381" preserveAspectRatio="none" className="block overflow-visible">
                    <path d={"M 0 0 L 6.374 0 C 9.704 0 11.892 1.909 11.892 5.025 C 11.892 8.14 9.323 10.25 6.279 10.25 L 3.33 10.25 L 3.33 16.381 L 0 16.381 L 0 0 Z M 3.33 7.437 L 5.898 7.437 C 7.421 7.437 8.562 6.834 8.562 5.125 C 8.562 3.417 7.421 2.814 5.994 2.814 L 3.33 2.814 L 3.33 7.437 Z"} fill={"#808184"} fillRule="nonzero" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={"absolute left-[1525px] top-[1446px] w-[90px] h-[25px] box-border origin-top-left text-[#ffffff] text-[20px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"تماس با ما"}
      </div>
      <div className={"absolute left-[984px] top-[1445px] w-[63px] h-[25px] box-border origin-top-left text-[#ffffff] text-[20px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"پیوندها"}
      </div>
      <div className={"absolute left-[1170px] top-[1493px] w-[452px] h-[18px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"آدرس کارخانه: کیلومتر 20 جاده خاوران، روبروی فرون آباد اول، کوچه صاحب الزمان"}
      </div>
      <div className={"absolute left-[1124px] top-[1524px] w-[491px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"آدرس دفترمرکزی و شوروم :  اتوبان ارتش. اقدسیه. اراج. نبش اراج. ساختمان نگین پلاک 156"}
      </div>
      <div className={"absolute left-[1359px] top-[1562px] w-[256px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"شماره تماس دفترمرکزی و شورم :  02178328000"}
      </div>
      <div className={"absolute left-[1439px] top-[1600px] w-[176px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"فکس دفتر مرکزی :  02122823107"}
      </div>
      <div className={"absolute left-[1392px] top-[1638px] w-[223px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"شماره تماس : 02136849085 - 02136849086"}
      </div>
      <div className={"absolute left-[1509px] top-[1676px] w-[106px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"فکس : 02136849474"}
      </div>
      <div className={"absolute left-[1463px] top-[1714px] w-[152px] h-[25px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-left [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:rtl]"}>
        {"ایمیل :     info@faromid.com"}
      </div>
      <div className={"absolute left-[784px] top-[1493px] w-[276px] h-[170px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"صنایع چوب ایران\nاتحادیه تولید کنندگان و صادر کنندگان مبل ایران\nتعاونی فرآورده های چوبی\n انجمن روکش های مصنوعی\nشورای ملی مبلمان\nگمرک جمهوری اسلامی ایران\nوزارت صنعت ، معدن و تجارت\nاستاندارد ایران\nسامانه جامع تجارت\nبانک مرکزی      "}
      </div>
      <div className={"absolute left-[611px] top-[1495px] w-[132px] h-[153px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-right [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"اتاق بازرگانی\nاتاق بازرگانی ایران\nاتاق بازرگانی آلمان\nاتاق بازرگانی ایتالیا\n اتاق بازرگانی اتریش\nاتاق بازرگانی چین\nبهین یاب\nمیانگین موزون سنا\nبازار طلا و ارز"}
      </div>
      <div className={"absolute left-[1174px] top-[1462.5px] w-[348px] h-[0px] box-border origin-top-left"}>
        <svg aria-hidden="true" width="100%" height="100%" viewBox="0 0 348 1" preserveAspectRatio="none" className="block overflow-visible">
          <path d={"M 348 -1 L 0 -1 L 0 1 L 348 1 L 348 -1 Z"} fill={"#ff0000"} fillRule="nonzero" />
        </svg>
      </div>
      <div className={"absolute left-[127px] top-[1542px] w-[250px] h-[40px] box-border origin-top-left text-[#ffffff] text-[13px] font-[700] text-center [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"فرامید تولید کننده ام دی اف دورو سینکرونایز، \nفوق برجسته و سوپر مات-آنتی فینگر"}
      </div>
      <div className={"absolute left-[512px] top-[791px] w-[1129px] h-[450px] box-border origin-top-left text-[#323030] text-[22px] font-[400] text-justify [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-pre-wrap [direction:rtl]"}>
        {"گروه تولیدی فرامید فعالیت خود را در زمینه صنعت چوب و مبلمان از سال ۱۳۳۲ توسط آقای محمد فروز فقید آغاز نمود و از سال ۱۳۸۴ دو فرزند ایشان آقایان امید و فرید فروز شرکت فرامید تجارت را تاسیس نمودند.\nمحور اصلی فعالیت این شرکت همیشه بر \"احترام به مشتریان و رضایت مندی ایشان\" از طریق\" ارائه محصول با کیفیت\" همراه با \" زمان تحویل مناسب\" استوار بوده است. داشتن کارنامه ای روشن طی این سالها که نشان از حسن نظر مشتریان گرامی بوده، خود گواه این مطلب است.\nدر سال ۱۳۹۲ برادران فروز تصمیم به راه اندازی خط تولید اوراق روکش شده ملامینه با ماشین آلات مدرن و به روز در کارخانه متعلق به این شرکت در حومه تهران گرفتند. لازم به ذکر است که مقدمات این کار در سال ۱۳۹۱ با تحقیق در بازار های جهانی و سفرهای متعدد به اروپا و آسیا پایه گذاری گردید.\nعلاوه بر نوآوری در طرح و رنگ محصولات، تمرکز اصلی فرامید بر استفاده از بافت های جدید بوده است که از طریق ایجاد ارتباطات سازنده با برخی از شرکت های تولیدی مطرح دنیا در زمینه تولید صفحات پرس موجبات تحقق این امر حاصل گردد.\nگروه تولیدی فرامید با حدود 150 نفر پرسنل مستقیم و حدود 600 نفر پرسنل غیر مستقیم و با ظرفیت تولید بیش از 50000 ورق در ماه، اولین تولید کننده ورق های ام دی اف دوروسینکرونایز، فوق برجسته و سوپرمات در بازار صنایع مربوطه خود می باشد.\nمحصول جدید فرامید برای اولین بار در خاورمیانه تولید شده و به طور قطع می تواند در بر گیرنده بازار آسیا و سپس بازار اروپا بوده و گامی موثر در معرفی محصول ساخت ایران به دنیا باشد. از اینرو یکی از اهداف مهم مجموعه فرامید صادرات و گسترش بازار فروش و نمایندگان در خارج از مرزهای ایران است. در این راستا فرامید قطعاً نیازمند پشتیبانی و همراهی مصرف کنندگان و دولت می باشد.\nشرکت فرامید امیدوار است با حمایت هرچه بیشتر تولید داخل و حقوق مصرف کنندگان گامی موثر در اشتغال زایی جوانان کشور عزیزمان و همچنین افزایش توان تولید داخلی، سهم قابل توجهی از بازار نمونه های وارداتی مشابه را به خود اختصاص دهد."}
      </div>
      <div className={"absolute left-[79px] top-[791px] w-[361.794px] h-[450px] box-border origin-top-left overflow-hidden"}>
        <div className={"absolute left-[0px] top-[0px] w-[361.794px] h-[450px] box-border origin-top-left bg-[#d9d9d9]"} />
        <div className={"absolute left-[-74.751px] top-[-23.92px] w-[541.513px] h-[497.961px] box-border origin-top-left overflow-hidden"}>
          <div className={"absolute left-[0px] top-[0px] w-[541.513px] h-[497.961px] box-border origin-top-left bg-[#d9d9d9]"} />
          <div className={"absolute left-[-102.249px] top-[5.92px] w-[615.385px] h-[494px] box-border origin-top-left bg-cover bg-no-repeat bg-center"} style={{backgroundImage: "url('/assets/about/be7057755c3f1501497e513959a2c4301d4e9755.webp')"}} />
        </div>
      </div>
      <div className={"absolute left-[1388px] top-[598px] w-[254px] h-[67px] box-border origin-top-left text-[#afacac] text-[58px] font-[700] text-justify [font-family:var(--font-vazirmatn),var(--font-inter),Tahoma,Arial,sans-serif] break-normal leading-[1.35] whitespace-nowrap [direction:ltr]"}>
        {"Since 1995"}
      </div>
      {/* Native accessible navigation and interactive regions */}
      <Link href="/" className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[90px] top-[60px] w-[300px] h-[100px]" aria-label="صفحه اصلی فرامید" />
      <Link href={"/"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1501px] top-[89px] w-[118px] h-[40px]" aria-label={"صفحه اصلی"} />
      <Link href={"/products"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1372px] top-[91px] w-[105px] h-[40px]" aria-label={"محصولات"} />
      <Link href={"/about"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[887px] top-[90px] w-[84px] h-[40px]" aria-label={"درباره ما"} />
      <Link href={"/contact"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[606px] top-[94px] w-[107px] h-[40px]" aria-label={"تماس با ما"} />
      <Link href={"/careers"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[743px] top-[91px] w-[120px] h-[40px]" aria-label={"همکاری با ما"} />
      <Link href={"/exhibitions"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[995px] top-[93px] w-[113px] h-[40px]" aria-label={"نمایشگاه ها"} />
      <Link href={"/textures"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1276px] top-[83px] w-[72px] h-[52px]" aria-label={"تکسچر"} />
      <Link href={"/gallery"} className="absolute z-[200] block cursor-pointer border-0 bg-transparent hover:shadow-[inset_0_-2px_0_rgba(237,28,36,0.5)] left-[1132px] top-[91px] w-[120px] h-[40px]" aria-label={"گالری تصاویر"} />
    </>
  );
}
