"use client";

import {SiteLayout} from '@/components/site-layout';
import {GalleryDesktop} from '@/components/desktop/gallery-desktop';

export function GalleryView() {
  return (
    <SiteLayout
      slug="gallery"
      width={1728}
      height={3641}
      background="#000000"
      renderDesktop={openImage => <GalleryDesktop onOpenImage={openImage}/>}
    />
  );
}
