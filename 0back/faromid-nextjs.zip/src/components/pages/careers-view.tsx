"use client";

import {SiteLayout} from '@/components/site-layout';
import {CareersDesktop} from '@/components/desktop/careers-desktop';

export function CareersView() {
  return (
    <SiteLayout
      slug="careers"
      width={1729}
      height={1465}
      background="#ffffff"
      renderDesktop={openImage => <CareersDesktop onOpenImage={openImage}/>}
    />
  );
}
