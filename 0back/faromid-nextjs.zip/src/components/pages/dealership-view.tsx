"use client";

import {SiteLayout} from '@/components/site-layout';
import {DealershipDesktop} from '@/components/desktop/dealership-desktop';

export function DealershipView() {
  return (
    <SiteLayout
      slug="dealership"
      width={1729}
      height={1465}
      background="#ffffff"
      renderDesktop={openImage => <DealershipDesktop onOpenImage={openImage}/>}
    />
  );
}
