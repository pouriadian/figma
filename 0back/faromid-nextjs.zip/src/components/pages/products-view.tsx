"use client";

import {SiteLayout} from '@/components/site-layout';
import {ProductsDesktop} from '@/components/desktop/products-desktop';

export function ProductsView() {
  return (
    <SiteLayout
      slug="products"
      width={1727}
      height={4168}
      background="#ffffff"
      renderDesktop={openImage => <ProductsDesktop onOpenImage={openImage}/>}
    />
  );
}
