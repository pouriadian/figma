"use client";

import {SiteLayout} from '@/components/site-layout';
import {ExhibitionsDesktop} from '@/components/desktop/exhibitions-desktop';

export function ExhibitionsView() {
  return (
    <SiteLayout
      slug="exhibitions"
      width={1728}
      height={3233}
      background="#000000"
      renderDesktop={openImage => <ExhibitionsDesktop onOpenImage={openImage}/>}
    />
  );
}
