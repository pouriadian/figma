"use client";

import {SiteLayout} from '@/components/site-layout';
import {AboutDesktop} from '@/components/desktop/about-desktop';

export function AboutView() {
  return (
    <SiteLayout
      slug="about"
      width={1728}
      height={1849}
      background="#e8ecef"
      renderDesktop={openImage => <AboutDesktop onOpenImage={openImage}/>}
    />
  );
}
