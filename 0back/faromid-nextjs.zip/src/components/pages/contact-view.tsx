"use client";

import {SiteLayout} from '@/components/site-layout';
import {ContactDesktop} from '@/components/desktop/contact-desktop';

export function ContactView() {
  return (
    <SiteLayout
      slug="contact"
      width={1729}
      height={1465}
      background="#ffffff"
      renderDesktop={openImage => <ContactDesktop onOpenImage={openImage}/>}
    />
  );
}
