"use client";

import {SiteLayout} from '@/components/site-layout';
import {HomeDesktop} from '@/components/desktop/home-desktop';

export function HomeView() {
  return (
    <SiteLayout
      slug="home"
      width={1728}
      height={5536}
      background="#ffffff"
      renderDesktop={openImage => <HomeDesktop onOpenImage={openImage}/>}
    />
  );
}
