"use client";

import {useEffect, useState, type CSSProperties, type ReactNode} from 'react';
import Image from 'next/image';
import {X} from 'lucide-react';
import {MobilePage} from '@/components/mobile-page';

export type PageSlug = 'home' | 'products' | 'about' | 'careers' | 'gallery' | 'dealership' | 'contact' | 'exhibitions';

export type OpenImage = (src: string) => void;

/** Shared responsive shell; artwork itself is a conventional page-specific JSX component. */
export function SiteLayout({slug,width,height,background,renderDesktop}:{
  slug:PageSlug;
  width:number;
  height:number;
  background:string;
  renderDesktop:(onOpenImage:OpenImage)=>ReactNode;
}) {
  const [lightbox,setLightbox]=useState<string|null>(null);
  const canvasVars = {
    '--canvas-w': `${width}px`,
    '--canvas-h': `${height}px`,
  } as CSSProperties;
  useEffect(()=>{
    if(!lightbox) return;
    const handleKey=(ev:KeyboardEvent)=>{if(ev.key==='Escape')setLightbox(null);};
    window.addEventListener('keydown',handleKey);
    return ()=>window.removeEventListener('keydown',handleKey);
  },[lightbox]);
  return <>
    <div className="block w-full max-[900px]:hidden">
      <div
        className="relative mx-auto h-[calc(var(--canvas-h)*min(1,100cqw/var(--canvas-w)))] w-full max-w-[1729px] overflow-hidden bg-white [container-type:inline-size]"
        style={canvasVars}
      >
        <div
          className="absolute top-0 left-0 origin-top-left overflow-hidden [transform:scale(min(1,100cqw/var(--canvas-w)))]"
          style={{width,height,backgroundColor:background}}
        >
          {renderDesktop(setLightbox)}
        </div>
      </div>
    </div>
    <div className="hidden max-[900px]:block">
      <MobilePage slug={slug} onOpenImage={setLightbox}/>
    </div>
    {lightbox && <div className="fixed inset-0 z-[2000] flex items-center justify-center bg-[rgba(0,0,0,0.93)] p-[20px]" role="dialog" aria-modal="true" aria-label="نمایش تصویر" onClick={()=>setLightbox(null)}>
      <button type="button" className="absolute top-[24px] right-[28px] grid h-[46px] w-[46px] place-items-center rounded-full border border-solid border-[#666] bg-[#181818] text-white" aria-label="بستن" onClick={()=>setLightbox(null)}><X size={24}/></button>
      <Image src={lightbox} alt="تصویر گالری فرامید" width={1400} height={1100} className="h-auto max-h-[85vh] w-auto max-w-[92vw] object-contain" unoptimized />
    </div>}
  </>;
}
