import Image from 'next/image';
import Link from 'next/link';
import {links} from '@/lib/constants';
import {brand} from '@/lib/media';
import {footerHeadingStyles} from '@/lib/tailwind-styles';

export function MobileFooter() {
  return (
    <footer className="grid gap-[30px] bg-[#201f1f] p-[46px_25px_20px] text-[#f8f8f8] min-[560px]:max-[900px]:grid-cols-2 min-[560px]:max-[900px]:gap-[35px]" dir="rtl">
      <div>
        <Image src={brand.logo} width={200} height={60} alt="Faromid Group" className="h-auto max-w-[200px]" />
        <p className="max-w-[340px] text-[12px] leading-[1.85] text-[#ddd]">
          تولیدکننده MDF ملامینه، سینکرونایز، فوق برجسته و سوپرمات آنتی فینگر
        </p>
      </div>
      <div className="grid grid-cols-2 gap-x-[8px] gap-y-[12px]">
        <h3 className={`${footerHeadingStyles} col-span-full mb-[4px]`}>پیوندها</h3>
        {links.map(link => (
          <Link key={link.href} href={link.href} className="text-[12px] text-[#ddd] hover:text-[#ff4045]">
            {link.label}
          </Link>
        ))}
      </div>
      <div className="text-[12px] leading-[2] text-[#ddd] min-[560px]:max-[900px]:col-span-full">
        <h3 className={`${footerHeadingStyles} mb-[18px]`}>تماس با ما</h3>
        <p className="my-[10px] max-w-[600px]">آدرس کارخانه: کیلومتر ۲۰ جاده خاوران، روبروی فرون‌آباد اول، کوچه صاحب‌الزمان</p>
        <p className="my-[10px] max-w-[600px]">دفتر مرکزی و شوروم: تهران، اقدسیه، ساختمان نگین</p>
        <a className="block text-right [direction:ltr] hover:text-[#ff4045]" href="tel:+982178328000" dir="ltr">021 7832 8000</a>
        <a className="block text-right [direction:ltr] hover:text-[#ff4045]" href="mailto:info@faromid.com">info@faromid.com</a>
      </div>
      <div className="border-t border-[#454343] pt-[20px] text-center text-[11px] text-[#aaa] [direction:ltr] min-[560px]:max-[900px]:col-span-full">
        © {new Date().getFullYear()} Faromid Group
      </div>
    </footer>
  );
}
