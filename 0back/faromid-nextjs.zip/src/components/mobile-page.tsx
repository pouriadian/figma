'use client';

import type {ReactNode} from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {ArrowUpLeft, Mail, MapPin, Phone} from 'lucide-react';
import {asset} from '@/lib/assets';
import {ProductCarousel} from '@/components/product-carousel';
import {CATALOG_PRODUCTS} from '@/lib/products-catalog';
import {brand} from '@/lib/media';
import {buttonStyles, pageTitleStyles, sectionHeadingStyles, sectionStyles} from '@/lib/tailwind-styles';
import {MobileHeader} from './mobile-header';
import {MobileFooter} from './mobile-footer';
import {ContactForm} from './contact-form';
import {ContactMapEmbed} from './contact-map';
import type {PageSlug} from './site-layout';

type PhotoAspect = 'square' | 'wide' | 'editorial' | 'about' | 'banner';
const photoAspectClasses: Record<PhotoAspect, string> = {
  square: 'aspect-square',
  wide: 'h-full aspect-auto',
  editorial: 'aspect-[1.38]',
  about: 'aspect-[1.5]',
  banner: 'h-full aspect-auto',
};

function Photo({
  src,
  alt,
  priority = false,
  aspect = 'square',
  className = '',
}: {
  src: string;
  alt: string;
  priority?: boolean;
  aspect?: PhotoAspect;
  className?: string;
}) {
  return (
    <div className={`relative w-full overflow-hidden bg-[#ccc] ${photoAspectClasses[aspect]} ${className}`}>
      <Image
        src={src}
        alt={alt}
        fill
        sizes="(max-width: 600px) 100vw, 700px"
        priority={priority}
        className="object-cover transition-transform duration-[350ms] ease-in-out group-hover:scale-[1.035]"
      />
    </div>
  );
}

function SectionHeading({children}: {children: ReactNode}) {
  return <h2 className={sectionHeadingStyles}>{children}</h2>;
}

const samples = ['سمپل آنتی فینگر', 'سمپل کیفی', 'سمپل هایگلاس', 'سمپل اولترا'];
const valueItems = [
  ['✧', 'نوآوری', 'Innovation'],
  ['◎', 'مسئولیت اجتماعی', 'Social Responsibility'],
  ['⌁', 'اعتماد', 'Trust'],
  ['♙', 'مشتری‌مداری', 'Customer Centricity'],
  ['♧', 'خلاقیت', 'Creativity'],
  ['✧', 'کیفیت', 'Quality'],
  ['✎', 'برنامه‌ریزی استراتژیک', 'Strategic Planning'],
];
const galleryTitles = [
  'G2LAB | Monalia Hotel',
  'Studio Arketo | Ristorante ExMahalo',
  'دکوراسیون داخلی مدرن',
  'پروژه‌های معماری فرامید',
  'اجرای دکوراسیون',
  'طراحی فضای زندگی',
];
const eventTitles = ['تصاویر نمایشگاه اول', 'تصاویر نمایشگاه دوم', 'تصاویر نمایشگاه سوم', 'تصاویر نمایشگاه چهارم'];

const aboutSectionStyles =
  'bg-white px-[25px] py-[45px] text-[15px] leading-[2.25] [&>p]:mt-0 [&>p]:mb-[26px] [&>p]:text-justify [&>p]:leading-[2.25] [&>p]:text-[#343434]';

function ProductGrid({limit = 12, textures = false}: {limit?: number; textures?: boolean}) {
  const products = CATALOG_PRODUCTS.slice(0, limit);
  return (
    <div className={`grid grid-cols-2 gap-x-[12px] gap-y-[19px] min-[560px]:max-[900px]:grid-cols-3 min-[560px]:max-[900px]:gap-[22px] ${textures ? 'mx-auto max-w-[1400px] min-[901px]:grid-cols-4 min-[901px]:gap-[26px]' : ''}`}>
      {products.map((product) => (
        <Link
          href={product.href}
          className="bg-white p-[10px] shadow-[0_2px_0_#bcbaba] transition-[transform,box-shadow] duration-200 hover:-translate-y-[3px] hover:shadow-[0_8px_15px_#00000016]"
          key={product.id}
        >
          <div className={`relative w-full overflow-hidden bg-[#f6f5f4] ${textures ? 'aspect-[0.83] min-[901px]:aspect-square' : 'aspect-[0.83]'}`}>
            <Image src={product.image} alt={`طرح بافت MDF مدل ${product.model} - ${product.code}`} fill sizes="(max-width:500px) 45vw, 30vw" className="object-cover" />
          </div>
          <div className="flex flex-col items-start gap-[5px] p-[10px_0_1px] text-[11px] leading-[1.6] font-semibold [&>span]:before:ml-[4px] [&>span]:before:text-[17px] [&>span]:before:leading-[8px] [&>span]:before:text-[#ec1f27] [&>span]:before:content-['•']">
            <span>مدل: {product.model}</span>
            <span>کد: {product.code}</span>
            <span>ابعاد: {product.dimensions}</span>
          </div>
        </Link>
      ))}
    </div>
  );
}

type BannerKind = 'products' | 'about' | 'careers' | 'dealership';
function PageBanner({kind}: {kind: BannerKind}) {
  const isShort = kind === 'careers' || kind === 'dealership';
  const data = {
    products: {image: asset.intro, alt: 'فضای داخلی آشپزخانه با متریال آنتی فینگر', overline: 'Faromid Collection', title: 'ANTI FINGER'},
    about: {image: asset.aboutHero, alt: 'متریال و محصولات گروه فرامید', overline: 'FAROMID GROUP', title: 'Since 1995'},
    careers: {image: asset.careers, alt: 'همکاری و ارتباط با گروه فرامید', overline: '', title: 'همکاری با ما'},
    dealership: {image: asset.dealership, alt: 'فرصت نمایندگی فرامید', overline: '', title: 'اخذ نمایندگی'},
  }[kind];
  const titleStyles = isShort
    ? 'text-[40px] leading-[1.5] font-extrabold [direction:rtl] [font-family:var(--font-vazirmatn),Tahoma,sans-serif]'
    : kind === 'about'
      ? 'text-[55px] leading-[1.2] font-extrabold [direction:ltr] [font-family:Arial,sans-serif]'
      : 'text-[clamp(35px,10vw,85px)] leading-[1.2] font-extrabold [direction:ltr] [font-family:Arial,sans-serif]';

  return (
    <div className={`relative flex items-center justify-center overflow-hidden bg-[#191919] text-center text-white after:absolute after:inset-0 after:bg-[linear-gradient(0deg,#10101044,#10101030)] after:content-[''] ${isShort ? 'h-[300px]' : 'h-[370px]'}`}>
      <Photo src={data.image} alt={data.alt} priority aspect="banner" className="absolute inset-0" />
      <div className="relative z-[2]">
        {data.overline && <p className="mt-0 mb-[7px] text-[14px] tracking-[3px] text-[#eee] [direction:ltr] [font-family:Arial,sans-serif]">{data.overline}</p>}
        <h1 className={`m-0 tracking-[1px] ${titleStyles}`}>{data.title}</h1>
      </div>
    </div>
  );
}

function Home() {
  return (
    <>
      <section className="relative flex min-h-[510px] items-end overflow-hidden bg-[#070707] min-[560px]:max-[900px]:min-h-[600px]">
        <div className="absolute top-0 right-0 bottom-0 left-[18%] opacity-90 after:absolute after:inset-0 after:bg-[linear-gradient(90deg,#050505_0%,transparent_86%),linear-gradient(0deg,#0d0d0d_0%,transparent_70%)] after:content-['']">
          <Image src={asset.hero} alt="محصولات Faromid و سمپل متریال" fill sizes="100vw" priority className="object-cover" />
        </div>
        <div className="relative z-[2] flex w-full flex-col items-start gap-[28px] p-[35px_26px_53px] text-white min-[560px]:max-[900px]:p-[55px]">
          <Image src={brand.heroStripes} width={236} height={180} alt="" aria-hidden priority className="h-[170px] w-auto max-w-[70%] object-contain opacity-90 brightness-[.85]" />
          <p className="relative m-0 max-w-[330px] border-r-[3px] border-[#ee252c] pr-[13px] text-[17px] leading-[2] font-semibold">
            فرامید تولیدکننده ام‌دی‌اف ملامینه، سینکرونایز، فوق‌برجسته و سوپرمات
          </p>
          <Link href="/products" className="flex items-center gap-[10px] border-b border-[#ee252c] pb-[6px] font-bold">
            مشاهده محصولات <ArrowUpLeft size={18} />
          </Link>
        </div>
      </section>

      <section className={`${sectionStyles} bg-[#dfdddd]`}>
        <SectionHeading>محصولات</SectionHeading>
        <ProductCarousel perSlide={4} showMoreLink />
      </section>

      <section
        className="relative min-h-[410px] bg-cover bg-center p-[55px_20px] text-white"
        style={{backgroundImage: `linear-gradient(120deg,rgba(10,15,23,.87),rgba(17,20,25,.85)), url('${asset.interiors[1]}')`}}
      >
        <SectionHeading>ارزش‌های سازمانی</SectionHeading>
        <div className="grid grid-cols-2 gap-x-[10px] gap-y-[25px] min-[560px]:max-[900px]:grid-cols-3">
          {valueItems.map(([symbol, title, en]) => (
            <div className="flex flex-col items-center gap-[5px] text-center" key={en}>
              <span className="grid h-[65px] w-[65px] place-items-center rounded-full border border-solid border-[#ddd] bg-[#ffffff0b] text-[27px] leading-none">{symbol}</span>
              <strong className="text-[13px] font-bold">{title}</strong>
              <small className="text-[10px] tracking-[.1px] opacity-80 [font-family:Arial,sans-serif]">{en}</small>
            </div>
          ))}
        </div>
      </section>

      <section className={`${sectionStyles} bg-[#dfdddd]`}>
        <SectionHeading>گالری تصاویر</SectionHeading>
        <div className="grid grid-cols-2 gap-[8px]">
          {asset.interiors.slice(0, 5).map((url, i) => (
            <Link href="/gallery" className={i === 0 ? 'group row-span-2' : 'group'} key={url}>
              <Photo src={url} alt={galleryTitles[i]} aspect={i === 0 ? 'wide' : 'square'} />
            </Link>
          ))}
        </div>
        <Link href="/gallery" className={`${buttonStyles} mx-auto mt-[28px] flex max-w-max`}>بیشتر <ArrowUpLeft size={16} /></Link>
      </section>

      <section className="flex flex-col items-center gap-[12px] bg-white p-[40px_26px_46px] text-center">
        <Image src={brand.homeHistoryPanels} alt="" aria-hidden width={520} height={220} className="h-auto w-[min(92%,520px)] object-contain" />
        <p className="m-0 max-w-[520px] text-[12px] leading-[1.65] font-bold [font-family:Arial,sans-serif]">
          Since 1975 the Caspany family has pursued its entrepreneurial path of tradition and innovation with passion and enthusiasm.
        </p>
      </section>

      <section className={`${sectionStyles} bg-[#dfdddd]`}>
        <SectionHeading>سمپل‌ها</SectionHeading>
        <div className="grid grid-cols-2 gap-x-[13px] gap-y-[24px] min-[560px]:max-[900px]:grid-cols-4">
          {asset.samples.map((url, i) => (
            <Link href="/products" className="group" key={url}>
              <Photo src={url} alt={samples[i]} />
              <h3 className="mt-[11px] mb-0 text-center text-[12px] font-medium">{samples[i]}</h3>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}

function Products() {
  return (
    <>
      <PageBanner kind="products" />
      <section className={`${sectionStyles} bg-[#dfdddd]`}>
        <SectionHeading>محصولات آنتی فینگر</SectionHeading>
        <ProductCarousel perSlide={4} />
      </section>
    </>
  );
}

function About() {
  return (
    <>
      <PageBanner kind="about" />
      <section className={aboutSectionStyles} dir="rtl">
        <SectionHeading>درباره فرامید</SectionHeading>
        <p>گروه تولیدی فرامید فعالیت خود را در زمینه صنعت چوب و مبلمان از سال ۱۳۳۲ توسط آقای محمد فروز آغاز نمود. این مجموعه با تکیه بر تجربه، نوآوری و کیفیت، توسعه محصولات و ارائه متریال متنوع برای معماری و طراحی داخلی را دنبال می‌کند.</p>
        <Photo src={asset.about} alt="شوروم و نمونه محصولات فرامید" aspect="about" />
      </section>
    </>
  );
}

function Gallery({onOpen}: {onOpen: (src: string) => void}) {
  return <EditorialPage title="پروژه‌ها" images={asset.interiors} titles={galleryTitles} onOpen={onOpen} />;
}

function Exhibitions({onOpen}: {onOpen: (src: string) => void}) {
  return <EditorialPage title="نمایشگاه‌ها" images={asset.exhibitions} titles={eventTitles} onOpen={onOpen} />;
}

function EditorialPage({title, images, titles, onOpen}: {
  title: string;
  images: string[];
  titles: string[];
  onOpen: (src: string) => void;
}) {
  return (
    <section className={`${sectionStyles} bg-[#dfdddd]`}>
      <h1 className={pageTitleStyles}>{title}</h1>
      <div className="mb-[55px] grid grid-cols-1 gap-[22px] min-[560px]:max-[900px]:grid-cols-2">
        {images.map((src, i) => (
          <button
            className="group overflow-hidden border-0 bg-white p-0 text-right text-[#202020] shadow-[0_1px_4px_#0002]"
            key={src}
            type="button"
            onClick={() => onOpen(src)}
          >
            <Photo src={src} alt={titles[i]} aspect="editorial" />
            <h3 className="m-0 p-[10px_16px_3px] text-right text-[15px] leading-[1.7] [direction:ltr] [font-family:var(--font-vazirmatn),Tahoma,Arial,sans-serif]">{titles[i]}</h3>
            <span className="flex items-center gap-[4px] p-[0_16px_14px] text-[12px] text-[#757575]">
              {title === 'پروژه‌ها' ? 'مشاهده تصویر' : 'نمایش عکس'} <ArrowUpLeft size={14} />
            </span>
          </button>
        ))}
      </div>
      <SectionHeading>محصولات جدید</SectionHeading>
      <ProductCarousel perSlide={4} />
    </section>
  );
}

function Careers() {
  return (
    <>
      <PageBanner kind="careers" />
      <section className={aboutSectionStyles}>
        <p>فلسفه کاری در فرامید مبتنی بر احترام و اخلاق حرفه‌ای می‌باشد که منجر به ایجاد محیط کاری دوستانه بر اساس معیارهای بین‌المللی و توأم با پیشرفت و یادگیری مستمر است.</p>
        <SectionHeading>ارسال رزومه</SectionHeading>
        <p>برای ارسال رزومه، زمینه تخصصی و راه ارتباطی خود را بنویسید و در برنامه ایمیل فایل رزومه را ضمیمه کنید.</p>
        <ContactForm type="careers" />
      </section>
    </>
  );
}

function Dealership() {
  return (
    <>
      <PageBanner kind="dealership" />
      <section className={aboutSectionStyles}>
        <p>برای همکاری تجاری و اطلاع از شرایط اخذ نمایندگی محصولات فرامید، درخواست خود را به همراه نام شهر و اطلاعات تماس ارسال کنید.</p>
        <SectionHeading>فرم اخذ نمایندگی</SectionHeading>
        <ContactForm type="dealership" />
      </section>
    </>
  );
}

function Contact() {
  const contactLinkStyles = 'flex items-center gap-[11px] leading-[1.9] [&>svg]:shrink-0 [&>svg]:text-[#ed1c24]';
  return (
    <>
      <section className="bg-white p-[45px_22px_32px] leading-[2.1]">
        <h1 className={pageTitleStyles}>تماس با ما</h1>
        <p className="max-w-[500px]">برای دریافت اطلاعات محصولات، شرایط همکاری و مشاوره با ما در تماس باشید.</p>
        <div className="grid gap-[13px]">
          <a className={contactLinkStyles} href="tel:+982178328000"><Phone size={18} /> 02178328000</a>
          <a className={contactLinkStyles} href="mailto:info@faromid.com"><Mail size={18} /> info@faromid.com</a>
          <p className={contactLinkStyles}><MapPin size={18} /> آدرس کارخانه: کیلومتر ۲۰ جاده خاوران، روبروی فرون‌آباد اول، کوچه صاحب‌الزمان</p>
        </div>
      </section>
      <div className="min-h-[280px] bg-[#e8e8e8]">
        <ContactMapEmbed className="block h-full min-h-[min(56vw,420px)] w-full aspect-[4/3] border-0" />
      </div>
      <section className={aboutSectionStyles}>
        <SectionHeading>ارسال پیام</SectionHeading>
        <ContactForm />
      </section>
    </>
  );
}

function Textures() {
  return (
    <section className={`${sectionStyles} bg-[#dfdddd]`}>
      <h1 className={pageTitleStyles}>بافت و تکسچر محصولات</h1>
      <p className="mt-[-20px] mb-[29px] text-center leading-[1.8] text-[#555]">مجموعه‌ای از بافت‌های طبیعی، مدرن و مینیمال محصولات فرامید</p>
      <ProductGrid textures />
    </section>
  );
}

const siteStyles = 'min-h-screen bg-[#e2e1e1] text-[14px] text-[#171717]';

export function MobilePage({slug, onOpenImage}: {slug: PageSlug; onOpenImage: (src: string) => void}) {
  return (
    <div className={siteStyles} dir="rtl">
      <MobileHeader />
      <main>
        {slug === 'home' ? <Home />
          : slug === 'products' ? <Products />
          : slug === 'about' ? <About />
          : slug === 'careers' ? <Careers />
          : slug === 'gallery' ? <Gallery onOpen={onOpenImage} />
          : slug === 'exhibitions' ? <Exhibitions onOpen={onOpenImage} />
          : slug === 'dealership' ? <Dealership />
          : <Contact />}
      </main>
      <MobileFooter />
    </div>
  );
}

export function MobileTextures() {
  return (
    <div className={`${siteStyles} mx-auto max-w-[1728px]`} dir="rtl">
      <MobileHeader wide />
      <main><Textures /></main>
      <MobileFooter />
    </div>
  );
}
