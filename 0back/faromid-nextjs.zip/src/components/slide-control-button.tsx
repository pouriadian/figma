'use client';

import type { ButtonHTMLAttributes } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

type Direction = 'prev' | 'next';

const sizeClasses = {
  md: 'h-[73px] w-[73px]',
  sm: 'h-[46px] w-[46px]',
} as const;

/** RTL carousel control: prev = toward end, next = toward start. */
export function SlideControlButton({
  direction,
  size = 'md',
  className = '',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { direction: Direction; size?: keyof typeof sizeClasses }) {
  const Icon = direction === 'prev' ? ChevronRight : ChevronLeft;
  return (
    <button
      type="button"
      className={`inline-flex shrink-0 items-center justify-center rounded-[4px] border border-solid border-[#e0e0e0] bg-[#f1f1f1] text-[#464646] shadow-[0_1px_2px_#00000014] transition-[background-color,transform,box-shadow] duration-200 hover:bg-white hover:shadow-[0_4px_12px_#0000001a] active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-[#f1f1f1] disabled:hover:shadow-none ${sizeClasses[size]} ${className}`}
      {...props}
    >
      <Icon size={size === 'md' ? 28 : 22} strokeWidth={2.25} aria-hidden />
    </button>
  );
}
