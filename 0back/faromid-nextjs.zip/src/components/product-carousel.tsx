'use client';

import { useCallback, useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowUpLeft } from 'lucide-react';
import { CATALOG_PRODUCTS, catalogPageCount, type CatalogProduct } from '@/lib/products-catalog';
import { SlideControlButton } from '@/components/slide-control-button';
import { buttonStyles } from '@/lib/tailwind-styles';

function ProductMeta({ product, compact }: { product: CatalogProduct; compact?: boolean }) {
  return (
    <div
      className={`flex flex-col items-start gap-[4px] font-semibold text-[#1a1a1a] ${compact ? 'p-[10px_12px_12px] text-[11px] leading-[1.55]' : 'p-[12px_14px_14px] text-[12px] leading-[1.6]'}`}
    >
      <span className="flex items-center gap-[6px] before:text-[#ec1f27] before:content-['•']">
        مدل: {product.model}
      </span>
      <span className="flex items-center gap-[6px] before:text-[#ec1f27] before:content-['•']">
        کد: {product.code}
      </span>
      <span className="flex items-center gap-[6px] before:text-[#ec1f27] before:content-['•']">
        ابعاد: {product.dimensions}
      </span>
    </div>
  );
}

function ProductSlideCard({ product, compact }: { product: CatalogProduct; compact?: boolean }) {
  return (
    <Link
      href={product.href}
      className={`group block overflow-hidden bg-white shadow-[0_4px_4px_#00000028] transition-[transform,box-shadow] duration-200 hover:-translate-y-[2px] hover:shadow-[0_10px_22px_#00000022] ${compact ? 'rounded-[2px]' : 'rounded-[3px]'}`}
    >
      <div className={`relative w-full overflow-hidden bg-[#f3f2f1] ${compact ? 'aspect-[0.72]' : 'aspect-[0.68] min-h-[420px]'}`}>
        <Image
          src={product.image}
          alt={`طرح بافت MDF مدل ${product.model} - ${product.code}`}
          fill
          sizes="(max-width: 900px) 45vw, 320px"
          className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
      </div>
      <ProductMeta product={product} compact={compact} />
    </Link>
  );
}

type ProductCarouselProps = {
  perSlide?: number;
  variant?: 'mobile' | 'desktop' | 'desktopCompact';
  className?: string;
  showMoreLink?: boolean;
};

export function ProductCarousel({
  perSlide = 4,
  variant = 'mobile',
  className = '',
  showMoreLink = false,
}: ProductCarouselProps) {
  const pageCount = catalogPageCount(perSlide);
  const [page, setPage] = useState(0);

  const goPrev = useCallback(() => setPage((p) => Math.max(0, p - 1)), []);
  const goNext = useCallback(() => setPage((p) => Math.min(pageCount - 1, p + 1)), [pageCount]);

  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === 'ArrowRight') goPrev();
      if (ev.key === 'ArrowLeft') goNext();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [goNext, goPrev]);

  const slice = CATALOG_PRODUCTS.slice(page * perSlide, page * perSlide + perSlide);
  const isDesktop = variant.startsWith('desktop');
  const compact = variant === 'desktopCompact';

  const gridClass = isDesktop
    ? 'grid grid-cols-4 gap-x-[22px] gap-y-[18px]'
    : 'grid grid-cols-2 gap-x-[12px] gap-y-[19px] min-[560px]:max-[900px]:grid-cols-4 min-[560px]:max-[900px]:gap-[22px]';

  return (
    <div className={className} dir="rtl">
      <div className="relative">
        <div className={gridClass} aria-live="polite" aria-label={`محصولات، صفحه ${page + 1} از ${pageCount}`}>
          {slice.map((product) => (
            <ProductSlideCard key={product.id} product={product} compact={compact || !isDesktop} />
          ))}
        </div>
      </div>

      <div
        className={`mt-[22px] flex flex-wrap items-center justify-center gap-[14px] ${isDesktop ? 'mt-[28px]' : ''}`}
        role="group"
        aria-label="کنترل اسلاید محصولات"
      >
        <SlideControlButton direction="prev" onClick={goPrev} disabled={page === 0} aria-label="صفحه قبل" />
        <div className="flex min-w-[120px] flex-col items-center gap-[10px]">
          <span className="text-[15px] font-bold text-[#2a2a2a]">
            <span className="text-[#ed1c24]">{page + 1}</span>
            <span className="mx-[6px] text-[#888]">/</span>
            {pageCount}
          </span>
          <div className="flex items-center gap-[8px]">
            {Array.from({ length: pageCount }, (_, i) => (
              <button
                key={i}
                type="button"
                aria-label={`رفتن به صفحه ${i + 1}`}
                aria-current={i === page ? 'true' : undefined}
                onClick={() => setPage(i)}
                className={`h-[9px] rounded-full transition-all duration-200 ${
                  i === page ? 'w-[26px] bg-[#ed1c24]' : 'w-[9px] bg-[#c8c8c8] hover:bg-[#a8a8a8]'
                }`}
              />
            ))}
          </div>
        </div>
        <SlideControlButton direction="next" onClick={goNext} disabled={page === pageCount - 1} aria-label="صفحه بعد" />
      </div>

      {showMoreLink && (
        <Link href="/products" className={`${buttonStyles} mx-auto mt-[28px] flex max-w-max items-center gap-[8px]`}>
          بیشتر
          <ArrowUpLeft size={17} aria-hidden />
        </Link>
      )}
    </div>
  );
}

/** Fixed-position carousel for desktop artboards (covers static product grid). */
export function DesktopArtboardProductCarousel({
  className,
  perSlide = 4,
}: {
  className?: string;
  perSlide?: number;
}) {
  return (
    <div className={`pointer-events-auto ${className ?? ''}`}>
      <ProductCarousel perSlide={perSlide} variant="desktop" />
    </div>
  );
}

export function DesktopMoreLink({
  href,
  className,
  label = 'بیشتر',
}: {
  href: string;
  className?: string;
  label?: string;
}) {
  return (
    <Link
      href={href}
      className={`pointer-events-auto absolute z-[260] inline-flex items-center justify-center gap-[10px] rounded-[16px] bg-[#211c1c] px-[28px] py-[14px] text-[22px] font-bold text-white shadow-[0_6px_18px_#00000033] transition-[transform,background-color] duration-200 hover:-translate-y-px hover:bg-[#2d2727] ${className ?? ''}`}
    >
      {label}
      <ArrowUpLeft size={22} strokeWidth={2.25} aria-hidden />
    </Link>
  );
}
