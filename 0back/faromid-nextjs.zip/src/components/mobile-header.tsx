'use client';

import {useState} from 'react';
import Image from 'next/image';
import Link from 'next/link';
import {usePathname} from 'next/navigation';
import {Menu, X} from 'lucide-react';
import {links} from '@/lib/constants';
import {brand} from '@/lib/media';

export function MobileHeader({wide = false}: {wide?: boolean}) {
  const [open, setOpen] = useState(false);
  const current = usePathname();

  return (
    <header className={`relative z-[400] flex h-[80px] items-center justify-between bg-[#191919] p-[12px_clamp(18px,5vw,32px)] text-white ${wide ? "min-[901px]:h-[100px]" : ""}`}>
      <Link href="/" aria-label="صفحه اصلی فرامید" onClick={() => setOpen(false)}>
        <Image
          src={brand.logo}
          width={166}
          height={48}
          alt="Faromid Group"
          priority
          className={`h-auto w-[158px] object-contain ${wide ? "min-[901px]:w-[230px]" : ""}`}
        />
      </Link>
      <button
        className={`grid h-[44px] w-[44px] place-items-center rounded-[2px] border border-solid border-[#555] bg-transparent text-white ${wide ? "min-[901px]:block" : ""}`}
        type="button"
        aria-label={open ? 'بستن منو' : 'باز کردن منو'}
        aria-expanded={open}
        onClick={() => setOpen(value => !value)}
      >
        {open ? <X /> : <Menu />}
      </button>
      {open && (
        <nav
          className={`absolute inset-x-0 top-[80px] grid bg-[#1d1d1d] p-[15px_23px_22px] shadow-[0_12px_24px_rgba(0,0,0,0.26)] ${wide ? "min-[901px]:top-[100px] min-[901px]:grid-cols-5" : ""}`}
          aria-label="منوی اصلی"
        >
          {links.map(item => (
            <Link
              className={`block border-b border-[#363636] p-[13px_5px] font-medium transition-colors duration-200 hover:text-[#ff4248] ${current === item.href ? 'text-[#ff4248]' : 'text-[#f5f5f5]'}`}
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
