import {buttonStyles} from '@/lib/tailwind-styles';
import type {Metadata} from 'next';
import Image from 'next/image';
import Link from 'next/link';
import {notFound} from 'next/navigation';
import {MobileHeader} from '@/components/mobile-header';
import {MobileFooter} from '@/components/mobile-footer';
import {ArrowRight, Mail} from 'lucide-react';
import {productTexture} from '@/lib/media';

export function generateStaticParams(){return Array.from({length:12},(_,i)=>({slug:`product-${i+1}`}));}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{
  const {slug}=await params;
  const n=Number(slug.replace('product-',''));
  return {title:`CLEAN TOUCH – ${7184+n}`,description:`اطلاعات و مشخصات MDF کلین تاچ فرامید با کد ${7184+n}`};
}
export default async function ProductDetail({params}:{params:Promise<{slug:string}>}){
  const {slug}=await params;
  const num=Number(slug.replace('product-',''));
  if(!/^product-([1-9]|1[0-2])$/.test(slug)||!Number.isInteger(num))notFound();
  const number=7184+num;
  return <div className="min-h-screen bg-[#e2e1e1] text-[14px] text-[#171717]" dir="rtl"><MobileHeader/>
    <main className="mx-auto max-w-[1400px] bg-[#f5f4f4] px-[clamp(18px,5vw,60px)] pt-[45px] pb-[90px]"><Link href="/products" className="mb-[32px] inline-flex items-center gap-[9px] text-[13px] text-[#555]"><ArrowRight size={17}/> بازگشت به محصولات</Link>
      <div className="grid grid-cols-2 items-start gap-[70px] [direction:ltr] max-[800px]:grid-cols-1 max-[800px]:gap-[28px]"><div className="relative min-h-[530px] bg-white max-[800px]:min-h-[430px]"><Image alt={`طرح MDF فرامید CLEAN TOUCH با کد ${number}`} src={productTexture(((num-1)%8)+1)} fill sizes="(max-width:900px) 100vw, 45vw" className="object-contain" priority/></div>
      <div className="text-right leading-[2] [direction:rtl]"><span className="text-[11px] font-bold tracking-[3px] text-[#bb2228]">FAROMID GROUP / MDF</span><h1 className="mt-[8px] mb-[17px] text-[35px] leading-[1.6] max-[800px]:text-[27px]">کلین تاچ | CLEAN TOUCH</h1><p>کد محصول: <b>{number}</b></p><div className="my-[26px] grid gap-[10px] border-y border-[#ddd] py-[17px] [&>div]:flex [&>div]:justify-between [&>div]:gap-[30px] [&_span]:text-[#666]"><div><span>مدل</span><strong>CLEAN TOUCH</strong></div><div><span>کد</span><strong>{number}</strong></div><div><span>ابعاد</span><strong>۱۲۱ × ۲۲۸</strong></div><div><span>نوع</span><strong>MDF دکوراتیو</strong></div></div>
       <p className="mb-[26px] text-[13px] leading-[2.2] text-[#555]">تصاویر نمونه ممکن است از نظر نور و رنگ در نمایشگرهای مختلف متفاوت باشند. برای اطلاعات فنی یا ثبت درخواست، با دفتر فروش تماس بگیرید.</p>
       <a className={buttonStyles} href={`mailto:info@faromid.com?subject=${encodeURIComponent('استعلام محصول '+number)}`}><Mail size={17}/> استعلام محصول</a>
      </div></div>
    </main><MobileFooter/>
  </div>;
}
