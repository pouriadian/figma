/** Shared Tailwind utility compositions; deliberately no bespoke component CSS. */
export const buttonStyles =
  'inline-flex min-h-[44px] items-center justify-center gap-[10px] rounded-[6px] border border-solid border-[#242122] bg-[#242122] px-[24px] py-[9px] text-[14px] font-bold text-white transition-[transform,background-color,border-color] duration-200 hover:-translate-y-px hover:border-[#dd1b22] hover:bg-[#dd1b22] [&_svg]:shrink-0';

export const sectionStyles = 'px-[clamp(19px,4vw,38px)] pt-[50px] pb-[57px]';
export const sectionHeadingStyles = 'mb-[28px] mt-0 text-center text-[24px] leading-[1.5] font-extrabold';
export const pageTitleStyles = 'mt-[4px] mb-[40px] text-center text-[35px] font-black';

export const footerHeadingStyles =
  "relative mt-0 pt-[10px] text-[18px] font-extrabold before:absolute before:top-0 before:right-0 before:h-[2px] before:w-[72px] before:bg-[#e6232a] before:content-['']";

export const formFieldStyles =
  'mb-[9px] w-full rounded-[3px] border border-solid border-[#c7c7c7] bg-[#f8f8f8] px-[12px] py-[13px] outline-none focus:border-[#e11d24] focus:shadow-[0_0_0_2px_#e11d241c]';
