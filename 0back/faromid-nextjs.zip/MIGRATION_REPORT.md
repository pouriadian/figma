# Faromid native React migration report

## Completed

- Converted the 8 original desktop page compositions into native JSX/TSX and Tailwind CSS utilities.
- Created dedicated client views under `src/components/pages/` so each route imports only its own desktop artwork.
- Kept all mobile/tablet layouts, navigation, lightbox actions, images, and SEO metadata.
- Eliminated the JSON-based design renderer and all 8 `src/design/*.json` files.
- Replaced the old JSON-based image category lookup with static TypeScript.
- Original 83 public asset files retained.

## Fidelity validation

Compared the old renderer reference and the new JSX/Tailwind output using offline browser rendering and local assets.
For each of 8 pages, inspected two scroll positions at 1200px and 1728px desktop widths (32 image comparisons in total). Results: **0.0 mean absolute RGB difference** in all 32 samples.

This validates the sampled layouts and their static appearance, **not** the entire interactive site or a production Next.js build. The contact iframe was rendered with matching local placeholders, since live external maps are not accessible in the comparison environment. Mobile/tablet layouts are unchanged from the previous Tailwind version.

## Build verification limitation

`npm install` and `next build` could not run in this container because `registry.npmjs.org` failed DNS resolution (`EAI_AGAIN`). All 41 TS/TSX source files passed the TypeScript parser syntax diagnostic check; generated Tailwind CSS utilities compiled successfully using an already installed Tailwind compiler. A full dependency-backed typecheck and Next.js production build still need to be run on your machine or CI.

## Recheck after extraction

```bash
npm install
npm run verify:design-free
npm run lint
npm run build
npm run dev
```

The desktop artwork intentionally retains a fixed-coordinate responsive artboard (scaled with CSS) to guarantee parity with the existing visual design. It is native static JSX with Tailwind utility classes, **not** a design JSON interpreter; converting its layout to a completely fluid grid would be a separate redesign and could change the appearance.
