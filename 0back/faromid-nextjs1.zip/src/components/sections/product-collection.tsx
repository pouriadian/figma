'use client';
import {useMemo,useState} from 'react';
import {Search,ArrowDownUp,X} from 'lucide-react';
import {CATALOG_PRODUCTS} from '@/lib/products-catalog';
import {ProductCard} from '@/components/ui/product-card';

export function ProductCollection({limit}:{limit?:number}) {
  const [query,setQuery]=useState('');
  const [descending,setDescending]=useState(false);
  const products=useMemo(()=>{
    const q=query.trim().toLowerCase();
    return [...(limit?CATALOG_PRODUCTS.slice(0,limit):CATALOG_PRODUCTS)]
      .sort((a,b)=>descending?b.code-a.code:a.code-b.code)
      .filter(p=>!q||[p.code.toString(),p.model,p.dimensions].some(v=>v.toLowerCase().includes(q)));
  },[query,descending,limit]);

  return <div>
    <div className="mb-7 flex flex-wrap items-center justify-between gap-3">
      <label className="relative block w-full sm:w-[300px]"><span className="sr-only">جستجوی محصول</span><Search size={18} className="pointer-events-none absolute top-1/2 right-4 -translate-y-1/2 text-[#8c948c]"/><input type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="جستجوی کد یا مدل..." className="h-12 w-full rounded-2xl border border-[#dfe3dc] bg-white py-3 pr-11 pl-4 text-sm text-[#303832] outline-none transition-colors focus:border-[#818d81]"/></label>
      <button type="button" onClick={()=>setDescending(!descending)} className="inline-flex h-12 items-center gap-2 rounded-2xl border border-[#dfe3dc] bg-white px-4 text-[13px] text-[#586259] transition-colors hover:border-[#9ba49a]"><ArrowDownUp size={16}/>{descending?'کد: نزولی':'کد: صعودی'}</button>
    </div>
    {products.length>0?<div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">{products.map(p=><ProductCard key={p.id} product={p}/>)}</div>:
      <div className="grid min-h-52 place-items-center rounded-3xl border border-[#dce1da] bg-white p-8 text-center text-sm text-[#697369]"><div><p>محصولی یافت نشد.</p><button type="button" className="mt-2 inline-flex items-center gap-2 underline underline-offset-4" onClick={()=>setQuery('')}>پاک کردن جستجو <X size={14}/></button></div></div>}
  </div>;
}
