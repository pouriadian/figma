import Image from 'next/image';
import Link from 'next/link';
import {ArrowUpLeft} from 'lucide-react';
import {asset} from '@/lib/assets';
import {brand} from '@/lib/media';
import {ModernProductCarousel} from '@/components/ui/product-carousel';
import {Container,SectionTitle} from '@/components/ui/brand-ui';

const values=[
  ['✧','نوآوری','Innovation'],
  ['◎','مسئولیت اجتماعی','Social Responsibility'],
  ['⌁','اعتماد','Trust'],
  ['♙','مشتری‌مداری','Customer Centricity'],
  ['♧','خلاقیت','Creativity'],
  ['✧','کیفیت','Quality'],
  ['✎','برنامه‌ریزی استراتژیک','Strategic Planning'],
];
const samples=['سمپل آنتی فینگر','سمپل کیفی','سمپل هایگلاس','سمپل اولترا'];
const galleryNames=[
  'G2LAB | Monalia Hotel','Studio Arketo | Ristorante ExMahalo',
  'دکوراسیون داخلی مدرن','پروژه‌های معماری فرامید','اجرای دکوراسیون','طراحی فضای زندگی',
];

export function HomeCollections(){
 return <section className="bg-[#f5f5f1] py-16 sm:py-20 lg:py-24"><Container>
   <SectionTitle title="محصولات" action={{href:'/products',label:'بیشتر'}} />
   <ModernProductCarousel />
 </Container></section>;
}

export function HomeValues(){
 return <section className="relative isolate overflow-hidden bg-[#16191a] py-16 text-white sm:py-20">
   <Image src={asset.interiors[1]} fill alt="" aria-hidden sizes="100vw" className="-z-10 object-cover opacity-25" />
   <div className="absolute inset-0 -z-10 bg-[#151a1c]/70" />
   <Container><h2 className="mb-10 mt-0 text-center text-[clamp(1.6rem,2.7vw,2.5rem)] font-semibold">ارزش‌های سازمانی</h2>
   <div className="grid grid-cols-2 gap-x-3 gap-y-9 sm:grid-cols-3 lg:grid-cols-4">
     {values.map(([symbol,fa,en])=><div key={en} className="flex flex-col items-center gap-2 px-2 text-center"><span aria-hidden className="grid h-14 w-14 place-items-center rounded-2xl border border-white/25 bg-white/5 text-[25px] text-white/85">{symbol}</span><h3 className="mb-0 mt-2 text-[13px] font-semibold sm:text-[15px]">{fa}</h3><small className="text-[10px] tracking-wider text-white/55" dir="ltr">{en}</small></div>)}
   </div></Container>
 </section>;
}

export function HomeGallery(){
 return <section className="bg-[#f5f5f1] py-16 sm:py-20"><Container>
  <SectionTitle title="گالری تصاویر" action={{href:'/gallery',label:'بیشتر'}} />
  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 lg:gap-5">
    {asset.interiors.map((src,index)=><Link href="/gallery" key={src} className={`group relative block min-h-[245px] overflow-hidden rounded-[20px] bg-[#c8cbc6] sm:min-h-[290px] ${index===0?'lg:row-span-2 lg:min-h-[600px]':''}`} aria-label={galleryNames[index]}>
      <Image src={src} alt={galleryNames[index]} fill sizes="(max-width:650px) 100vw, (max-width:1024px) 50vw, 33vw" className="object-cover transition-transform duration-700 group-hover:scale-[1.035]" />
      <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 bg-gradient-to-t from-black/65 to-transparent px-5 pt-16 pb-5 text-white"><span className="text-[12px] font-medium sm:text-sm">{galleryNames[index]}</span><ArrowUpLeft size={17} className="shrink-0 transition-transform group-hover:-translate-x-1 group-hover:-translate-y-1" /></div>
    </Link>)}
  </div>
 </Container></section>;
}

export function HomeHistory(){
  return <section className="bg-white py-14 sm:py-20"><Container><div className="grid items-center gap-6 md:grid-cols-[.85fr_1.15fr] md:gap-12">
    <Image src={brand.homeHistoryPanels} width={600} height={270} alt="سمپل‌ها و پنل‌های فرامید" className="h-auto w-full max-w-[520px] object-contain" />
    <p dir="ltr" className="m-0 max-w-[580px] text-[14px] leading-[2.1] font-medium text-[#4f554e] sm:text-[16px]">Since 1975 the Caspany family has pursued its entrepreneurial path of tradition and innovation with passion and enthusiasm.</p>
  </div></Container></section>;
}

export function HomeSamples(){
 return <section className="bg-[#f5f5f1] py-16 sm:py-20"><Container>
  <SectionTitle title="سمپل‌ها" action={{href:'/products',label:'بیشتر'}} />
  <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-5">
    {asset.samples.map((src,i)=><Link href="/products" key={`${src}-${i}`} className="group block overflow-hidden rounded-[18px] border border-[#e5e7e1] bg-white transition-[box-shadow,transform] duration-300 hover:-translate-y-1 hover:shadow-[0_16px_34px_rgba(0,0,0,.09)]"><div className="relative aspect-[4/4.4] overflow-hidden bg-[#e6e7e3]"><Image src={src} alt={samples[i]} fill sizes="(max-width:650px) 50vw, 25vw" className="object-cover transition-transform duration-500 group-hover:scale-[1.035]" /></div><h3 className="m-0 p-4 text-center text-sm font-medium">{samples[i]}</h3></Link>)}
  </div>
 </Container></section>;
}
