import Image from 'next/image';
import {SiteShell} from '@/components/layout/site-shell';
import {PageIntro} from '@/components/sections/page-intro';
import {Container,SectionTitle} from '@/components/ui/brand-ui';
import {asset} from '@/lib/assets';

export function AboutView(){return <SiteShell>
  <PageIntro title="Since 1995" subtitle="FAROMID GROUP" image={asset.aboutHero}/>
  <section className="bg-[#f5f5f1] py-16 sm:py-24"><Container>
    <div className="grid items-center gap-9 lg:grid-cols-2 lg:gap-16">
      <div className="relative min-h-[320px] overflow-hidden rounded-[24px] bg-[#ddd] sm:min-h-[460px]"><Image src={asset.about} alt="شوروم و نمونه محصولات فرامید" fill sizes="(max-width:1024px) 100vw, 50vw" className="object-cover"/></div>
      <div><SectionTitle title="درباره فرامید"/><p className="m-0 max-w-xl text-[15px] leading-[2.85] text-[#596058]">گروه تولیدی فرامید فعالیت خود را در زمینه صنعت چوب و مبلمان از سال ۱۳۳۲ توسط آقای محمد فروز آغاز نمود. این مجموعه با تکیه بر تجربه، نوآوری و کیفیت، توسعه محصولات و ارائه متریال متنوع برای معماری و طراحی داخلی را دنبال می‌کند.</p></div>
    </div>
  </Container></section>
</SiteShell>}
