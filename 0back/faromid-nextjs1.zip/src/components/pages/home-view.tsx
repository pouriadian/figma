import {SiteShell} from '@/components/layout/site-shell';
import {HomeHero} from '@/components/sections/home-hero';
import {HomeCollections,HomeValues,HomeGallery,HomeHistory,HomeSamples} from '@/components/sections/home-sections';
export function HomeView(){return <SiteShell><HomeHero/><HomeCollections/><HomeValues/><HomeGallery/><HomeHistory/><HomeSamples/></SiteShell>;}
