import Image from 'next/image';
import Link from 'next/link';
import {SiteShell} from '@/components/layout/site-shell';
import {PageIntro} from '@/components/sections/page-intro';
import {Container,SectionTitle} from '@/components/ui/brand-ui';
import {ModernProductCarousel} from '@/components/ui/product-carousel';
import {ProductCollection} from '@/components/sections/product-collection';
import {asset} from '@/lib/assets';
import {mediaWebp} from '@/lib/media';

export function ProductsView(){return <SiteShell>
  <PageIntro title="ANTI FINGER" subtitle="Faromid Collection" image={mediaWebp('b64de2f4b544c1901affa3f8dce63e6f47283ee7','backgrounds')}/>
  <section className="bg-[#f4f4f0] py-16 sm:py-20"><Container><SectionTitle title="محصولات آنتی فینگر"/><ModernProductCarousel /></Container></section>
  <section className="bg-white py-16 sm:py-20"><Container><SectionTitle title="محصولات"/><ProductCollection/></Container></section>
  <section className="bg-[#f4f4f0] py-16 sm:py-20"><Container><SectionTitle title="تکسچر" action={{href:'/textures',label:'بیشتر'}} />
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">{asset.textures.slice(0,8).map((src,i)=><Link key={src} href="/textures" className="group relative block aspect-[.8] overflow-hidden rounded-[17px] border border-[#e5e8e0] bg-[#e8e8e3]"><Image src={src} fill alt={`بافت فرامید شماره ${i+1}`} sizes="(max-width:600px) 50vw, 25vw" className="object-cover transition-transform duration-500 group-hover:scale-[1.025]"/></Link>)}</div>
  </Container></section>
</SiteShell>}
