import {SiteShell} from '@/components/layout/site-shell';
import {Container,SectionTitle} from '@/components/ui/brand-ui';
import {EditorialGallery} from '@/components/sections/editorial-gallery';
import {asset} from '@/lib/assets';
const titles=['G2LAB | Monalia Hotel','Studio Arketo | Ristorante ExMahalo','دکوراسیون داخلی مدرن','پروژه‌های معماری فرامید','اجرای دکوراسیون','طراحی فضای زندگی'];
export function GalleryView(){return <SiteShell><section className="bg-[#f5f5f1] py-14 sm:py-20"><Container><SectionTitle title="پروژه‌ها"/><EditorialGallery items={asset.interiors.map((src,i)=>({src,title:titles[i]}))}/></Container></section></SiteShell>}
