import Image from 'next/image';
import {SiteShell} from '@/components/layout/site-shell';
import {PageIntro} from '@/components/sections/page-intro';
import {Container,SectionTitle} from '@/components/ui/brand-ui';
import {ContactForm} from '@/components/contact-form';
import {asset} from '@/lib/assets';
import {mediaWebp} from '@/lib/media';

export function DealershipView(){return <SiteShell><PageIntro title="اخذ نمایندگی" image={asset.dealership}/>
  <section className="bg-[#f5f5f1] py-16 sm:py-24"><Container><div className="grid items-start gap-10 lg:grid-cols-2 lg:gap-16">
    <div><div className="relative mb-7 aspect-[1.3] overflow-hidden rounded-[24px] bg-[#e7e7e2]"><Image src={mediaWebp('7a1c123ccba2ae8742f098b200b59b7eb3e9d180','dealership')} alt="نمایشگاه محصولات فرامید" fill sizes="(max-width:1024px) 100vw, 50vw" className="object-cover"/></div><p className="text-[15px] leading-[2.5] text-[#596159]">برای همکاری تجاری و اطلاع از شرایط اخذ نمایندگی محصولات فرامید، درخواست خود را به همراه نام شهر و اطلاعات تماس ارسال کنید.</p></div>
    <div className="rounded-[26px] border border-[#e4e7e1] bg-white p-6 sm:p-9"><SectionTitle title="فرم اخذ نمایندگی"/><ContactForm type="dealership"/></div>
  </div></Container></section>
</SiteShell>}
