import {SiteShell} from '@/components/layout/site-shell';
import {Container,SectionTitle} from '@/components/ui/brand-ui';
import {EditorialGallery} from '@/components/sections/editorial-gallery';
import {asset} from '@/lib/assets';
const titles=['تصاویر نمایشگاه اول','تصاویر نمایشگاه دوم','تصاویر نمایشگاه سوم','تصاویر نمایشگاه چهارم'];
export function ExhibitionsView(){return <SiteShell><section className="bg-[#f5f5f1] py-14 sm:py-20"><Container><SectionTitle title="نمایشگاه‌ها"/><EditorialGallery items={asset.exhibitions.map((src,i)=>({src,title:titles[i]}))}/></Container></section></SiteShell>}
