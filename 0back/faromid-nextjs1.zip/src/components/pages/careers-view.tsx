import {SiteShell} from '@/components/layout/site-shell';
import {PageIntro} from '@/components/sections/page-intro';
import {Container,SectionTitle} from '@/components/ui/brand-ui';
import {ContactForm} from '@/components/contact-form';
import {asset} from '@/lib/assets';

export function CareersView(){return <SiteShell><PageIntro title="همکاری با ما" image={asset.careers}/>
  <section className="bg-[#f5f5f1] py-16 sm:py-24"><Container><div className="mx-auto max-w-[850px]">
    <p className="mb-10 text-[15px] leading-[2.6] text-[#5c655d]">فلسفه کاری در فرامید مبتنی بر احترام و اخلاق حرفه‌ای می‌باشد که منجر به ایجاد محیط کاری دوستانه بر اساس معیارهای بین‌المللی و توأم با پیشرفت و یادگیری مستمر است.</p>
    <div className="rounded-[26px] border border-[#e4e7e1] bg-white p-6 sm:p-10"><SectionTitle title="ارسال رزومه"/><p className="mb-6 text-[13px] leading-[2.2] text-[#7b817a]">برای ارسال رزومه، زمینه تخصصی و راه ارتباطی خود را بنویسید و در برنامه ایمیل فایل رزومه را ضمیمه کنید.</p><ContactForm type="careers"/></div>
  </div></Container></section>
</SiteShell>}
