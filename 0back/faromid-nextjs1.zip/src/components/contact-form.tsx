'use client';

import {useState, type FormEvent, type ChangeEvent} from 'react';
import {ArrowUpLeft} from 'lucide-react';

type FormType='contact'|'careers'|'dealership';
const input='h-[54px] w-full rounded-2xl border border-[#e2e3dd] bg-[#fafaf8] px-4 text-sm text-[#2b302c] outline-none transition-colors duration-300 placeholder:text-[#a9ada7] focus:border-[#9ca59c] focus:bg-white';
export function ContactForm({type='contact'}:{type?:FormType}){
 const [values,setValues]=useState({name:'',email:'',phone:'',message:''});
 const [notice,setNotice]=useState(false);
 const subject=type==='careers'?'درخواست همکاری با فرامید':type==='dealership'?'درخواست نمایندگی فرامید':'ارتباط از وب‌سایت فرامید';
 const change=(key:keyof typeof values)=>(e:ChangeEvent<HTMLInputElement|HTMLTextAreaElement>)=>{setValues(old=>({...old,[key]:e.target.value}));setNotice(false);};
 const submit=(e:FormEvent)=>{e.preventDefault();
  const body=`نام و نام خانوادگی: ${values.name}\nایمیل: ${values.email}\nتلفن: ${values.phone||'ثبت نشده'}\n\n${values.message}`;
  const url=`mailto:info@faromid.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  setNotice(true);window.location.href=url;
 };
 return <form onSubmit={submit} className="grid gap-5" aria-label={subject}>
   <div className="grid gap-5 sm:grid-cols-2">
     <label className="grid gap-2 text-[13px] font-medium text-[#454945]">نام و نام خانوادگی <span className="text-[#a05f59]">*</span><input autoComplete="name" className={input} required placeholder="نام شما" value={values.name} onChange={change('name')}/></label>
     <label className="grid gap-2 text-[13px] font-medium text-[#454945]">ایمیل <span className="text-[#a05f59]">*</span><input type="email" dir="ltr" autoComplete="email" className={`${input} text-left`} required placeholder="you@example.com" value={values.email} onChange={change('email')}/></label>
   </div>
   <label className="grid gap-2 text-[13px] font-medium text-[#454945]">شماره تماس (اختیاری)<input type="tel" dir="ltr" autoComplete="tel" className={`${input} text-left`} placeholder="09xxxxxxxxx" value={values.phone} onChange={change('phone')}/></label>
   <label className="grid gap-2 text-[13px] font-medium text-[#454945]">{type==='careers'?'تخصص و توضیحات':type==='dealership'?'شهر و اطلاعات کسب‌وکار':'پیام شما'} <span className="text-[#a05f59]">*</span><textarea rows={5} className={`${input} h-auto min-h-[150px] resize-y py-4 leading-[2]`} required minLength={5} placeholder={type==='careers'?'در مورد تجربه و تخصص خود بنویسید. رزومه را در ایمیل ضمیمه کنید...':type==='dealership'?'شهر موردنظر، زمینه فعالیت و اطلاعات لازم را بنویسید...':'چگونه می‌توانیم کمکتان کنیم؟'} value={values.message} onChange={change('message')}/></label>
   <div className="flex flex-wrap items-center gap-5"><button className="group inline-flex min-h-12 items-center gap-3 rounded-full bg-[#252826] px-7 py-3 text-[13px] font-semibold text-white transition-all duration-300 hover:bg-[#454945]" type="submit">ادامه در برنامه ایمیل <ArrowUpLeft size={17} className="transition-transform group-hover:-translate-x-1 group-hover:-translate-y-1"/></button><p aria-live="polite" className="m-0 max-w-[370px] text-[11px] leading-[2] text-[#92968f]">{notice?'در صورت نصب برنامه ایمیل، پیش‌نویس باز شده است؛ برای ارسال نهایی آن را تأیید کنید.':'این فرم ایمیل شما را باز می‌کند و پیام مستقیماً از سرور ارسال نمی‌شود.'}</p></div>
 </form>;
}
