import type {Metadata} from 'next';
import {DealershipView} from '@/components/pages/dealership-view';

export const metadata:Metadata={title:'اخذ نمایندگی', description:'اخذ نمایندگی | گروه تولیدی فرامید، طراحی و تولید MDF و محصولات دکوراسیون داخلی'};
export default function Page(){return <DealershipView/>;}
