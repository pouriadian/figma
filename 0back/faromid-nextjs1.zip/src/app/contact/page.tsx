import type {Metadata} from 'next';
import {ContactView} from '@/components/pages/contact-view';

export const metadata:Metadata={title:'تماس با ما', description:'تماس با ما | گروه تولیدی فرامید، طراحی و تولید MDF و محصولات دکوراسیون داخلی'};
export default function Page(){return <ContactView/>;}
