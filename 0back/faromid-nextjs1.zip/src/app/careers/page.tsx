import type {Metadata} from 'next';
import {CareersView} from '@/components/pages/careers-view';

export const metadata:Metadata={title:'همکاری با ما', description:'همکاری با ما | گروه تولیدی فرامید، طراحی و تولید MDF و محصولات دکوراسیون داخلی'};
export default function Page(){return <CareersView/>;}
