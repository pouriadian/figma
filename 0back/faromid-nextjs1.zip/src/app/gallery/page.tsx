import type {Metadata} from 'next';
import {GalleryView} from '@/components/pages/gallery-view';

export const metadata:Metadata={title:'گالری تصاویر و پروژه\u200cها', description:'گالری تصاویر و پروژه\u200cها | گروه تولیدی فرامید، طراحی و تولید MDF و محصولات دکوراسیون داخلی'};
export default function Page(){return <GalleryView/>;}
