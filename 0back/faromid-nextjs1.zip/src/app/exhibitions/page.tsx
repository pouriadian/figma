import type {Metadata} from 'next';
import {ExhibitionsView} from '@/components/pages/exhibitions-view';

export const metadata:Metadata={title:'نمایشگاه\u200cها', description:'نمایشگاه\u200cها | گروه تولیدی فرامید، طراحی و تولید MDF و محصولات دکوراسیون داخلی'};
export default function Page(){return <ExhibitionsView/>;}
