import type {Metadata} from 'next';
import {HomeView} from '@/components/pages/home-view';

export const metadata:Metadata={title:'فرامید | گروه تولیدی فرامید', description:'فرامید | گروه تولیدی فرامید | گروه تولیدی فرامید، طراحی و تولید MDF و محصولات دکوراسیون داخلی'};
export default function Page(){return <HomeView/>;}
