import type {Metadata} from 'next';
import Image from 'next/image';
import Link from 'next/link';
import {notFound} from 'next/navigation';
import {ArrowRight,Mail} from 'lucide-react';
import {SiteShell} from '@/components/layout/site-shell';
import {ModernProductCarousel} from '@/components/ui/product-carousel';
import {Container,SectionTitle,BrandLink} from '@/components/ui/brand-ui';
import {CATALOG_PRODUCTS} from '@/lib/products-catalog';

export function generateStaticParams(){return CATALOG_PRODUCTS.map(product=>({slug:product.slug}));}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{
 const {slug}=await params;
 const product=CATALOG_PRODUCTS.find(item=>item.slug===slug);
 return {title:product?`CLEAN TOUCH – ${product.code}`:'محصول یافت نشد',description:product?`مشخصات MDF کلین تاچ فرامید کد ${product.code}`:undefined};
}
export default async function ProductDetail({params}:{params:Promise<{slug:string}>}){
 const {slug}=await params;
 const product=CATALOG_PRODUCTS.find(item=>item.slug===slug);
 if(!product)notFound();
 const related=CATALOG_PRODUCTS.filter(item=>item.id!==product.id).slice(0,8);
 return <SiteShell>
  <section className="bg-[#f5f5f1] py-9 sm:py-16"><Container>
   <Link href="/products" className="mb-8 inline-flex items-center gap-2 text-[13px] text-[#68736a] transition-colors hover:text-[#272f28]"><ArrowRight size={17}/> بازگشت به محصولات</Link>
   <div className="grid gap-8 lg:grid-cols-[1.07fr_.93fr] lg:gap-16">
    <div className="relative aspect-[1/.92] overflow-hidden rounded-[24px] border border-[#e0e2dc] bg-white"><Image src={product.image} alt={`طرح MDF فرامید CLEAN TOUCH کد ${product.code}`} fill priority sizes="(max-width:1024px) 100vw, 50vw" className="object-cover" /></div>
    <div className="flex flex-col justify-center"><h1 className="m-0 text-[clamp(2rem,3.5vw,3.5rem)] font-semibold leading-[1.55]">کلین تاچ | CLEAN TOUCH</h1><p className="mb-0 mt-2 text-sm text-[#727a73]">کد محصول: <strong dir="ltr" className="text-[#3a423b]">{product.code}</strong></p>
     <dl className="mt-8 divide-y divide-[#dfe3dc] border-y border-[#dfe3dc]">{[['مدل',product.model],['کد',product.code],['ابعاد',product.dimensions],['نوع','MDF دکوراتیو']].map(([label,value])=><div key={label} className="flex items-center justify-between gap-4 py-4 text-[14px]"><dt className="text-[#788179]">{label}</dt><dd className="m-0 font-medium text-[#333a33]">{value}</dd></div>)}</dl>
     <p className="mt-7 text-[13px] leading-[2.3] text-[#697269]">تصاویر نمونه ممکن است از نظر نور و رنگ در نمایشگرهای مختلف متفاوت باشند. برای اطلاعات فنی یا ثبت درخواست، با دفتر فروش تماس بگیرید.</p>
     <a href={`mailto:info@faromid.com?subject=${encodeURIComponent('استعلام محصول '+product.code)}`} className="mt-5 inline-flex w-fit min-h-12 items-center gap-3 rounded-full bg-[#29302a] px-6 py-3 text-[13px] font-semibold text-white transition-colors hover:bg-[#475249]"><Mail size={16}/>استعلام محصول</a>
    </div>
   </div>
  </Container></section>
  <section className="bg-white py-14 sm:py-20"><Container><SectionTitle title="محصولات" action={{href:'/products',label:'بیشتر'}}/><ModernProductCarousel items={related}/></Container></section>
 </SiteShell>
}
