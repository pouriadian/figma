import type {Metadata} from 'next';
import {ProductsView} from '@/components/pages/products-view';

export const metadata:Metadata={title:'محصولات آنتی فینگر', description:'محصولات آنتی فینگر | گروه تولیدی فرامید، طراحی و تولید MDF و محصولات دکوراسیون داخلی'};
export default function Page(){return <ProductsView/>;}
