import type {Metadata} from 'next';
import {AboutView} from '@/components/pages/about-view';

export const metadata:Metadata={title:'درباره فرامید', description:'درباره فرامید | گروه تولیدی فرامید، طراحی و تولید MDF و محصولات دکوراسیون داخلی'};
export default function Page(){return <AboutView/>;}
