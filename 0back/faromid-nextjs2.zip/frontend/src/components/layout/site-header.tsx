'use client';

import Image from 'next/image';
import Link from 'next/link';
import {usePathname} from 'next/navigation';
import {useEffect, useRef, useState} from 'react';
import {ChevronDown, Menu, X} from 'lucide-react';
import {brand} from '@/lib/media';
import {links} from '@/lib/constants';

const mainLinks = links.filter(item => ['/', '/products', '/textures', '/gallery', '/about'].includes(item.href));
const moreLinks = links.filter(item => !mainLinks.some(main => main.href === item.href));

/**
 * The homepage header overlays the original two-panel image banner.
 * Other routes retain their regular sticky navbar; both share the same links.
 */
export function SiteHeader() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const moreRef = useRef<HTMLDivElement>(null);
  const onHome = pathname === '/';

  useEffect(() => {setMobileOpen(false); setMoreOpen(false);}, [pathname]);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {setMobileOpen(false); setMoreOpen(false);}
    };
    const onPointer = (event: PointerEvent) => {
      if (moreRef.current && !moreRef.current.contains(event.target as Node)) setMoreOpen(false);
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('pointerdown', onPointer);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('pointerdown', onPointer);
    };
  }, []);

  if (onHome) {
    return (
      <header className="absolute inset-x-0 top-0 z-[100] w-full bg-transparent">
        <div className="relative hidden h-[9.3vw] w-full lg:block">
          <Link
            href="/"
            aria-label="فرامید - صفحه اصلی"
            className="absolute top-[calc(4.455vw+5px)] left-[6.95%] block w-[15.795%] focus-visible:rounded-md"
          >
            <Image src={brand.logo} width={273} height={72} priority alt="Faromid Group" className="h-auto w-full" />
          </Link>
          <nav
            aria-label="فهرست اصلی"
            className="absolute top-[calc(4.225vw+4px)] right-[2.95%] left-[24.25%] flex h-[4.34vw] items-center justify-around gap-[.15vw] rounded-[5px] bg-white/80 px-[1.25vw] [direction:rtl] backdrop-blur-[2px]"
          >
            {links.map(item => (
              <Link
                key={item.href}
                href={item.href}
                aria-current={pathname === item.href ? 'page' : undefined}
                className="inline-flex min-h-[70%] shrink-0 items-center justify-center whitespace-nowrap rounded-[4px] px-[.22vw] text-[clamp(10px,1.1574vw,20px)] font-normal text-[#606060] transition-colors duration-200 hover:bg-black/5 hover:text-[#161616] focus-visible:text-black"
              >
                {item.href === '/textures' ? 'بافت' : item.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="relative flex h-[76px] items-center justify-between px-5 [direction:ltr] sm:h-[86px] sm:px-8 lg:hidden">
          <Link href="/" aria-label="صفحه اصلی فرامید" onClick={() => setMobileOpen(false)} className="relative z-10 inline-flex items-center">
            <Image src={brand.logo} alt="Faromid Group" width={210} height={56} priority className="h-auto w-[155px] sm:w-[190px]" />
          </Link>
          <button
            type="button"
            aria-label={mobileOpen ? 'بستن منو' : 'باز کردن منو'}
            aria-controls="faromid-home-mobile-nav"
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen(!mobileOpen)}
            className="relative z-10 grid h-11 w-11 place-items-center rounded-xl border border-white/30 bg-[#0d0d0d]/75 text-white backdrop-blur-sm transition-colors hover:bg-[#0d0d0d]"
          >
            {mobileOpen ? <X size={22}/> : <Menu size={22}/>}
          </button>
        </div>
        {mobileOpen && (
          <nav id="faromid-home-mobile-nav" aria-label="فهرست اصلی موبایل" dir="rtl" className="mx-3 grid max-h-[calc(100dvh-90px)] grid-cols-2 gap-1 overflow-y-auto rounded-2xl bg-white/95 p-3 text-[#303030] shadow-xl backdrop-blur-md sm:mx-8 sm:grid-cols-3 lg:hidden">
            {links.map(item => (
              <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)} className="rounded-xl px-3 py-3 text-center text-[13px] transition-colors hover:bg-[#f0f0f0]">
                {item.href === '/textures' ? 'بافت' : item.label}
              </Link>
            ))}
          </nav>
        )}
      </header>
    );
  }

  const navClass = (href: string) =>
    `relative inline-flex min-h-11 items-center whitespace-nowrap text-[13px] font-medium transition-colors duration-200 after:absolute after:inset-x-0 after:bottom-1.5 after:h-px after:bg-white/75 after:transition-transform after:duration-300 ${pathname === href ? 'text-white after:scale-x-100' : 'text-white/70 hover:text-white after:scale-x-0 hover:after:scale-x-100'}`;

  return <header className="sticky top-0 z-[100] border-b border-white/10 bg-[#171918]/95 text-white shadow-[0_8px_24px_rgba(0,0,0,.12)] backdrop-blur-xl">
    <div className="mx-auto flex h-[74px] w-full max-w-[1440px] items-center justify-between gap-5 px-5 sm:px-8 xl:h-[86px] xl:px-12 2xl:px-16">
      <Link href="/" aria-label="صفحه اصلی فرامید" className="z-10 inline-flex shrink-0 items-center rounded-md" onClick={() => setMobileOpen(false)}>
        <Image src={brand.logo} alt="Faromid Group" width={230} height={65} priority className="h-auto w-[149px] object-contain sm:w-[168px]" />
      </Link>
      <nav className="hidden items-center gap-5 xl:flex 2xl:gap-8" aria-label="فهرست اصلی">
        {mainLinks.map(item => <Link key={item.href} href={item.href} aria-current={pathname === item.href ? 'page' : undefined} className={navClass(item.href)}>{item.label}</Link>)}
        <div className="relative" ref={moreRef}>
          <button type="button" className="inline-flex min-h-11 items-center gap-2 rounded-full px-2 text-[13px] text-white/75 transition-colors hover:text-white" aria-expanded={moreOpen} aria-controls="faromid-more-links" onClick={() => setMoreOpen(!moreOpen)}>
            بیشتر <ChevronDown size={15} className={`transition-transform duration-200 ${moreOpen ? 'rotate-180' : ''}`} />
          </button>
          {moreOpen && <div id="faromid-more-links" className="absolute top-full right-0 z-20 mt-2 w-[205px] rounded-2xl border border-white/10 bg-[#252927] p-2 shadow-[0_18px_40px_rgba(0,0,0,.24)]">
            {moreLinks.map(item => <Link href={item.href} key={item.href} className={`block rounded-xl px-4 py-3 text-[13px] transition-colors ${pathname === item.href ? 'bg-white/12 text-white' : 'text-white/70 hover:bg-white/10 hover:text-white'}`} onClick={() => setMoreOpen(false)}>{item.label}</Link>)}
          </div>}
        </div>
      </nav>
      <button type="button" className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-white/15 text-white transition-colors hover:bg-white/10 xl:hidden" aria-label={mobileOpen ? 'بستن منو' : 'باز کردن منو'} aria-expanded={mobileOpen} aria-controls="faromid-mobile-links" onClick={() => setMobileOpen(!mobileOpen)}>
        {mobileOpen ? <X size={22} /> : <Menu size={22} />}
      </button>
    </div>
    <nav id="faromid-mobile-links" aria-label="فهرست موبایل" className={`${mobileOpen ? 'grid' : 'hidden'} max-h-[calc(100dvh-74px)] grid-cols-1 gap-1 overflow-y-auto border-t border-white/10 bg-[#191c1a] p-4 sm:grid-cols-2 sm:p-6 xl:hidden`}>
      {links.map(item => <Link href={item.href} key={item.href} aria-current={pathname === item.href ? 'page' : undefined} onClick={() => setMobileOpen(false)} className={`rounded-xl px-4 py-3.5 text-sm transition-colors ${pathname === item.href ? 'bg-white/15 text-white' : 'text-white/70 hover:bg-white/10 hover:text-white'}`}>{item.label}</Link>)}
    </nav>
  </header>;
}
